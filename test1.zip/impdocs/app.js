var express = require('express');
var favicon = require('serve-favicon');
var morgan = require('morgan');
var compression = require('compression');
var bodyParser = require('body-parser');
var methodOverride = require('method-override');
var cookieParser = require('cookie-parser');
var errorHandler = require('errorhandler');
var path = require('path');
var passport = require('passport');
var session = require('express-session');
var path = require('path');
var passport = require('./server/config/passport');
var expressValidator = require('express-validator');
var http = require('http');

var app = express();

//Code for CSRF Varifaction
/*var csrfValue = function(req) {
    var token = (req.body && req.body._csrf)
        || (req.query && req.query._csrf)
        || (req.headers['x-csrf-token'])
        || (req.headers['x-xsrf-token']);
    return token;
};
*/

app.use(session({
    'secret': "secret key",
    'name': 'sid',
    'unset': 'destroy', 
    'resave': true,
    'saveUninitialized': true
}));

app.use(passport.initialize());
app.use(passport.session());

app.use(cookieParser("secretkey"));
//app.use(bodyParser());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(expressValidator()); 

app.set('appPath', 'public');
app.use(express.static(__dirname +'/public'));
app.use(favicon(__dirname + '/public/assets/favicon.ico'));

/*app.use(express.csrf({ value: csrfValue }));

app.use(function(req, res, next) {
    console.log("Request URL" + req.originalUrl)
    console.log("XSRF-TOKEN => " + req.session._csrf)
    res.cookie('XSRF-TOKEN', req.session._csrf);
    next();

});*/

/*var jwt = require('jsonwebtoken');

app.use(function(req, res, next) {


console.log(req.headers);


    if(req.headers.authtoken)
    {
        var token = req.headers.authtoken;
        jwt.verify(token, 'shhhhh', function(err, decoded) {
            console.log(decoded);
            if(err)
            {
                res.json({status:'fail','data':null, 'message':err.message});
            }
            else
            {
                console.log(token);
                next();
            }   
        });
    }
    else
    {
        if(req.body.deviceID && req.body.secretKey)
        {
            var token = jwt.sign({ device_id: req.body.deviceID }, 'shhhhh');
            if(token)
            {
                console.log(token);
                res.json({status:'success', 'token':token});
            }
            else
            {
                console.log("---token or secret key not found---");
                res.json({status:'fail','token':null});
            }   
        }
        else
        {
            res.json({status:'fail','data':null, 'message':'Device id and secret key not found'});
        }    
    }
});
*/
//app.use(app.router);


/*///////////////////////////////////////////*/
/*/             General Route                /*/
/*//////////////////////////////////////////*/

var miscellaneousRoute = require('./server/api/general/miscellaneous/route/miscellaneousRoute.js');
new miscellaneousRoute(app);


/*///////////////////////////////////////////*/
/*/             Admin Routes                /*/
/*//////////////////////////////////////////*/
var adminAuthenticationRoute = require('./server/api/admin/auth/route/authRoute.js');
new adminAuthenticationRoute(app);

var adminUserRoute = require('./server/api/admin/user/route/userRoute.js');
new adminUserRoute(app);

var adminComposerRoute = require('./server/api/admin/composer/route/composerRoute.js');
new adminComposerRoute(app);


var siteArticleRoute = require('./server/api/admin/article/route/articleRoute.js');
new siteArticleRoute(app);

var siteGenreRoute = require('./server/api/admin/genre/route/genreRoute.js');
new siteGenreRoute(app);


var siteInstrumentRoute = require('./server/api/admin/instrument/route/instrumentRoute.js');
new siteInstrumentRoute(app);


var adminPieceRoute = require('./server/api/admin/piece/route/pieceRoute.js');
new adminPieceRoute(app);


var adminPianoTypeRoute = require('./server/api/admin/pianoType/route/pianoTypeRoute.js');
new adminPianoTypeRoute(app);


var adminSubscriptionPlanRoute = require('./server/api/admin/subscriptionPlan/route/subscriptionPlanRoute.js');
new adminSubscriptionPlanRoute(app);


var adminDashboardRoute = require('./server/api/admin/dashboard/route/dashboardRoute.js');
new adminDashboardRoute(app);



/*///////////////////////////////////////////*/
/*/             Front-end Routes           /*/
/*//////////////////////////////////////////*/
var siteAuthenticationRoute = require('./server/api/site/auth/route/authRoute.js');
new siteAuthenticationRoute(app);

var siteUserRoute = require('./server/api/site/user/route/userRoute.js');
new siteUserRoute(app);

var siteMusicLibraryRoute = require('./server/api/site/musicLibrary/route/musicLibraryRoute.js');
new siteMusicLibraryRoute(app);

var siteSubscriptionRoute = require('./server/api/site/subscription/route/subscriptionRoute.js');
new siteSubscriptionRoute(app);

var siteHomeRoute = require('./server/api/site/home/route/homeRoute.js');
new siteHomeRoute(app);



/*///////////////////////////////////////////*/
//                  Cron                    //
/*//////////////////////////////////////////*/
app.all('/cronTab/inviteOldUser*', function(req, res, next) {
    
    //http://localhost:3003/cronTab/inviteOldUser
    var cronController = require('./server/api/general/cron/controller/cronController');
    cronController.inviteOldUser(req, res, next);

});

app.all('/cronTab/subscriptionReminder*', function(req, res, next) {
    
    //http://localhost:3003/cronTab/subscriptionReminder
    var cronController = require('./server/api/general/cron/controller/cronController');
    cronController.subscriptionReminder(req, res, next);

});


/*///////////////////////////////////////////*/
//             Main Route                    //
/*//////////////////////////////////////////*/

app.all('/admin*', function(req, res, next) {
    res.sendfile(app.get('appPath') + '/admin.html');
});

app.all('/*', function(req, res, next) {
    res.sendfile(app.get('appPath') + '/index.html');
});


http.createServer(app).listen(3003, function(){
    console.log("Express server listening on port 3003");
});

exports = module.exports = app;