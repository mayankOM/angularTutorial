/**
    * Main AngularJS Web Application
*/
var app = angular.module('siteApp', [
    'ngRoute',
    'ngCookies',
    'ngResource',
    'ngStorage',
    /*'swxSessionStorage',*/
    'homePageModule',
    'siteMusicLibrary',
    'siteSubscription',
    'userModule',
    'ngFileUpload',
    'angularUtils.directives.dirPagination',
    'angular-loading-bar',
    'ngSanitize',
    'siteMusic'
]);

app.config(['$routeProvider','$locationProvider', function ($routeProvider,$locationProvider) {
    
    $routeProvider.otherwise("/");
    $locationProvider.html5Mode(true);

}]).run(function($http) {
    $http.get('/api/general/abc').success(function(response) {
    }).error(function(response) {});
});

var onlyLoggedIn = function ($location,$q,siteAuth) {
    
    var deferred = $q.defer();
    siteAuth.isLoggedInAsync(function(loggedIn) {
        
        if (loggedIn) {
            deferred.resolve();
        } else {
            deferred.reject();
            $location.url('/');
        }
    });
    return deferred.promise;
};


var loadLoggedInUser = function ($location,$q,siteAuth) {
    var deferred = $q.defer();
    siteAuth.loadLogedInUser(function(loggedInUser) {
        deferred.resolve();
    });
    return deferred.promise;

}
