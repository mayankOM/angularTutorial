'use strict';

//Define App module
var siteMusic = angular.module("siteMusic");
	
siteMusic.controller('siteMusicController', ["$rootScope","$scope","$timeout", "$route", "$location", "$http", "siteAuth", "$routeParams", "$filter",
	function($rootScope, $scope, $timeout, $route, $location, $http, siteAuth, $routeParams, $filter) {
		
		$scope.indexNo = '';
		$scope.userAuthentication = "";
		$scope.MuscilibraryList = "";
		$scope.playerShow = 0;
		$scope.latestScrollHeight = 0;
		
		//New Customisation by Ajay
		$scope.playerType 				= 'simple';
		$scope.simplePlayerObj 			= '';
		$scope.customPlayerObj 			= '';
		
		//$scope.s3BucketURL 			= 'https://d5dr1biitdh99.cloudfront.net/uploads/';
		//--Old working---//
		//$scope.s3BucketURL 				= 'https://s3-us-west-2.amazonaws.com/pianoamigo-cloudfront/uploads/';
		$scope.s3BucketURL 				= 'https://s3.amazonaws.com/accompany-production/';
										   
		//$scope.s3BucketURL 			= 'https://s3.amazonaws.com/softwebpianostage/';
		
		$scope.defaultAudioFile 		= '';
		$scope.defaultAudioFileIndex 	= 0;
		$scope.selectedTempo 			= 0;
		$scope.currentTempoIndex 		= 0;
		$scope.payerStatus 				= 'paused';
		$scope.selectedPieceID 			= 0;

	    $scope.loopStartPercentage 		= 0;
	    $scope.loopEndPercentage 		= 20;
	    $scope.currentPlayerPosition 	= 0;
	    
	    //$scope.replayFlag 				= 1;
	    $scope.pauseTime 				= 2000;
	    $scope.favoritePiece 			= false;
	    $scope.defaultTempoIndex 		= 0;
	    $scope.defaultTempo 			= false;

	    $scope.reverse 					= false;
		$scope.predicate 				= 'title';


		if(siteAuth.getCurrentUser()) {
			$scope.userAuthentication = $rootScope.userAuthenticated;
		}	

		$scope.tempoArray = '';
		$scope.pauseflag = 0;
		
		//$scope.instrumentsText = 'Select';
		//$scope.librariesText = 'Select';

		$scope.libraries = '';
		$scope.instruments = '';

		

		/*$scope.searchText = "";
		$scope.friends = [{
	        name: 'John',
	        phone: '555-1276'
	    }, {
	        name: 'Mary',
	        phone: '800-BIG-MARY'
	    }, {
	        name: 'Mike',
	        phone: '555-4321'
	    }, {
	        name: 'Adam',
	        phone: '555-5678'
	    }, {
	        name: 'Julie',
	        phone: '555-8765'
	    }];*/

		
		$('.fancy-select').click(function() {
            
            if($(this).children('.trigger,.options').hasClass('open')) {
                $(this).children('.trigger,.options').removeClass('open');    
            } else {
                $('div.fancy-select .trigger, div.fancy-select .options ').removeClass('open');
                $(this).children('.trigger,.options').addClass('open');
            }
        });


		$scope.setReplayStatus = function() {
			
			if($scope.playerType == 'simple'){
				
				$("#slider").addClass("meter red");
				var startPoint = 0;
				var objectName = $scope.simplePlayerObj;
		    
		    } else {
		    	
		    	$("#customSlider").addClass("meter red");
				var objectName = $scope.customPlayerObj;
				var startPoint = $scope.loopStartPercentage;
				
			}
			objectName.jPlayer("pause");
			
			setTimeout(function() {
				$scope.payerStatus = 'playing';
				objectName.jPlayer("playHead", startPoint);
			},100);
		};

		$scope.setVal = function(key,val,text) {
			
			if(key == 'libraries') {
				$scope.libraries = val;
				$scope.librariesText = text;
			} else if (key == 'instruments') {
				$scope.instruments = val;
				$scope.instrumentsText = text;
			}
			$scope.searchData();
		};

		$scope.disableEnablePlay = function(palyer,flag){

			if(palyer === 'custom') {
				
				if(flag === 'disable') {
					$("#customSlider").slider('disable');
					$("#extraCustom").show();
					$("#existingCustom").hide();	
					$("#customSlider").addClass("meter red");
				} else {
					$("#customSlider").slider('enable');
					$("#extraCustom").hide();
					$("#existingCustom").show();	
					$("#customSlider").removeClass("meter red");
				}

			} else {

				if(flag === 'disable') {
					$("#slider").slider('disable');
					$("#extraSimple").show();
					$("#existingSimple").hide();	
					$("#slider").addClass("meter red");
				} else {
					$("#slider").slider('enable');
					$("#extraSimple").hide();
					$("#existingSimple").show();	
					$("#slider").removeClass("meter red");
				}
			}
		};

		/*
			Module : MusicLibrary
			Author : Mayank [SOFTWEB]
			Inputs : 
			Output : List of Basic data [Library List, Instrument List]
			Date   : 2015-10-28
		*/
		$scope.getMuscilibrary = function() {

			$scope.MuscilibraryList = "";
			$http.post('/api/general/getInstrumentList','').success(function(response) {
				
				$scope.instrumentsText 	= response[0].title;
				$scope.instruments 		= response[0].id;
				$scope.instrumentsList 	= response;	
			
				$http.post('/api/general/getLibraryList','').success(function(response) {
					
					$scope.librariesText 	= response[0].title;
					$scope.libraries 		= response[0].id;
					$scope.librariesList 	= response;
					
					$scope.searchData();	

				}).error(function(response) {
					$scope.error = response.message;
				});

			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/*
			Module : MusicLibrary
			Author : Mayank Patel [SOFTWEB]
			Inputs : Search Keyword, InstrumentID or LibraryID
			Output : List of searched Pieces (Musci Library)
			Date   : 2015-10-28
		*/
		$scope.searchData = function() {

			$scope.MuscilibraryList = "";
			
			if($routeParams.favtxt == 'favorite'){
				var postedValue = {
					q			: 	($scope.q) ? $scope.q : '',
					libraries 	: 	($scope.libraries) ? $scope.libraries : '',
					instruments : 	($scope.instruments) ? $scope.instruments : '',
					userID      : 	siteAuth.getCurrentUser().id,
					favorite    : 	"YES"
				};
				$scope.musicLibTitle = "FAV";
			}
			else{
				var postedValue = {
					q			: 	($scope.q) ? $scope.q : '',
					libraries 	: 	($scope.libraries) ? $scope.libraries : '',
					instruments : 	($scope.instruments) ? $scope.instruments : '',
					userID      : 	siteAuth.getCurrentUser().id,
					favorite    : 	"NO"
				};
				$scope.musicLibTitle = "LIB";
			}	

			console.log(postedValue);

			$http.post('/api/site/listFilteredMuscilibrary',postedValue).success(function(response) {
				
				if(response.status == 'succ') {

					$scope.indexNo = 0;
					$scope.currentPage = 1;
	  				$scope.pageSize = 10;
					$scope.MuscilibraryList = response.data;

					if($scope.playerShow == 1)
					{
						$scope.myObj = {
					        "height" : $scope.latestScrollHeight+"px"
					    }
					}
				} else {
					$scope.error = response.err;
				}
			}).error(function(response) {
					$scope.error = response.message;
			});

		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : MisucLibraryId (PieceID)
		    Output : Get Detail of selected Piece
		    Date   : 2015-11-04
		*/
		$scope.getMusicDetail = function(pieceID) {
			
			var pieceRowID = '#musicLibIcon_'+pieceID;
			var selector = '.simpleTrack li.musicitem div a';
			
			$(selector).removeClass('active');
		    $(pieceRowID).addClass('active');
		    
		    var playHead = 0;

		    if($scope.playerType == 'simple'){
				$scope.disableEnablePlay('simple','disable');
				var objectName = $scope.simplePlayerObj;
		    } else {
		    	$scope.disableEnablePlay('custom','disable');
				var objectName = $scope.customPlayerObj;
			}
		    objectName.jPlayer("pause");

			$scope.MusicDetail = "";
			var pieceID = pieceID;
			var musicObj = {
				pieceID		: pieceID,
				userID      : siteAuth.getCurrentUser().id
			}

			if(musicObj) {
				
				
				//Get Music Detail for the selected Music ID (Piece ID)
				$http.post('/api/site/musicDetail',musicObj).success(function(response) {
					
					if(response.status == 'succ') {
						
						$scope.MusicDetail 			= response.data[0];       			//Piece Detail
						$scope.selectedTempo 		= $scope.MusicDetail.tempo;         //Default Tempo
						
						var musicDetailArray 		= ($scope.MusicDetail.UsersPieces[0]) ? $scope.MusicDetail.UsersPieces[0] : []; 
						$scope.favoritePiece    	= (musicDetailArray.isFavourite) ? musicDetailArray.isFavourite : false;
						$scope.selectedPieceID 		= musicObj.pieceID;
						
						$scope.loopStartPercentage 	= parseFloat((musicDetailArray.startLoop && musicDetailArray.startLoop != '') ? Number(parseFloat(musicDetailArray.startLoop)).toFixed(2) : 0); 
						$scope.loopEndPercentage  	= parseFloat((musicDetailArray.endLoop && musicDetailArray.endLoop != '') ? Number(parseFloat(musicDetailArray.endLoop)).toFixed(2) : 20); 
						
						$("#startPoint").val($scope.loopStartPercentage);
						$("#endPoint").val($scope.loopEndPercentage);

						$("#customSlider").slider("option", "values", [$scope.loopStartPercentage,$scope.loopEndPercentage]);
						$("#slider").slider("option", "value",0);

						playHead = ($scope.playerType == 'simple') ? 0 : $scope.loopStartPercentage;
						$scope.currentPlayerPosition = ($scope.playerType == 'simple') ? 0 : $scope.loopStartPercentage;
						
						
						$("#palyer").show();
						
						/*----Manage Music library list relative to player ---*/
						$scope.playerShow = 1;
						var playerHeight = $("#palyer").height();
						var musicBGHeight = $(".music_bg").height();
						var headHeight = $(".head").height();
						var newHeight = parseInt(playerHeight) + parseInt(headHeight);
						var scrollHeight = parseInt(musicBGHeight) - parseInt(newHeight);
						$scope.latestScrollHeight = scrollHeight;
						$scope.myObj = {
					        "height" : $scope.latestScrollHeight+"px"
					    }

						var tempoArray = [];
						//console.log("Ajay Here :: " + $scope.MusicDetail.AudioFiles.length + " => " +$scope.selectedTempo)
						
						for(var i = 0; i < $scope.MusicDetail.AudioFiles.length; i++) {
							
							if(parseInt($scope.MusicDetail.AudioFiles[i].tempo) === $scope.selectedTempo) {
								
								$scope.defaultAudioFileIndex 	= i;
								$scope.currentTempoIndex 		= i;
								$scope.defaultTempoIndex 		= i;
	    						$scope.defaultTempo 			= true;
	    						$scope.defaultAudioFile 		= $scope.MusicDetail.AudioFiles[i].file
								
								$scope.setPlayer(objectName,playHead);
								
							}
							
							var obj = {
								index 	: i,
								id 		: $scope.MusicDetail.AudioFiles[i].id,
								tempo 	: $scope.MusicDetail.AudioFiles[i].tempo,
								file 	: $scope.MusicDetail.AudioFiles[i].file,
							}
							tempoArray.push(obj);
						}
						
						$scope.tempoArray = tempoArray;
						
					} else {
						$scope.error = response.err;
					}	
				
				}).error(function(response) {
					$scope.error = response.message;
				});	
			}
		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : Index Of selected Tempo
		    Output : Get detail of NEXT tempo 
		    Date   : 2015-11-19
		*/
		$scope.getTempoDetailPrev = function(index) {

			index = parseInt(index) + 1;
			
			if(index >= 0 && index < $scope.tempoArray.length) {
				
				
				var currentPlayerPosition 			= $scope.currentPlayerPosition;
				//$scope.currentPlayerPositionOne 	= currentPlayerPosition;

				$scope.defaultTempo 			= ($scope.defaultTempoIndex == index) ? true : false;
				$scope.defaultAudioFile 		= $scope.tempoArray[index].file;
				$scope.defaultAudioFileIndex 	= $scope.tempoArray[index].index;
				$scope.selectedTempo 			= $scope.tempoArray[index].tempo;
				$scope.currentTempoIndex 		= $scope.defaultAudioFileIndex;

				var currentPayerStatus 			= $scope.payerStatus;
				
				if($scope.playerType == 'simple') {
					$scope.disableEnablePlay('simple','disable');
					var objectName = $scope.simplePlayerObj;
				} else {
					$scope.disableEnablePlay('custom','disable');
					var objectName = $scope.customPlayerObj;
				}
				
				$scope.setPlayer(objectName,currentPlayerPosition);

			} else {
				return false;
			}	
		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : Index Of selected Tempo
		    Output : Get detail of selected tempo -1
		    Date   : 2015-11-19
		*/
		$scope.getTempoDetailNext = function(index) {

			index = parseInt(index) - 1;
			
			if(index >= 0 && index < $scope.tempoArray.length) {
				
				var currentPlayerPosition 		= $scope.currentPlayerPosition;
				$scope.defaultTempo 			= ($scope.defaultTempoIndex == index) ? true : false;
				$scope.defaultAudioFile 		= $scope.tempoArray[index].file;
				$scope.defaultAudioFileIndex 	= $scope.tempoArray[index].index;
				$scope.selectedTempo 			= $scope.tempoArray[index].tempo;
				$scope.currentTempoIndex 		= $scope.defaultAudioFileIndex;
				var currentPayerStatus 			= $scope.payerStatus;
				
				if($scope.playerType == 'simple') {
					$scope.disableEnablePlay('simple','disable');
					var objectName = $scope.simplePlayerObj;
				} else {
					$scope.disableEnablePlay('custom','disable');
					var objectName = $scope.customPlayerObj;
				}
				
				$scope.setPlayer(objectName,currentPlayerPosition);
			
			} else {
				return false;
			}
		};


		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : Sort parameter
		    Output : Get Sort list
		    Date   : 2015-11-09
		*/
		$scope.order = function(predicate) {
			$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
			$scope.predicate = predicate;
		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : pieceID, userID
		    Output : Update Favorite or UnFavorite Piece
		    Date   : 2015-11-20
		*/
		
		$scope.updateFavourite = function() {
			
			var userID 	= siteAuth.getCurrentUser().id;
			var obj = {
				userID 		: userID,
				pieceID 	: $scope.selectedPieceID,
			};						
			
			$http.post('/api/site/updateFavourite',obj).success(function(response) {
				if(response.status == 'succ') {
					$scope.favoritePiece = response.data; 
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};




		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : pieceID, userID
		    Output : Update Start and End time of loop
		    Date   : 2015-11-20
		*/
		
		$scope.updateStartEndTime = function() {
			
			var userID 	= siteAuth.getCurrentUser().id;
			var obj = {
				userID 		: userID,
				pieceID 	: $scope.selectedPieceID,
				startLoop 	: $scope.loopStartPercentage,
				endLoop 	: $scope.loopEndPercentage,
			};						
			
			$http.post('/api/site/updateStartEndTime',obj).success(function(response) {
				if(response.status == 'succ') {
					console.log("Time Updated :: ");
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};


		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : PieceID, UserID
		    Output : Update last played Pice time
		    Date   : 2015-11-23
		*/
		$scope.updateLastPlayedPiece = function() {

			var userID = siteAuth.getCurrentUser().id;
			var obj = {
				userID 		: userID,
				pieceID 	: $scope.selectedPieceID,
			};						
			
			$http.post('/api/site/updateLastPlayedPiece',obj).success(function(response) {

				var last_played_time = response.data;					
				if(response.status == 'succ') {
					
					for(var index = 0; index < $scope.MuscilibraryList.length; index++) {
						
						if($scope.MuscilibraryList[index].id == $scope.selectedPieceID) {
							
							if($scope.MuscilibraryList[index].UsersPieces[0]){
								$scope.MuscilibraryList[index].UsersPieces[0].lastPlayed = last_played_time;
							} else {
								$scope.MuscilibraryList[index].UsersPieces.push({'lastPlayed':last_played_time});
							}
							break;
						}
					}
				}
			
			}).error(function(response) {
				$scope.error = response.message;
			});
		};


		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : PieceID, UserID
		    Output : Update last played Pice time
		    Date   : 2015-11-23
		*/
		$scope.getLatestBufferinTime = function(currentTime) {
			console.log("----Get a Current time Function -------");
			console.log(currentTime);

		};


		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : playerObj, playHead
		    Output : Set media in player
		    Date   : 2016-01-07
		*/
		$scope.setPlayer = function(playerObj,playHead){
			
			var mediaPaht = $scope.s3BucketURL+$scope.selectedPieceID+"/"+$scope.defaultAudioFile;
			playerObj.jPlayer("setMedia", { m4a:  mediaPaht }).jPlayer("playHead",playHead);

			//Need to remove comment In case when need to user Signed url
			/*var tempoDetail = {
				pieceID :  $scope.selectedPieceID,
				fileName : $scope.defaultAudioFile
			}
			$http.post('/api/site/getCoudFrontUrl',tempoDetail).success(function(responseData){
				playerObj.jPlayer("setMedia", { m4a:  responseData.data }).jPlayer("playHead",playHead);
			});*/
		
		};

		/*-------------------Script for player -------------------------------*/

		$scope.pauseflag = 0;
		var simpleStartSliderTime = 0;

		/*--------------- simple mode ----------------------------------------*/
		/*
		    * jQuery UI ThemeRoller
		    *
		    * Includes code to hide GUI volume controls on mobile devices.
		    * ie., Where volume controls have no effect. See noVolume option for more info.
		    *
		    * Includes fix for Flash solution with MP4 files.
		    * ie., The timeupdates are ignored for 1000ms after changing the play-head.
		    * Alternative solution would be to use the slider option: {animate:false}
		*/
		
		$scope.simplePlayerObj = $("#jquery_jplayer_simple");
		
		var simplePlayerData,
		    fixFlash_mp4, 			// Flag: The m4a and m4v Flash player gives some old currentTime values when changed.
		    fixFlash_mp4_id, 		// Timeout ID used with fixFlash_mp4
		    ignore_timeupdate, 		// Flag used with fixFlash_mp4
		    
		    options = {
		    
		        
		        ready: function (event) {
		            //Hide the volume slider on mobile browsers. ie., They have no effect.
		            if(event.jPlayer.status.noVolume) {
		                //Add a class and then CSS rules deal with it.
		                $(".volume_part").addClass("jp-no-volume");
		            }
		            //Determine if Flash is being used and the mp4 media type is supplied. BTW, Supplying both mp3 and mp4 is pointless.
		            fixFlash_mp4 = event.jPlayer.flash.used && /m4a|m4v/.test(event.jPlayer.options.supplied);
	            },

	            seeked: function(event){
	        		$scope.disableEnablePlay('simple','enable');
	            	if($scope.payerStatus == 'playing')
	            		$scope.simplePlayerObj.jPlayer("play");
	        	},

	            timeupdate: function(event) {
	            	
	            	/* Old  code */
	            	var obj = event.jPlayer.status.media;
	                if(!$.isEmptyObject(obj)){
		            	$scope.currentPlayerPosition  = Number(event.jPlayer.status.currentPercentAbsolute).toFixed(2);
		            }
	            	if(!ignore_timeupdate) { 
	            		simpleControl.progress.slider("value", $scope.currentPlayerPosition);
	            	}
	            	//console.log("Ajay Piece id :: " + $scope.selectedPieceID);

		        },


		        pause: function(event) {
                	$scope.payerStatus  = 'paused';
	            },

	            play: function(event){
		        	//$scope.simplePlayerObj.jPlayer("playHead",$scope.currentPlayerPosition);
	            	$scope.updateLastPlayedPiece();
		        },
		        playing: function(event){
	            	$scope.payerStatus  = 'playing';
	            	$scope.disableEnablePlay('simple','enable');
		        },

		        volumechange: function(event) {
		            if(event.jPlayer.options.muted) {
		            	simpleControl.volume.slider("value", 0);
		            } else {
		                simpleControl.volume.slider("value", event.jPlayer.options.volume);
		            }
		        },

		        ended: function(event) {
	                $scope.currentPlayerPosition = 0;
	                $scope.simplePlayerObj.jPlayer('stop');
	                simpleControl.progress.slider("value", 0);
	                $scope.currentPlayerPosition = 0;
	            },
	            
	            swfPath: "../../dist/jplayer",
	            supplied: "m4a, oga",
	            cssSelectorAncestor: "#jp_container_simple",
	            wmode: "window",
	            keyEnabled: true,
	            preload:"auto",
	            keyBindings: {
				  	play: {
				    	key: 32, //Spacebar
				    	fn: function(f) {
				      		if(f.status.paused) {
				        		f.play();
				      		} else {
				        		f.pause();
				      		}
				    	}
				  	},
				}
	        },
	        
	       

	        simpleControl = {
	            progress: $(options.cssSelectorAncestor + " .jp-progress-slider"),
	            volume: $(options.cssSelectorAncestor + " .jp-volume-slider")
	        };

		    //Instance jPlayer
		    $scope.simplePlayerObj.jPlayer(options);

		    //A pointer to the jPlayer data object
		    simplePlayerData = $scope.simplePlayerObj.data("jPlayer");

		    //Define hover states of the buttons
		    $('.jp-gui ul li').hover(
		        function() { $(this).addClass('ui-state-hover'); },
		        function() { $(this).removeClass('ui-state-hover'); }
		    );

		    //Create the progress slider control
		    simpleControl.progress.slider({
		        
		        animate: "slow",
		        max: 100,
		        range: "min",
		        step: 0.1,
		        value : 0,
		        
		        slide: function(event, ui) {
		            
		            var sp = simplePlayerData.status.seekPercent;
		            
		            if(sp > 0) {
		                
		                //Apply a fix to mp4 formats when the Flash is used.
		                if(fixFlash_mp4) {
		                    
		                    ignore_timeupdate = true;
		                    clearTimeout(fixFlash_mp4_id);
		                    
		                    fixFlash_mp4_id = setTimeout(function() {
		                        ignore_timeupdate = false;
		                    },1000);
		                }
		                
		                //Move the play-head to the value and factor in the seek percent.
		                $scope.simplePlayerObj.jPlayer("playHead", Number(ui.value).toFixed(2) * (100 / sp));

			        } else {
		                //Create a timeout to reset this slider to zero.
		                setTimeout(function() {
		                    simpleControl.progress.slider("value", 0);
		                }, 0);
		            }
		        	

		        }
		    });

		    //Create the volume slider control
		    simpleControl.volume.slider({
		        animate: "slow",
		        max: 1,
		        range: "min",
		        step: 0.01,
		        value : $.jPlayer.prototype.options.volume,
		        
		        slide: function(event, ui) {
		            $scope.simplePlayerObj.jPlayer("option", "muted", false);
		            $scope.simplePlayerObj.jPlayer("option", "volume", ui.value);
		        }
		    });

		    /*--------------- simple end ----------------------------------------*/
		    
		    

		    
		    /*
			    * jQuery UI ThemeRoller
			    *
			    * Includes code to hide GUI volume controls on mobile devices.
			    * ie., Where volume controls have no effect. See noVolume option for more info.
			    *
			    * Includes fix for Flash solution with MP4 files.
			    * ie., The timeupdates are ignored for 1000ms after changing the play-head.
			    * Alternative solution would be to use the slider option: {animate:false}
		    */

		    $scope.customPlayerObj = $("#jquery_jplayer_1");

		    var customPlayerData,
		        fixFlash_mp4, 				//Flag: The m4a and m4v Flash player gives some old currentTime values when changed.
		        fixFlash_mp4_id, 			//Timeout ID used with fixFlash_mp4
		        ignore_timeupdate, 			//Flag used with fixFlash_mp4
		        
		        options = {
		            ready: function (event) {
		                
		                //Hide the volume slider on mobile browsers. ie., They have no effect.
		                if(event.jPlayer.status.noVolume) {
		                    //Add a class and then CSS rules deal with it.
		                    $(".volume_part").addClass("jp-no-volume");
		                }

		                //Determine if Flash is being used and the mp4 media type is supplied. BTW, Supplying both mp3 and mp4 is pointless.
		                fixFlash_mp4 = event.jPlayer.flash.used && /m4a|m4v/.test(event.jPlayer.options.supplied);
		            
		            },

		            seeked: function(event){
		            	$scope.disableEnablePlay('custom','enable');
		            	if($scope.payerStatus == 'playing')
		            		$scope.customPlayerObj.jPlayer("play");
		        	},
		            
		            timeupdate: function(event) {

		                var obj = event.jPlayer.status.media;
		                if(!$.isEmptyObject(obj)){
			            	$scope.currentPlayerPosition  = Number(event.jPlayer.status.currentPercentAbsolute).toFixed(2);
			            }
	                	var width = (parseFloat($scope.loopEndPercentage) >= parseFloat($scope.currentPlayerPosition)) ? parseFloat($scope.currentPlayerPosition) : parseFloat($scope.loopEndPercentage);
	                	$( ".custombuffer" ).css('width', width+'%');	
		                if(parseFloat($scope.currentPlayerPosition) >= parseFloat($scope.loopEndPercentage)) {
		                	
		                	if($scope.payerStatus == 'playing') {
		                		$scope.customPlayerObj.jPlayer("pause");
			                    setTimeout(function(){ 
		                    		$scope.payerStatus = 'playing';
			                    	$scope.customPlayerObj.jPlayer("playHead",$scope.loopStartPercentage);
			                    }, $scope.pauseTime);	
		                	}
		                } 
		                
		            },
		            
		            pause: function(event) {
                		$scope.payerStatus  = 'paused';
		            },
		            
		            click: function(event) {
		            	//console.log("Ajay Here Click Event");
		            },

		            play: function(event){
			        	//$scope.customPlayerObj.jPlayer("playHead",($scope.currentPlayerPosition < $scope.loopStartPercentage) ? $scope.loopStartPercentage : $scope.loopStartPercentage);
	                	$scope.updateLastPlayedPiece();
			        },

			        playing: function(event){
		            	$scope.payerStatus  = 'playing';
			        	$scope.disableEnablePlay('custom','enable');
			        },


		            ended: function(event) {
		                $scope.customPlayerObj.jPlayer("playHead", $scope.loopStartPercentage);
		            },
		            
		            volumechange: function(event) {
		                if(event.jPlayer.options.muted) {
		                    customControl.volume.slider("value", 0);
		                } else {
		                    customControl.volume.slider("value", event.jPlayer.options.volume);
		                }
		            },

		            suspend: function(event){
		            	//alert(123)
		            },
		            
		            swfPath: "../../dist/jplayer",
		            supplied: "m4a, oga",
		            cssSelectorAncestor: "#jp_container_1",
		            wmode: "window",
		            keyEnabled: true,
		            preload:"auto",
		            keyBindings: {
					  	play: {
					    	key: 32, //Spacebar
					    	fn: function(f) {
					      		if(f.status.paused) {
					        		f.play();
					      		} else {
					        		f.pause();
					      		}
					    	}
					  	},
					}
		            
		        },
		        customControl = {
		            progress: $(options.cssSelectorAncestor + " .jp-progress-slider"),
		            volume: $(options.cssSelectorAncestor + " .jp-volume-slider")
		        };

		    
		    //Instance jPlayer
		    $scope.customPlayerObj.jPlayer(options);

		    
		    //A pointer to the jPlayer data object
		    customPlayerData = $scope.customPlayerObj.data("jPlayer");

		    // Define hover states of the buttons
		    $('.jp-gui ul li').hover(
		        function() { $(this).addClass('ui-state-hover'); },
		        function() { $(this).removeClass('ui-state-hover'); }
		    );

		    //Create the progress slider control
		    customControl.progress.slider({
		        
		        animate: "slow",
		        range: true,
		        max: 100,
		        step: 0.01,
		        values: [$scope.loopStartPercentage,$scope.loopEndPercentage],
		        
		        slide: function(event, ui) {
		            
		        	//$scope.currentPlayerPosition  = Number(customPlayerData.status.currentPercentAbsolute).toFixed(2);
		            var sp = customPlayerData.status.seekPercent;

		            if(sp > 0) {
		                
		                //Apply a fix to mp4 formats when the Flash is used.
		                if( fixFlash_mp4 ) {
		                    
		                    ignore_timeupdate = true;
		                    clearTimeout(fixFlash_mp4_id);
		                    
		                    fixFlash_mp4_id = setTimeout(function() {
		                        ignore_timeupdate = false;
		                    },1000);
		                }
		                
		                //define startSliderTime and endSliderTime
		                //jump to song at startSliderTime
		                var previousStartPercentage 	= $scope.loopStartPercentage;
		                var previousEndPercentage     	= $scope.loopEndPercentage; 

		                $scope.loopStartPercentage 		= Number(ui.values[0]).toFixed(2);
		                $scope.loopEndPercentage 		= Number(ui.values[1]).toFixed(2);

		                //console.log("Ajay currentPlayerPosition :: " + $scope.currentPlayerPosition + " Ajay loopStartPercentage :: " + $scope.loopStartPercentage * (100 / sp));
		                //console.log("Ajay Start Slide :: " + $scope.loopStartPercentage + " Ajay End slide :: " + $scope.loopEndPercentage);
						
						if((previousStartPercentage != $scope.loopStartPercentage)) {
							
							//console.log("Ajay Current :: " + $scope.currentPlayerPosition +"  new One :: "+ $scope.loopStartPercentage);
							if(parseFloat($scope.currentPlayerPosition) < parseFloat($scope.loopStartPercentage)) {
								
								if($scope.payerStatus == 'playing') {
									
									$scope.customPlayerObj.jPlayer("pause");
									$( ".custombuffer" ).css('width', $scope.loopStartPercentage+'%');
									
									//$scope.payerStatus = 'playing';
									//$scope.customPlayerObj.jPlayer("playHead", $scope.loopStartPercentage * (100 / sp));
									$scope.customPlayerObj.jPlayer("playHead", $scope.loopStartPercentage * (100 / sp)).jPlayer("play");
								
								} else {
								
									$( ".custombuffer" ).css('width', $scope.loopStartPercentage+'%');
									$scope.customPlayerObj.jPlayer("playHead", $scope.loopStartPercentage * (100 / sp));
								
								}
							
							} else if($scope.payerStatus == 'paused') {
								
								$( ".custombuffer" ).css('width', $scope.loopStartPercentage+'%');
								$scope.customPlayerObj.jPlayer("playHead", $scope.loopStartPercentage * (100 / sp));
							
							}
						}

		            } else {
		                
		                //Create a timeout to reset this slider to zero.
		                setTimeout(function() {
		                    //customControl.progress.slider("values", 0);
		                    customControl.progress.slider("option", "values", [0,20]);
		                }, 0);
		            }
		        },
		        
		        change:function(event, ui){
	            	
	            	if((parseFloat($("#startPoint").val()) != parseFloat($scope.loopStartPercentage)) || (parseFloat($("#endPoint").val()) != parseFloat($scope.loopEndPercentage))){
	            		$scope.updateStartEndTime();
		            	$("#startPoint").val($scope.loopStartPercentage);
						$("#endPoint").val($scope.loopEndPercentage);
	            	}
                }
		    



		    });

		    //Create the volume slider control
		    customControl.volume.slider({
		        
		        animate: "slow",
		        max: 1,
		        range: "min",
		        step: 0.01,
		        value : $.jPlayer.prototype.options.volume,
		        slide: function(event, ui) {
		            $scope.customPlayerObj.jPlayer("option", "muted", false);
		            $scope.customPlayerObj.jPlayer("option", "volume", ui.value);
		        }
		    });

		    jQuery( "#jp_container_1 .jp-progress-slider .ui-slider-range" ).after( "<div class='custombuffer' style='overflow: hidden;'></div>" );
		    
		    

		    /*--------------- custom mode end----------------------------------------*/
		    //on Mode change event - interchange simple & custom players
		    $( "#doCustomeMode" ).bind( "click", function() {

		    	$scope.disableEnablePlay('custom','disable');

				$scope.currentPlayerPosition = $scope.loopStartPercentage;
				$scope.setPlayer($scope.customPlayerObj,$scope.loopStartPercentage);
		        $("#customSlider").addClass("meter red");
		        
		        $scope.playerType = 'custome';
		        $scope.simplePlayerObj.jPlayer("stop");
		        $scope.payerStatus  = 'paused';

	            jQuery("#simpleMode").hide();   
	            jQuery("#customMode").show();
					
		    });

		    
		    $( "#doSimpleMode" ).bind( "click", function() {

				$scope.disableEnablePlay('simple','disable');

    			$scope.setPlayer($scope.simplePlayerObj,0);
    			$("#slider").slider("option", "value",0);
	            $("#slider").addClass("meter red");

	            $scope.playerType = 'simple';
		        $scope.customPlayerObj.jPlayer("stop");
		        $scope.payerStatus  = 'paused';

	            jQuery("#customMode").hide();
	            jQuery("#simpleMode").show();
	
		    });

		    
			$(function() {
	          	$( "#slider" ).slider();
	        });

	        $(function() {
	          	$( "#customSlider" ).slider();
	        });
		
		

	        /*(function($) {
			  	$.fn.nodoubletapzoom = function() {
			    	
			    	$(this).bind('touchstart', function preventZoom(e) {
			        	var t2 = e.timeStamp
			          	, t1 = $(this).data('lastTouch') || t2
			          	, dt = t2 - t1
			          	, fingers = e.originalEvent.touches.length;
			        	
			        	$(this).data('lastTouch', t2);
			        	if (!dt || dt > 500 || fingers > 1) return; // not double-tap

			        	e.preventDefault(); // double tap - prevent the zoom
			        	//also synthesize click events we just swallowed up
			        	$(this).trigger('click').trigger('click');
			     	});
			  	};
			})(jQuery);*/


			/*$('.no-zoom').bind('touchend', function(e) {
  				//alert(123);
  				e.preventDefault();
  				//Add your code here.
			});*/

			$('.no-zoom').bind('touchstart', function preventZoom(e) {
		        
		        var t2 = e.timeStamp
		          	, t1 = $(this).data('lastTouch') || t2
		          	, dt = t2 - t1
		          	, fingers = e.originalEvent.touches.length;
		        	
		        	$(this).data('lastTouch', t2);
		        	if (!dt || dt > 500 || fingers > 1) return; // not double-tap

		        	e.preventDefault(); // double tap - prevent the zoom
		        	//also synthesize click events we just swallowed up
		        	$(this).trigger('click').trigger('click');
	     	});
			/*-------------------END Script for player -------------------------------*/
	
	}
]);