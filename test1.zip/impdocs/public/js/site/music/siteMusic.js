'use strict';

var siteMusicModule = angular.module("siteMusic",['ngRoute','ngResource','ngMessages']);

siteMusicModule.config(['$routeProvider',
    function($routeProvider) {
        
        $routeProvider.when("/music/:favtxt", {
            resolve:{loggedIn:onlyLoggedInMusic},
            templateUrl: "templates/site/partials/music/musicLibrary.html"
        });
        
        $routeProvider.when("/music", {
        	resolve:{loggedIn:onlyLoggedInMusic},
        	templateUrl: "templates/site/partials/music/musicLibrary.html"
        });

        
    }
]);

var onlyLoggedInMusic = function ($location,$q,siteAuth, $http, $filter) {
    
    var deferred = $q.defer();
    siteAuth.isLoggedInAsync(function(loggedIn) {
        
        if (loggedIn) {
	        
            var usersession = siteAuth.getCurrentUser();
            var user_id = usersession.id;
            var useridobj = {
                user_id     : user_id
            }
            
            $http.post('/api/site/getuser',useridobj).success(function(response) {
                if(response.id) {
                    
                    var today           = new Date();
                    var todayDate       = $filter('date')(today, "yyyy-MM-dd");
                    var memberEndDate   = new Date(response.Subscriptions[0].endAt);
                    var memberEndDate   = $filter('date')(memberEndDate, "yyyy-MM-dd");
                    
                    if(todayDate > memberEndDate) {
                        $location.path('/');
                    }   
                }   
            });     
            
            deferred.resolve();
	    
        } else {
	        
            deferred.reject();
	        $location.path('/');
	    
        }
	});
    return deferred.promise;
};
