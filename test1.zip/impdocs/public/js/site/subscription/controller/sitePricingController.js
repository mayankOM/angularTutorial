'use strict';

//Define App module
var Subscription = angular.module("siteSubscription");

Subscription.controller('planPriceController', ["$rootScope","$scope","$timeout","$location", "$http",'$routeParams','siteAuth', '$localStorage',
	
	function($rootScope, $scope, $timeout, $location, $http , $routeParams ,siteAuth, $localStorage) {

		var fullYear = [];
		var curYear = new Date().getFullYear();
		var startYear = curYear;
		var crYear = curYear+25;
		$scope.amt = "";
		
		for (var i=startYear; i<=crYear; i++) {
	    	var newarray = {
	    		'value' : i,
	    		'year' : i 
	    	};
			fullYear.push(newarray);
		}
		
		$scope.creaditcardYear = fullYear;
		$scope.cc_month = '01';
		$scope.cc_Year = curYear;
		$scope.cardtype = 'visa';
		$scope.terms_c = false;

		/**  Init function on Plans page **/
		$rootScope.setPlans = function () {
			
			$scope.planlist = '';
			$http.post('/api/site/getPlandetails','').success(function(response) {
				
				$scope.planlist = response;
				$scope.selectedLang = $localStorage.langSelected;
				
				//console.log($scope.selectedLang);
			
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/**  Check authentication and redirect on Subscription payment process page **/
		$scope.setPrice = function (planid) {
			
			if(siteAuth.getCurrentUser()) {
				$location.path('/subscriptions/'+planid);
			} else {
				if(confirm("Please login or create a new account. Thank you")){
					$location.path("/");	
				}
			}	
		
		};

		/**  Init function on Subscription page **/
		$scope.setvalue = function () {
			
			$scope.isDisable 			= 0;
			$scope.selectedplan 		= $routeParams.planid;
			$scope.userAuthenticated 	= $rootScope.userAuthenticated;
			
			var planObj = {
				planid: $scope.selectedplan
			};
			
			$http.post('/api/site/getPlan' , planObj).success(function(response) {
				$scope.plandata = response;
			}).error(function(response) {
				$scope.error = response.message;							
			});
		};

		/**  Get a list Of Subscription log report  **/
		$scope.getSubLogList = function () {

			var usersession = siteAuth.getCurrentUser();
			var user_id = usersession.id;
			var useridobj = {
				user_id		: user_id
			}
			$http.post('/api/site/getSubLog' , useridobj).success(function(response) {
				
				//console.log(response);

				$scope.planStatus = response.planStatus;
				$scope.subscriptionStatus = response.subscriptionStatus;
				var index = response.subscriptionStatus.length - 1;
				//response.subscriptionStatus[index];

				$scope.subLastLog = response.subscriptionStatus[index];
				
			}).error(function(response) {
				$scope.error = response.message;							
			});
		};


		/**  Cancel Recursive Subscription?  **/
		$scope.cancelRecSub = function (profileID, transactionID) {

			console.log(profileID);
			console.log(transactionID);


			var usersession = siteAuth.getCurrentUser();
			var user_id = usersession.id;
			var useridobj = {
				profileID			: profileID,
				transactionID		: transactionID,
				action  			: 'cancel'
			}
			$http.post('/api/site/cancelSubscription' , useridobj).success(function(response) {
				console.log(response);

				/*$scope.planStatus = response.planStatus;
				$scope.subscriptionStatus = response.subscriptionStatus;*/

			}).error(function(response) {
				$scope.error = response.message;							
			});
		};

			

		


		/* redirect back to Subscription Plan page */
		$scope.cancelSubscription = function () {
			$location.path("/plans");
		};

		/*** Plan Subscription ***/
		$scope.subscription = function () {
			$scope.isDisable = 1;
			if (typeof $scope.terms_c == 'undefined' || $scope.terms_c == false ) {

				$scope.error = [{"msg":"Please Select Terms & Condition"}];
				$scope.isDisable = 0;

			} else {
			
				

				var planid = $routeParams.planid;
				
				var cardtype = $scope.cardtype;
			
				var cc_month = $scope.cc_month;
				var cc_Year = $scope.cc_Year;
				var firstname = $rootScope.userAuthenticated.firstname;
				var  lastname = $rootScope.userAuthenticated.lastname;
				var cvv = $scope.cvv;
				if (typeof $scope.cvv == "undefined" || $scope.cvv == null) {
					$scope.error = [{"msg":"Please Enter CVV number"}];
					$scope.isDisable = 0;					
					return false;
				} else {
					var card_number = $scope.cvv;	
				}
				if (typeof $scope.card_number == "undefined" || $scope.card_number == null) {
					$scope.error = [{"msg":"Please Enter credit card number"}];
					$scope.isDisable = 0;					
					return false;
				} else {
					var card_number = $scope.card_number;

				}
			
				var amount = $scope.plandata.price;
				var plan_name = $scope.plandata.name;
				var plan_description = $scope.plandata.description;
				var plan_periodicity = $scope.plandata.periodicity;
				
				if (planid == 1 ) {
		  			var billing_period  = "Month";
		  			var billingfrequency = "6";
		  		} else if (planid == 2) {
		  			var billing_period  = "Year";
		  			var billingfrequency = "1";

		  		} else {
	  				$scope.error = "Please select Proper Plan";
	  				$scope.isDisable = 0;
	  				return false;
		  		}

		  		//For testing purpose
		  		//billing_period 		= "Day";
		  		//billingfrequency 	= "1";


		  		var expire_date = $scope.cc_month + $scope.cc_Year;
		  		var time = new Date();

				var dataObj = {
					creditcardtype					: cardtype,  					
					acct 							: card_number,
					expdate 						: expire_date,
					firstname 						: firstname,
					lastname 						: lastname,
					
					BILLINGPERIOD 					: billing_period,
					BILLINGFREQUENCY 				: billingfrequency,
					
					PROFILESTARTDATE 				: time,
					AMT 							: amount,
			   		DESC 							: 'A subscription at Om',
			   		L_BILLINGAGREEMENTDESCRIPTION0 	: "A description of this subscription",
					L_BILLINGTYPE0 					: "RecurringPayments",
					plan_id 						: planid,
					CVV2 							: cvv,
					plan_name 						: plan_name,
					plan_description 				: plan_description,
					plan_periodicity 				: plan_periodicity
				};

				$http.post('/api/site/payment' , dataObj).success(function(response) {
					
					if(response.status == 'Success') {
					
						$scope.success = [{ "msg" : "You Subscribed Successfully." }];
						$scope.error = "" ;	
					
					} else {
						
						$scope.isDisable = 0;
						$scope.error = [{ "msg" : response.longmessage }];
						$scope.success = "" ;		
					}	
				
				}).error(function(response) {
					$scope.isDisable = 0;
					$scope.error = response.status;
					$scope.success = "";
				});
			}  			
		};

		/* End subscription function */ 
		
		/*Nevigate on Plan page*/
		$scope.getPlans = function() {
			$location.path("/plans");
		};
	}
]);


/*angular.module('siteSubscription').directive
  	( 'creditCardType'
  	, function(){
    	var directive = { require: 'ngModel'
        	
        	, link: function(scope, elm, attrs, ctrl){
            	ctrl.$parsers.unshift(function(value){
              		scope.ccinfo.type =
                	(/^5[1-5]/.test(value)) ? "mastercard"
                	: (/^4/.test(value)) ? "visa"
                	: (/^3[47]/.test(value)) ? 'amex'
                	: (/^6011|65|64[4-9]|622(1(2[6-9]|[3-9]\d)|[2-8]\d{2}|9([01]\d|2[0-5]))/.test(value)) ? 'discover'
                	: undefined
              		ctrl.$setValidity('invalid',!!scope.ccinfo.type)
              		
              		return value
            	})
          	}
        }
      	return directive
    }
)

angular.module('siteSubscription').directive
  	( 'cardExpiration'
  	, function(){
      	var directive = { require: 'ngModel'
        	, link: function(scope, elm, attrs, ctrl){
	            scope.$watch('[ccinfo.month,ccinfo.year]',function(value){
	            	ctrl.$setValidity('invalid',true)
	              	if ( scope.ccinfo.year == scope.currentYear && scope.ccinfo.month <= scope.currentMonth ) {
	                	ctrl.$setValidity('invalid',false)
	              	}
	              	return value
	            },true)
        	}
        }
      	return directive
    }
)

angular.module('siteSubscription').filter
  	( 'range'
  	, function() {
      	var filter = function(arr, lower, upper) {
          	for (var i = lower; i <= upper; i++) arr.push(i)
          	return arr
        }
      	return filter
    }
);*/