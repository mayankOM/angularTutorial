	'use strict';

//Define App module
var siteMusicLibrary = angular.module("siteMusicLibrary");
	
siteMusicLibrary.controller('siteMusicLibraryController', ["$scope","$timeout", "$route", "$location", "$http", "siteAuth",
	function($scope, $timeout, $route, $location, $http, siteAuth) {
		console.log("---	Welcome to music library----");

		/*
			Module : MusicLibrary
			Author : Mayank [SOFTWEB]
			Inputs : 
			Output : List of Basic data [Library List, Instrument List]
			Date   : 2015-10-28
		*/
		$scope.getMuscilibrary = function() {

			$scope.instruments = '';
			$scope.instrumentsList = '';
			
			$http.get('/api/site/listinstruments').success(function(response) {
				$scope.instrumentsList = response.data;	
			}).error(function(response) {
				$scope.error = response.message;
			});

			$scope.libraries = '';
			$http.get('/api/site/listlibraries').success(function(response) {
				$scope.librariesList = response.data;	
			}).error(function(response) {
				$scope.error = response.message;
			});


			$scope.instruments = '';
			$scope.instrumentsList = '';
			$http.get('/api/site/listMuscilibrary').success(function(response) {
					
				if(response.status == 'succ')
				{
					//Pagination param
					$scope.currentPage = 1;
	  				$scope.pageSize = 10;
					$scope.MuscilibraryList = response.data;

					console.log($scope.MuscilibraryList);

				}	
				else
				{
					$scope.error = response.data.err;
				}	
			}).error(function(response) {
					$scope.error = response.data.err;
			});

		};

		/*
			Module : MusicLibrary
			Author : Mayank Patel [SOFTWEB]
			Inputs : Search Keyword, InstrumentID or LibraryID
			Output : List of searched Pieces (Musci Library)
			Date   : 2015-10-28
		*/
		$scope.searchData = function() {

			console.log($scope.search);
			$scope.instruments = '';
			$scope.instrumentsList = '';
			$http.post('/api/site/listFilteredMuscilibrary',$scope.search).success(function(response) {
				if(response.status == 'succ')
				{
					//Pagination param
					$scope.currentPage = 1;
	  				$scope.pageSize = 10;
					$scope.MuscilibraryList = response.data;
				}	
				else
				{
					$scope.error = response.data.err;
				}	
			}).error(function(response) {
					$scope.error = response.data.err;
			});
		};
	}
]);