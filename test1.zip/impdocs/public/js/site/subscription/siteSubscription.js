'use strict';

var siteSubscription = angular.module("siteSubscription",['ngRoute','ngResource','ngMessages']);
siteSubscription.config(['$routeProvider',
    function($routeProvider) {
        
        $routeProvider.when("/plans", {
        	resolve:{loggedInUser:loadLoggedInUser},
            templateUrl: "templates/site/partials/subscription/plan.html"
        });
        $routeProvider.when('/subscriptions/:planid', {
            resolve:{loggedIn:onlyLoggedIn},
            templateUrl: 'templates/site/partials/subscription/subscriptions.html'
        });
        $routeProvider.when('/subscriptionsLog', {
        	resolve:{loggedIn:onlyLoggedIn},
        	templateUrl: 'templates/site/partials/subscription/subscriptionLog.html'
        });
    }
]);