/**
	* Main AngularJS Web Application
*/

var app = angular.module('userModule', [
  	'ngRoute',
]);

app.config(['$routeProvider', function ($routeProvider) {

  	$routeProvider.when("/userProfile", {
  		resolve:{loggedIn:onlyLoggedIn},
  		templateUrl: "templates/site/partials/home/edit_profile.html"
  	});
}]);

var onlyLoggedIn = function ($location,$q,siteAuth) {
    var deferred = $q.defer();
    siteAuth.isLoggedInAsync(function(loggedIn) {
		console.log(loggedIn);
		if (loggedIn) {
	        deferred.resolve();
	    } else {
	        deferred.reject();
	        $location.url('/');
	    }
	});
    return deferred.promise;
};