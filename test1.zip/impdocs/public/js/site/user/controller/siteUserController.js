'use strict';

//Define App module
var siteMusicLibrary = angular.module("userModule");

siteMusicLibrary.controller('siteUserController', ["$scope","$timeout", "$route", "$location", "$http","siteAuth", "Upload",
	function($scope, $timeout, $route, $location, $http, siteAuth, Upload) {
		
		$scope.isDisable = 0;		
		$scope.userAuthenticated = "";
		$scope.UserProfilePicture = "";

		/*Get a list of days as per selected Month and Year*/
		$scope.getDaysArray = function() {
			var month = $scope.birthdayMonth;
			var year = $scope.birthdayYear;
			$scope.getDays(month, year);
		}
		$scope.signup = function() {
			$location.path("/signup");
		};

		/*Function for calculating days of month as per selected month and year*/
		$scope.getDays = function(month, year) {
			
		  	if(month == '01' || month == '03' || month == '05' || month == '07' || month == '08' || month == '10' ||  month == '12') {
		  		var startDay = 1;
		  		var endDay = 31;
			} else if(month == '04' || month == '06' || month == '09' || month == '11') {
				var startDay = 1;
		  		var endDay = 30;
			} else if(month == '02') {
				
				if ((parseInt(year)%4) == 0) {
					if (parseInt(year)%100 == 0) {
						if (parseInt(year)%400 == 0) {
							var startDay = 1;
	  						var endDay = 29;
						} else {
							var startDay = 1;
	  						var endDay = 28;
						}	
					} else {
						var startDay = 1;
  						var endDay = 29;
					}
				} else {
					var startDay = 1;
					var endDay = 28;
				}
			} else {
				var startDay = 1;
		  		var endDay = 31;
			}

		  	var fullDay = [];
		    for (var i = startDay; i <= endDay; i++) {

		    	if(i<=9)
		    		i = '0'+i;

		    	var newarray = {
		    		'value' : i,
		    		'day' : i 
		    	};
				
				fullDay.push(newarray);
		    }
		    $scope.bDay = fullDay;

		    //New Code
		    //console.log("Date => "+parseInt($scope.birthdayDay)+"End day => "+parseInt(endDay))
			$scope.birthdayDay = (parseInt($scope.birthdayDay) > parseInt(endDay)) ? '01' : $scope.birthdayDay;
			$("#birthDate span.customSelectInner").html($scope.birthdayDay);
		};

		/* Get a profile data of current logged in user */
		$scope.getProfileData = function() {
			
			if(siteAuth.getCurrentUser()) {
				
				$scope.countryList = siteAuth.countryList();

				var usersession = siteAuth.getCurrentUser();
				var user_id = usersession.id;
				var useridobj = {
					user_id		: user_id
				}

				// Get list of secret Questions
				$scope.secretQuestion = '';
				$http.post('/api/site/listsecretquestions','').success(function(response) {
					$scope.secretQuestion = response;	
				}).error(function(response) {
					$scope.error = response.message;
				});

				$http.post('/api/site/getuser',useridobj).success(function(response) {
					
					$scope.userAuthenticated = response;

					
					/*console.log("Here =================================================== >>>>>");
					console.log(response);
					console.log("Here =================================================== >>>>>");

					//$scope.userAuthenticated = usersession;
					$scope.userAuthenticated.password = "";
					
				  	console.log("Here eeeeee eeeeee eeeee => " + $scope.parseISODate("1969-12-13").getDay());
				  	var d = new Date($scope.userAuthenticated.birthday);
				  	//var d = new Date("January 13, 2014 11:13:00");
				  	console.log("Here =================================================== >>>>>");
					//console.log("Value Fron database  => "+ "January 13, 2014 11:13:00");
					console.log("Value Fron database  => "+ $scope.userAuthenticated.birthday);
					console.log("Here =================================================== >>>>>");
				  	
				  	console.log("Here =================================================== >>>>>");
					console.log("Day => "+ d.getDate() + " Month => " + d.getMonth() + " Year => " + d.getFullYear());
					console.log("Here =================================================== >>>>>");*/

				  	/*$scope.birthdayYear = d.getFullYear();
				  	if(d.getDate() < 10){
				  		$scope.birthdayDay = ("0" + (d.getDate()+1)).slice(-2);	
				  	} else {
				  		$scope.birthdayDay = (d.getDate()+ 1);	
				  	}
				  	$scope.birthdayMonth = ("0" + (d.getMonth() + 1)).slice(-2);*/

				  	//console.log("Value Fron database  => "+ $scope.userAuthenticated.birthday);
				  	
				  	var arrayYear 	= $scope.userAuthenticated.birthday.split('T');
				  	var fullDate   	= arrayYear[0].split('-') 
				  	
				  	//console.log(fullDate);

				  	$scope.birthdayYear 	= parseInt(fullDate[0]);
				  	$scope.birthdayMonth    = fullDate[1];
				  	$scope.birthdayDay 		= (parseInt(fullDate[2]) < 10) ?  ("0" + (fullDate[2])).slice(-2) : parseInt(fullDate[2]);


					var curYear = new Date().getFullYear();
				  	var startYear = 1900;

				    $scope.gender = $scope.userAuthenticated.gender;
				    $scope.country = $scope.userAuthenticated.country;
				    
				    $scope.questionId = $scope.userAuthenticated.questionId;
				  	
				  	var fullYear = [];
				    for (var i = startYear; i <= curYear; i++) {

				    	var newarray = {
				    		'value' : i,
				    		'year' : i 
				    	};

						fullYear.push(newarray);
				    }
				    $scope.bYear = fullYear;

				    
				    /*console.log("Here =================================================== >>>>>");
					console.log("Day => "+ $scope.birthdayDay + " Month => " +$scope.birthdayMonth + " Year => " +$scope.birthdayYear);
					console.log("Here =================================================== >>>>>");*/

				    //Call function for get proper number of day for date selection
				    $scope.getDays($scope.birthdayMonth, $scope.birthdayYear);
				    				
					$scope.change_pw = 0;
				}).error(function(response) {
					$scope.error = response.message;
				});    

				
			} else {
				$scope.userAuthenticated = "";
				$location.path("/");
			}	
		};


		
		$scope.parseISODate = function (s){
  			var b = s.split(/\D/);
  			var d = new Date();
  			d.setHours(0,0,0,0);
  			d.setFullYear(b[0], --b[1], b[2]);
  			return d.getFullYear() == b[0] && d.getDate() == b[2]? d : NaN;
		}

		
		/* Update user profile */
		$scope.updateProfile = function() {
			$scope.isDisable = 1;
			if($scope.birthdayYear != "" && $scope.birthdayYear != undefined && $scope.birthdayMonth != "" && $scope.birthdayMonth != undefined && $scope.birthdayDay != "" && $scope.birthdayDay != undefined ) {
				var birthday = $scope.birthdayYear+"-"+$scope.birthdayMonth+"-"+$scope.birthdayDay;	
			} else {
				$scope.error = [{ "msg" : "Date is Required" }];
				$scope.isDisable = 0;
				return false;
			}
			
			$scope.userAuthenticated.gender = $scope.gender
			$scope.userAuthenticated.country = $scope.country
			$scope.userAuthenticated.birthday = birthday;
			$scope.userAuthenticated.questionId = $scope.questionId;
			$scope.userAuthenticated.change_pw = $scope.change_pw;

			if($scope.userAuthenticated.change_pw == 1) {
				$scope.userAuthenticated.password = $scope.password;
			}	
				
			$http.post('/api/site/updateuser',$scope.userAuthenticated).success(function(response) {
				
				if(response.status == 'success') {	
					$scope.success = [{ "msg" : "Your profile information updated successfully." }];
					$scope.error = "" ;
					setTimeout(function(){
						$route.reload();
					},2000);
				
				} else {
					
					if(response.status == 'fail') {
						$scope.isDisable = 0;
						$scope.error = [{"msg":"Failed to update your profile information"}];
						$scope.success = "";
						setTimeout(function(){
							$route.reload();
						},2000);
					
					} else {
						$scope.isDisable = 0;
						$scope.error = response.status;
						$scope.success = "";
					}
				}	
			}).error(function(response) {
				$scope.isDisable = 0;
				$scope.error = response.message;
			});
		};

		/* Cancel the transaction and load homepage */
		$scope.cancel = function() {
			$location.path("/");
		};

		/* Redirect to Registration page */
		$scope.signup = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/signup");
		};

		/* Upload user profile picture */
		$scope.uploadFiles = function(file, errFiles) {
	       	var usersession = siteAuth.getCurrentUser();
			var user_id = usersession.id;

	        if (file) {
	            file.upload = Upload.upload({
	                url: '/api/site/imageUpload',
	                data: {file: file, user_id : user_id}
	            });
	            file.upload.then(function (response) {
	            	
	            	if(response.data.status == "succ") {
	            		$scope.userAuthenticated.profilePicture = response.data.filename;
	            		$route.reload();
	            	} else {
	            		$scope.UserProfilePicture = "";
	            	}	
	            
	            }, function (response) {
	            	$scope.error = response.status + ': ' + response.data;
	            }, function (evt) {
	                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
	            });
	        }   
	    };


	    
	    /*$scope.$watch(attrs.pristine, function() {
		   	
		   	$timeout(function() {
		    	alert(123);
		    	//element.multiselect('refresh');
		      	//element.multiselectfilter("updateCache");
		   	});
		
		});*/
	
	}
]);

siteHomepage.directive('matchPassword', function() {
  return {
    restrict: 'A',
    require: ['^ngModel', '^form'],
    link: function(scope, element, attrs, ctrls) {
      var formController = ctrls[1];
      var ngModel = ctrls[0];
      var otherPasswordModel = formController[attrs.matchPassword];
  
      ngModel.$validators.passwordMatch = function(modelValue, viewValue) {
        var password = modelValue || viewValue;
        var otherPassword = otherPasswordModel.$modelValue || otherPasswordModel.viewValue;
        //console.log('modelValue || viewValue', password, otherPassword);
        return password === otherPassword;
      };

    } // end link
  }; // end return
});
siteHomepage.directive('uniqueEmailEdit', function($http, $q, siteAuth) {

  return {
    require : 'ngModel',
    link : function($scope, element, attrs, ngModel) {
      ngModel.$asyncValidators.uniqueEmailEdit = function(modelValue, viewValue) {
        var email = modelValue || viewValue;
        var userdata = siteAuth.getCurrentUser();
		var user_id = userdata.id;
        return $http.post('/api/site/uniqueEmailEdit', {email : email, user_id : user_id}).then(function(res) {
          if (res.data.exists == 'true') {
            return $q.reject();
          }
          return $q.when();
        });
      }; // end async
    } // end link
  }; // end return 
});

siteHomepage.directive('errSrc', function() {
  return {
    link: function(scope, element, attrs) {

      scope.$watch(function() {
          return attrs['ngSrc'];
        }, function (value) {
          if (!value) {
            element.attr('src', attrs.errSrc);  
          }
      });

      element.bind('error', function() {
        element.attr('src', attrs.errSrc);
      });
    }
  }
});