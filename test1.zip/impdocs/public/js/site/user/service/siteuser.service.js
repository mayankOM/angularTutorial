'use strict';

angular.module('userModule').factory('siteUser', function ($http, $resource) {
    return {
	     getUser : function() {
	         return $http.get("/auth/getSession");
	     }
    };
});
