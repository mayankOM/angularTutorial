
angular.module('homePageModule').factory('siteAuth', function siteAuth($location, $http, $cookieStore, $q, $localStorage, $rootScope) {
    
    var currentUser = {};
    var getCookies = {};

    if($cookieStore.get('token')) {
        //currentUser = $sessionStorage.get('userSession');
        currentUser = $localStorage.localData;
    }

    return {

        /**
            * Authenticate user and save token
            *
            * @param  {Object}   user     - login info
            * @param  {Function} callback - optional
            * @return {Promise}
        */
        login: function(user, callback) {
            
            var cb = callback || angular.noop;
            var deferred = $q.defer();

            var rememberMe = user.rememberMe;
            var rememberEmail = user.email;
            var rememberPass = user.password;
            
            user.loginBy = 'site';
            
            $http.post("/api/site/auth/signin", user).success(function(data) {

                if(data.status == 'fail') {
                    deferred.reject({ status: "Login failed in res" });
                } else {

                    if(data.resetPassword == 'YES') {
                        deferred.resolve(data);
                        return cb(data);
                    } else {
                        
                        var rand = Math.random().toString(36).substr(2);  
                        $cookieStore.put('token', rand);

                        if(rememberMe == true) {
                            var obj = {
                                'rememberMe'    :   rememberMe,
                                'rememberEmail' :   rememberEmail,
                                'rememberPass'  :   rememberPass
                            };
                            
                            $http.post('/api/site/auth/enc',obj).success(function(response) {
                                
                                $cookieStore.put('setMe', rememberMe);
                                $cookieStore.put('cookieEmail', response.encEmail);
                                $cookieStore.put('cookiePassword', response.encPass);
                            
                            }).error(function(response) {
                            
                                $scope.error = response.message;
                            
                            });                        
                        
                        } else {
                            
                            $cookieStore.put('setMe', false);
                            $cookieStore.put('cookieEmail', '');
                            $cookieStore.put('cookiePassword', ''); 
                        
                        }

                        $localStorage.localData = data;
                        deferred.resolve(data);
                    
                    }
                }
                return cb();
            
            }).error(function(err) {
            
                this.logout();
                //$sessionStorage.remove('userSession');
                //$sessionStorage.empty();
                $localStorage.localData = '';
                $localStorage.$reset();
                deferred.reject(err);
                return cb(err);
            
            }.bind(this));
            return deferred.promise;
        },

        /**
            * Delete access token and user info
            *
            * @param  {Function}
        */
        
        logout: function() {
            
            $cookieStore.remove('token');
            //$sessionStorage.remove('userSession');
            //$sessionStorage.empty();
            $localStorage.localData = '';
            
            //$localStorage.$reset();
            currentUser = {};
            return $http.get("/api/site/auth/signout");
            //$location.path("");
        },

        /**
            * Gets all available info on authenticated user
            *
            * @return {Object} user
        */
        getCurrentUser: function() {
            //return currentUser = $sessionStorage.get('userSession');
            return currentUser = $localStorage.localData;
        },

        /**
            * Check if a user is logged in
            *
            * @return {Boolean}
        */
        isLoggedIn: function() {
            return currentUser.hasOwnProperty('role');
        },

        /**
            * Waits for currentUser to resolve before checking if user is logged in
        */
        isLoggedInAsync: function(cb) {
            
            if($localStorage.localData) {
                
                var usersession = $localStorage.localData;
                var useridobj   = {
                    user_id     : usersession.id
                }

                $http.post('/api/site/getuser',useridobj).success(function(response) {
                    $rootScope.userAuthenticated = response;
                    cb(true);
                }).error(function(response) {
                    cb(false);
                });

            } else {
                cb(false);
            } 
        },

        loadLogedInUser: function(cb) {
            
            if($localStorage.localData) {
                
                var usersession = $localStorage.localData;
                var useridobj   = {
                    user_id     : usersession.id
                }

                $http.post('/api/site/getuser',useridobj).success(function(response) {
                    $rootScope.userAuthenticated = response;
                    cb(true);
                }).error(function(response) {
                    $rootScope.userAuthenticated = '';
                    cb(true);
                });


            } else {
               $rootScope.userAuthenticated = '';
               cb(true);
            } 
        },

        /**
            * Check if a user is an admin
            *
            * @return {Boolean}
        */
        isAdmin: function() {
            return currentUser.isAdmin === true;
        },
        /**
            * Get auth token which is stored in cookie
        */
        getToken: function() {
            //console.log($cookieStore.get('token'));
            return $cookieStore.get('token');
        },

        /**
            * Get Cookies data
        */
        getCookies: function() {
            //console.log($cookieStore.get('token'));
            return getCookies = {
                'setMe' : $cookieStore.get('setMe'),
                'cookieEmail' : $cookieStore.get('cookieEmail'),
                'cookiePassword' : $cookieStore.get('cookiePassword')
            };
        },

        /**
            * Clear Browser console log
        */
        clearconsole: function() {
            if(window.console || window.console.firebug) {
                //console.clear();
            }
        },

        /**
        * Configuration for the social links
        */
        socialLinks: function() {
            
            return socialURL = {
                'youtube'   : "https://youtu.be/yeA96_GdAek",
                'twitter'   : "https://twitter.com/Om_App",
                'facebook'  : "https://www.facebook.com/OmMusic/"
            };
        },

        /**
            * Important configuration text
        */
        impConfig: function() {
            return impconfig = {
                'organizationName'     : "Om Music, LLC",
                'websiteURL'           : "http://www.accompanymusic.com/",
                'supportEmail'         : "accompanymusicapp@gmail.com",
                'currentYear'          : new Date().getFullYear(),
            };
        },

        /**
            * Language list
        */
        langList: function() {
            return lang = [
                { 'value' : 'en', 'lbl' : 'English'},
                { 'value' : 'fr', 'lbl' : 'Français'},
                { 'value' : 'es', 'lbl' : 'Español'},
                { 'value' : 'tw', 'lbl' : '中文'},
                { 'value' : 'ch', 'lbl' : '普通话'}
            ];
        },

        countryList: function() {
            return countries = [
                { 'value' : 'United States', 'lbl' : 'United States'},
                { 'value' : 'Afghanistan', 'lbl' : 'Afghanistan'},
                { 'value' : 'Albania', 'lbl' : 'Albania'},
                { 'value' : 'Algeria', 'lbl' : 'Algeria'},
                { 'value' : 'Andorra', 'lbl' : 'Andorra'},
                { 'value' : 'Angola', 'lbl' : 'Angola'},
                { 'value' : 'Antigua and Barbuda', 'lbl' : 'Antigua and Barbuda'},
                { 'value' : 'Argentina', 'lbl' : 'Argentina'},
                { 'value' : 'Armenia', 'lbl' : 'Armenia'},
                { 'value' : 'Australia', 'lbl' : 'Australia'},
                { 'value' : 'Austria', 'lbl' : 'Austria'},
                { 'value' : 'Azerbaijan', 'lbl' : 'Azerbaijan'},
                { 'value' : 'Bahamas', 'lbl' : 'Bahamas'},
                { 'value' : 'Bahrain', 'lbl' : 'Bahrain'},
                { 'value' : 'Bangladesh', 'lbl' : 'Bangladesh'},
                { 'value' : 'Barbados', 'lbl' : 'Barbados'},
                { 'value' : 'Belarus', 'lbl' : 'Belarus'},
                { 'value' : 'Belgium', 'lbl' : 'Belgium'},
                { 'value' : 'Belize', 'lbl' : 'Belize'},
                { 'value' : 'Benin', 'lbl' : 'Benin'},
                { 'value' : 'Bhutan', 'lbl' : 'Bhutan'},
                { 'value' : 'Bolivia', 'lbl' : 'Bolivia'},
                { 'value' : 'Bosnia and Herzegovina', 'lbl' : 'Bosnia and Herzegovina'},
                { 'value' : 'Botswana', 'lbl' : 'Botswana'},
                { 'value' : 'Brazil', 'lbl' : 'Brazil'},
                { 'value' : 'Brunei', 'lbl' : 'Brunei'},
                { 'value' : 'Bulgaria', 'lbl' : 'Bulgaria'},
                { 'value' : 'Burkina Faso', 'lbl' : 'Burkina Faso'},
                { 'value' : 'Burundi', 'lbl' : 'Burundi'},
                { 'value' : 'Cambodia', 'lbl' : 'Cambodia'},
                { 'value' : 'Cameroon', 'lbl' : 'Cameroon'},
                { 'value' : 'Canada', 'lbl' : 'Canada'},
                { 'value' : 'Cape Verde', 'lbl' : 'Cape Verde'},
                { 'value' : 'Central African Republic', 'lbl' : 'Central African Republic'},
                { 'value' : 'Chad', 'lbl' : 'Chad'},
                { 'value' : 'Chile', 'lbl' : 'Chile'},
                { 'value' : 'China', 'lbl' : 'China'},
                { 'value' : 'Colombi', 'lbl' : 'Colombi'},
                { 'value' : 'Comoros', 'lbl' : 'Comoros'},
                { 'value' : 'Congo (Brazzaville)', 'lbl' : 'Congo (Brazzaville)'},
                { 'value' : 'Congo', 'lbl' : 'Congo'},
                { 'value' : 'Costa Rica', 'lbl' : 'Costa Rica'},
                { 'value' : 'Cote d\'Ivoire', 'lbl' : 'Cote d\'Ivoire'},
                { 'value' : 'Croatia', 'lbl' : 'Croatia'},
                { 'value' : 'Cuba', 'lbl' : 'Cuba'},
                { 'value' : 'Cyprus', 'lbl' : 'Cyprus'},
                { 'value' : 'Czech Republic', 'lbl' : 'Czech Republic'},
                { 'value' : 'Denmark', 'lbl' : 'Denmark'},
                { 'value' : 'Djibouti', 'lbl' : 'Djibouti'},
                { 'value' : 'Dominica', 'lbl' : 'Dominica'},
                { 'value' : 'Dominican Republic', 'lbl' : 'Dominican Republic'},
                { 'value' : 'East Timor (Timor Timur)', 'lbl' : 'East Timor (Timor Timur)'},
                { 'value' : 'Ecuador', 'lbl' : 'Ecuador'},
                { 'value' : 'Egypt', 'lbl' : 'Egypt'},
                { 'value' : 'El Salvador', 'lbl' : 'El Salvador'},
                { 'value' : 'Equatorial Guinea', 'lbl' : 'Equatorial Guinea'},
                { 'value' : 'Eritrea', 'lbl' : 'Eritrea'},
                { 'value' : 'Estonia', 'lbl' : 'Estonia'},
                { 'value' : 'Ethiopia', 'lbl' : 'Ethiopia'},
                { 'value' : 'Fiji', 'lbl' : 'Fiji'},
                { 'value' : 'Finland', 'lbl' : 'Finland'},
                { 'value' : 'France', 'lbl' : 'France'},
                { 'value' : 'Gabon', 'lbl' : 'Gabon'},
                { 'value' : 'Gambia, The', 'lbl' : 'Gambia, The'},
                { 'value' : 'Georgia', 'lbl' : 'Georgia'},
                { 'value' : 'Germany', 'lbl' : 'Germany'},
                { 'value' : 'Ghana', 'lbl' : 'Ghana'},
                { 'value' : 'Greece', 'lbl' : 'Greece'},
                { 'value' : 'Grenada', 'lbl' : 'Grenada'},
                { 'value' : 'Guatemala', 'lbl' : 'Guatemala'},
                { 'value' : 'Guinea', 'lbl' : 'Guinea'},
                { 'value' : 'Guinea-Bissau', 'lbl' : 'Guinea-Bissau'},
                { 'value' : 'Guyana', 'lbl' : 'Guyana'},
                { 'value' : 'Haiti', 'lbl' : 'Haiti'},
                { 'value' : 'Honduras', 'lbl' : 'Honduras'},
                { 'value' : 'Hungary', 'lbl' : 'Hungary'},
                { 'value' : 'Iceland', 'lbl' : 'Iceland'},
                { 'value' : 'India', 'lbl' : 'India'},
                { 'value' : 'Indonesia', 'lbl' : 'Indonesia'},
                { 'value' : 'Iran', 'lbl' : 'Iran'},
                { 'value' : 'Iraq', 'lbl' : 'Iraq'},
                { 'value' : 'Ireland', 'lbl' : 'Ireland'},
                { 'value' : 'Israel', 'lbl' : 'Israel'},
                { 'value' : 'Italy', 'lbl' : 'Italy'},
                { 'value' : 'Jamaica', 'lbl' : 'Jamaica'},
                { 'value' : 'Japan', 'lbl' : 'Japan'},
                { 'value' : 'Jordan', 'lbl' : 'Jordan'},
                { 'value' : 'Kazakhstan', 'lbl' : 'Kazakhstan'},
                { 'value' : 'Kenya', 'lbl' : 'Kenya'},
                { 'value' : 'Kiribati', 'lbl' : 'Kiribati'},
                { 'value' : 'Korea, North', 'lbl' : 'Korea, North'},
                { 'value' : 'Korea, South', 'lbl' : 'Korea, South'},
                { 'value' : 'Kuwait', 'lbl' : 'Kuwait'},
                { 'value' : 'Kyrgyzstan', 'lbl' : 'Kyrgyzstan'},
                { 'value' : 'Laos', 'lbl' : 'Laos'},
                { 'value' : 'Latvia', 'lbl' : 'Latvia'},
                { 'value' : 'Lebanon', 'lbl' : 'Lebanon'},
                { 'value' : 'Lesotho', 'lbl' : 'Lesotho'},
                { 'value' : 'Liberia', 'lbl' : 'Liberia'},
                { 'value' : 'Libya', 'lbl' : 'Libya'},
                { 'value' : 'Liechtenstein', 'lbl' : 'Liechtenstein'},
                { 'value' : 'Lithuania', 'lbl' : 'Lithuania'},
                { 'value' : 'Luxembourg', 'lbl' : 'Luxembourg'},
                { 'value' : 'Macedonia', 'lbl' : 'Macedonia'},
                { 'value' : 'Madagascar', 'lbl' : 'Madagascar'},
                { 'value' : 'Malawi', 'lbl' : 'Malawi'},
                { 'value' : 'Malaysia', 'lbl' : 'Malaysia'},
                { 'value' : 'Maldives', 'lbl' : 'Maldives'},
                { 'value' : 'Mali', 'lbl' : 'Mali'},
                { 'value' : 'Malta', 'lbl' : 'Malta'},
                { 'value' : 'Marshall Islands', 'lbl' : 'Marshall Islands'},
                { 'value' : 'Mauritania', 'lbl' : 'Mauritania'},
                { 'value' : 'Mauritius', 'lbl' : 'Mauritius'},
                { 'value' : 'Mexico', 'lbl' : 'Mexico'},
                { 'value' : 'Micronesia', 'lbl' : 'Micronesia'},
                { 'value' : 'Moldova', 'lbl' : 'Moldova'},
                { 'value' : 'Monaco', 'lbl' : 'Monaco'},
                { 'value' : 'Mongolia', 'lbl' : 'Mongolia'},
                { 'value' : 'Morocco', 'lbl' : 'Morocco'},
                { 'value' : 'Mozambique', 'lbl' : 'Mozambique'},
                { 'value' : 'Myanmar', 'lbl' : 'Myanmar'},
                { 'value' : 'Namibia', 'lbl' : 'Namibia'},
                { 'value' : 'Nauru', 'lbl' : 'Nauru'},
                { 'value' : 'Nepal', 'lbl' : 'Nepal'},
                { 'value' : 'Netherlands', 'lbl' : 'Netherlands'},
                { 'value' : 'New Zealand', 'lbl' : 'New Zealand'},
                { 'value' : 'Nicaragua', 'lbl' : 'Nicaragua'},
                { 'value' : 'Niger', 'lbl' : 'Niger'},
                { 'value' : 'Nigeria', 'lbl' : 'Nigeria'},
                { 'value' : 'Norway', 'lbl' : 'Norway'},
                { 'value' : 'Oman', 'lbl' : 'Oman'},
                { 'value' : 'Pakistan', 'lbl' : 'Pakistan'},
                { 'value' : 'Palau', 'lbl' : 'Palau'},
                { 'value' : 'Panama', 'lbl' : 'Panama'},
                { 'value' : 'Papua New Guinea', 'lbl' : 'Papua New Guinea'},
                { 'value' : 'Paraguay', 'lbl' : 'Paraguay'},
                { 'value' : 'Peru', 'lbl' : 'Peru'},
                { 'value' : 'Philippines', 'lbl' : 'Philippines'},
                { 'value' : 'Poland', 'lbl' : 'Poland'},
                { 'value' : 'Portugal', 'lbl' : 'Portugal'},
                { 'value' : 'Qatar', 'lbl' : 'Qatar'},
                { 'value' : 'Romania', 'lbl' : 'Romania'},
                { 'value' : 'Russia', 'lbl' : 'Russia'},
                { 'value' : 'Rwanda', 'lbl' : 'Rwanda'},
                { 'value' : 'Saint Kitts and Nevis', 'lbl' : 'Saint Kitts and Nevis'},
                { 'value' : 'Saint Lucia', 'lbl' : 'Saint Lucia'},
                { 'value' : 'Saint Vincent', 'lbl' : 'Saint Vincent'},
                { 'value' : 'Samoa', 'lbl' : 'Samoa'},
                { 'value' : 'San Marino', 'lbl' : 'San Marino'},
                { 'value' : 'Sao Tome and Principe', 'lbl' : 'Sao Tome and Principe'},
                { 'value' : 'Saudi Arabia', 'lbl' : 'Saudi Arabia'},
                { 'value' : 'Senegal', 'lbl' : 'Senegal'},
                { 'value' : 'Serbia and Montenegro', 'lbl' : 'Serbia and Montenegro'},
                { 'value' : 'Seychelles', 'lbl' : 'Seychelles'},
                { 'value' : 'Sierra Leone', 'lbl' : 'Sierra Leone'},
                { 'value' : 'Singapore', 'lbl' : 'Singapore'},
                { 'value' : 'Slovakia', 'lbl' : 'Slovakia'},
                { 'value' : 'Slovenia', 'lbl' : 'Slovenia'},
                { 'value' : 'Solomon Islands', 'lbl' : 'Solomon Islands'},
                { 'value' : 'Somalia', 'lbl' : 'Somalia'},
                { 'value' : 'South Africa', 'lbl' : 'South Africa'},
                { 'value' : 'Spain', 'lbl' : 'Spain'},
                { 'value' : 'Sri Lanka', 'lbl' : 'Sri Lanka'},
                { 'value' : 'Sudan', 'lbl' : 'Sudan'},
                { 'value' : 'Suriname', 'lbl' : 'Suriname'},
                { 'value' : 'Swaziland', 'lbl' : 'Swaziland'},
                { 'value' : 'Sweden', 'lbl' : 'Sweden'},
                { 'value' : 'Switzerland', 'lbl' : 'Switzerland'},
                { 'value' : 'Syria', 'lbl' : 'Syria'},
                { 'value' : 'Taiwan', 'lbl' : 'Taiwan'},
                { 'value' : 'Tajikistan', 'lbl' : 'Tajikistan'},
                { 'value' : 'Tanzania', 'lbl' : 'Tanzania'},
                { 'value' : 'Thailand', 'lbl' : 'Thailand'},
                { 'value' : 'Togo', 'lbl' : 'Togo'},
                { 'value' : 'Tonga', 'lbl' : 'Tonga'},
                { 'value' : 'Trinidad and Tobago', 'lbl' : 'Trinidad and Tobago'},
                { 'value' : 'Tunisia', 'lbl' : 'Tunisia'},
                { 'value' : 'Turkey', 'lbl' : 'Turkey'},
                { 'value' : 'Turkmenistan', 'lbl' : 'Turkmenistan'},
                { 'value' : 'Tuvalu', 'lbl' : 'Tuvalu'},
                { 'value' : 'Uganda', 'lbl' : 'Uganda'},
                { 'value' : 'Ukraine', 'lbl' : 'Ukraine'},
                { 'value' : 'United Arab Emirates', 'lbl' : 'United Arab Emirates'},
                { 'value' : 'United Kingdom', 'lbl' : 'United Kingdom'},
                { 'value' : 'Uruguay', 'lbl' : 'Uruguay'},
                { 'value' : 'Uzbekistan', 'lbl' : 'Uzbekistan'},
                { 'value' : 'Vanuatu', 'lbl' : 'Vanuatu'},
                { 'value' : 'Vatican City', 'lbl' : 'Vatican City'},
                { 'value' : 'Venezuela', 'lbl' : 'Venezuela'},
                { 'value' : 'Vietnam', 'lbl' : 'Vietnam'},
                { 'value' : 'Yemen', 'lbl' : 'Yemen'},
                { 'value' : 'Zambia', 'lbl' : 'Zambia'},
                { 'value' : 'Zimbabwe', 'lbl' : 'Zimbabwe'}
            ];
        }
    
    };
});
