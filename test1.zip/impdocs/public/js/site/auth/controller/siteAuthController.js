
//Define App module
var siteHomepage = angular.module("homePageModule");
//console.log('hello hope gggggggu r in right way');

siteHomepage.controller('siteAuthController', ["$rootScope", "$scope", "$route", "$timeout","$location", "$http","siteAuth", "$routeParams", "$localStorage", "$filter", "$translate",
	
	function($rootScope, $scope, $route, $timeout, $location, $http, siteAuth, $routeParams, $localStorage, $filter, $translate ) {

		//Get signup page again after successful signup and display message
		if($rootScope.registerSuccess != '' && $rootScope.registerSuccess != undefined)
		{
			$location.path("/signup");
		}
		var config = {};
		$scope.isDisable = 0;

		$scope.langList = siteAuth.langList();

		if(!$localStorage.langSelected || $localStorage.langSelected == '' ) {
			$localStorage.langSelected = 'en';
			$scope.language= 'en';
		}	
		
		$scope.myName = "";
		$scope.userdata = '';
		

		//$rootScope.userAuthenticated = '';
		
		//$localStorage.migrateSuccessMSG = "";
		//$rootScope.articleContent = "";

		// Set default content language is "English"
		$scope.feature_1_ArticleTitle = "";
		$scope.feature_1_ArticleContent = "";

		$scope.feature_2_ArticleTitle = "";
		$scope.feature_2_ArticleContent = "";

		$scope.feature_3_ArticleTitle = "";
		$scope.feature_3_ArticleContent = "";

		$scope.aboutus_ArticleTitle = "";
		$scope.aboutus_ArticleContent = "";

		$scope.contactus_ArticleTitle = "";
		$scope.contactus_ArticleContent = "";

		if($location.path() == '/'){
			$scope.usrlFlag = 1;
		} else {
			$scope.usrlFlag = 0;
		}

		if($routeParams.mitext == 'migrate') {	
			$scope.migrateUserLbl = 1;
		}else {
			$scope.migrateUserLbl = 0;	
			$rootScope.success = "";
		}

		$scope.socialLinks = siteAuth.socialLinks();
		$scope.impConfig = siteAuth.impConfig();

		/* Get Cookies Detail */
		$scope.getCookieData = function() {
			
			if(!siteAuth.getCurrentUser()) {

				if($localStorage.migrateSuccessMSG) {
	        		
	        		$rootScope.success = $localStorage.migrateSuccessMSG;	
	        		$localStorage.migrateSuccessMSG = "";
	        	}
	        	
				var cookiesData = siteAuth.getCookies();
		        $scope.credentials = {};
		        if(cookiesData.setMe == true) {
					
					$http.post('/api/site/auth/dec',cookiesData).success(function(response) {
		                $scope.credentials.rememberMe = cookiesData.setMe;
			        	$scope.credentials.email = response.decEmail;
			        	$scope.credentials.password = response.decPass;
		            }).error(function(response) {
		                $scope.error = response.message;
		            });
		        
		        }
			}
		}

		/*Get a list of days as per selected Month and Year*/
		$scope.getUserdata = function() {
			
			$scope.subscriptionFlag = 0;
			if(siteAuth.getCurrentUser()) {
			
				var usersession = siteAuth.getCurrentUser();
				var user_id = usersession.id;
				var useridobj = {
					user_id		: user_id
				}

				//$http.post('/api/site/getuser',useridobj).success(function(response) {
					
					var response 	= $rootScope.userAuthenticated; 
					console.log(response);
					$scope.userdata = response;
					$rootScope.userAuthenticated = response;
					
					if(response.id) {
						
						if(response.isAdmin == true) {
							$scope.subscriptionFlag = 1;
						} else {
							
							var today  			= new Date();
							var todayDate 		= $filter('date')(today, "yyyy-MM-dd");
							var memberEndDate 	= new Date(response.Subscriptions[0].endAt);
							var memberEndDate 	= $filter('date')(memberEndDate, "yyyy-MM-dd");
							
							if(todayDate > memberEndDate) {
							 	$scope.subscriptionFlag = 0;
							} else {
								$scope.subscriptionFlag = 1;
							}

							if(response.isPaid == true) {
							 	$scope.subscriptionPaidFlag = 0;
							} else {
								$scope.subscriptionFreeFlag = 1;
							}

						}	
					} 
					
				//}).error(function(response) {
					//$scope.error = response.message;
				//}); 
			}
		}

		/*Get a list of days as per selected Month and Year*/
		$scope.preFillData = function() {
			
			if($rootScope.registerSuccess != '' && $rootScope.registerSuccess != undefined)
			{
				$scope.success = $rootScope.registerSuccess;
				$scope.error = "";		
				$rootScope.registerSuccess = '';
			}
			
			var curYear = new Date().getFullYear();
		  	var startYear = 1900;
		  	
		  	$scope.birthdayYear = 1980;
		  	$scope.birthdayDay = '01';
		    $scope.birthdayMonth = '01';
		    
		    $scope.gender = 'Male';
		    $scope.country = 'United States';
		    $scope.countryList = siteAuth.countryList();
		  	
		  	var fullYear = [];
		    for (var i=startYear; i<=curYear; i++) {

		    	var newarray = {
		    		'value' : i,
		    		'year' : i 
		    	};

				fullYear.push(newarray);
		    }
		    $scope.bYear = fullYear;
		    $scope.getDays($scope.birthdayMonth , $scope.birthdayYear);

			// Get list of secret Questions
			$scope.secretQuestion = '';
			
			$http.post('/api/site/listsecretquestions','').success(function(response) {
				
				$scope.questionId = response[0].id;
				$scope.secretQuestion = response;	
			
			}).error(function(response) {
				$scope.error = response.message;
			});
		}

		/*Get a list of days as per selected Month and Year*/
		$scope.getDaysArray = function() {
			var month = $scope.birthdayMonth;
			var year = $scope.birthdayYear;
			$scope.getDays(month, year);
		}

		/*Function for calculating days of month as per selected month and year*/
		$scope.getDays = function(month, year) {
			
		  	
		  	
		  	if(month == '01' || month == '03' || month == '05' || month == '07' || month == '08' || month == '10' ||  month == '12'){
		  		var startDay = 1;
		  		var endDay = 31;
			}
			else if(month == '04' || month == '06' || month == '09' || month == '11'){
				var startDay = 1;
		  		var endDay = 30;
			} else if(month == '02'){
				if ((parseInt(year)%4) == 0){
					if (parseInt(year)%100 == 0){
						
						if (parseInt(year)%400 == 0){
							var startDay = 1;
	  						var endDay = 29;
						} else {
							var startDay = 1;
	  						var endDay = 28;
						}	
					} else {
						var startDay = 1;
  						var endDay = 29;
					}
				
				} else {
					var startDay = 1;
					var endDay = 28;
				}
			
			 } else {
				var startDay = 1;
		  		var endDay = 31;
			}

		  	var fullDay = [];
		    for (var i=startDay; i<=endDay; i++) {

		    	if(i<=9)
		    		i = '0'+i;

		    	var newarray = {
		    		'value' : i,
		    		'day' : i 
		    	};
				fullDay.push(newarray);
		    }
		    
		    $scope.bDay = fullDay;
			
			//New Code
			//console.log("Date => "+parseInt($scope.birthdayDay)+"End day => "+parseInt(endDay))
			$scope.birthdayDay = (parseInt($scope.birthdayDay) > parseInt(endDay)) ? '01' : $scope.birthdayDay;
			$("#birthDate span.customSelectInner").html($scope.birthdayDay);

		};		

		/*SIgn up process*/
		$scope.signup = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/signup");
		};

		/*SIgn Out process*/
		$scope.signout = function() {
			siteAuth.logout().success(function (data) {
				if(data && data.status && data.status == "success") {
					
					$location.path("/");
					$('.signinbox .close').trigger( "click" );
					$('.close-menu').trigger( "click" );
					$route.reload();
				}
			});
		};

		/*Redirect on home page*/
		$scope.cancel = function() {
			$location.path("/");
		};

		/*Register with new user*/
		$scope.registeruser = function() {
			
			$scope.isDisable = 1;
			if($scope.birthdayYear != "" && $scope.birthdayYear != undefined && $scope.birthdayMonth != "" && $scope.birthdayMonth != undefined && $scope.birthdayDay != "" && $scope.birthdayDay != undefined ) {
				var birthday = $scope.birthdayYear+"-"+$scope.birthdayMonth+"-"+$scope.birthdayDay;	
			} else {
				$scope.error = [{ "msg" : "Date is Required" }];
				$scope.isDisable = 0;
				return false;
			}
			
			$scope.user.gender 		= $scope.gender
			$scope.user.country 	= $scope.country
			$scope.user.birthday 	= birthday;
			$scope.user.questionId 	= $scope.questionId;
			$scope.user.isAdmin 	= 0;
			$scope.user.userStatus 	= 1;

			$http.post('/api/site/registeruser',$scope.user).success(function(response) {

				if(response.status == 'success') {
					/*$('html,body').animate({ scrollTop: 0},'fast');
					$location.path("/");*/
					$rootScope.registerSuccess = [{ "msg" : "Thank you for signing up with Om!" }];
					$scope.error = "";
					$location.path("/");
				} else {
					
					if(response.status == 'fail') {
						$scope.isDisable = 0;
						$scope.error = [{ "msg" : "Registration for new user failed!" }];
						$scope.success = "";
					} else {
						$scope.isDisable = 0;
						$scope.error = response.status
						$scope.success = "";
					}	
				}	
			}).error(function(response) {
				
				$scope.isDisable = 0;
				$scope.error = response.message;
			
			});
		};
				
		/*User login process*/		
		$scope.userlogin = function() {
			$scope.isDisable = 1;
			siteAuth.login({
				
				email: $scope.credentials.email,
				password: $scope.credentials.password,
				rememberMe: $scope.credentials.rememberMe
			
			}).then( function(result) {

				if(result.resetPassword == 'YES') {
                	
                	$('.signinbox .close').trigger( "click" );
					$('.close-menu').trigger( "click" );
                	$location.path('/setNewPassword/migrate/'+result.userMigrateID);    
                
                } else {
					
            		/*$('html,body').animate({ scrollTop: $(".logo").offset().top},'fast');*/
					$('html,body').animate({ scrollTop: 0},'fast');
					$('.signinbox .close').trigger( "click" );
					$('.close-menu').trigger( "click" );
            		$location.path("/");
					$route.reload();
            	}
			
			}).catch( function(err) {
				
				$scope.isDisable = 0;
				$scope.error = [{ "msg" : "Email or Password is invalid" }];
			
			});
		};
		
		/*Show slider on bottom for go to top or not*/
		$scope.getLocation = function() {
			
			if($location.path() === "/") {
				$scope.showTopLink = 1;
			} else {
				$scope.showTopLink = 0;
			}
		};

		/*Get a loggedin user's profile data*/
		$scope.getProfile = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/userProfile");
		};

		/*Nevigate on homepage*/
		$scope.home = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/");
		};

		/*Nevigate on Plan page*/
		$scope.getPlans = function() {
			//alert('hello');
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/plans");
		};

		/*Nevigate on Subscription log detail page*/
		$scope.getSubscriptionDetail = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/subscriptionsLog");
		};

		/*Nevigate on Music Library page*/
		$scope.getMusicLibrary = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/musicLibrary");
		};

		/*Nevigate on Favorite Music Library page*/
		$scope.getMusicLibraryFavorite = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/musicLibrary/favorite");
		};

		/*Nevigate on Forget password page*/
		$scope.getForgetPassword = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/forgetPassword");
		};

		/*Forget password and send mail to respective user with reset password link*/
		$scope.forgetPassword = function() {

			var obj = {
				'forgetPasswordEmail'  :  $scope.forgetEmail
			};

			$http.post('/api/site/forgetPassword',obj).success(function(response) {

				console.log(response);
				if(response.status == 'succ') {
					$scope.success = [{ "msg" : response.msg }];
					$scope.error = "";
				} else {
					$scope.error = [{ "msg" : response.msg }];
					$scope.success = "";
				}	
			
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/*Reset password and also reset/updarade existing user account*/
		$scope.setNewPassword = function() {

			if($routeParams.mitext == 'migrate') //User account migration and reset password
			{	
				var obj = {
					'userId' 	: $routeParams.userid,
					'password' 	: $scope.newpass.password,
					'migrate' 	: $routeParams.mitext,
				};
			}else { //reset password
				var obj = {
					'userId' 	: $routeParams.userid,
					'password' 	: $scope.newpass.password
				};	
			}	

			$http.post('/api/site/resetPassword',obj).success(function(response) {

				if(response.status == 'succ') {
					
					$localStorage.migrateSuccessMSG = [{ "msg" : response.msg }];
					$scope.getCookieData();
					$(".signinlink a").trigger("click");
					$scope.error = "";
				
				} else {
					$scope.error = [{ "msg" : response.msg }];
					$scope.success = "";
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/*Get a list of content for home page*/
		$scope.getContent = function (key) {

			if($location.path() === "/") {
				$scope.showTopLink = 1;
			} else {
				$scope.showTopLink = 0;
			}

			if(siteAuth.getCurrentUser()) {
				$scope.userAuth = 1;
			}
			else{
				$scope.userAuth = 0;
			}
			
			$http.post('/api/site/listContent','').success(function(response) {
				
				$rootScope.articleContent = response;

				$scope.changeLanguage($localStorage.langSelected);

				//Set default content language is "English"
				/*$scope.feature_1_ArticleTitle = response[0].titleEN;
				$scope.feature_1_ArticleContent = response[0].contentEN;

				$scope.feature_2_ArticleTitle = response[1].titleEN;
				$scope.feature_2_ArticleContent = response[1].contentEN;

				$scope.feature_3_ArticleTitle = response[2].titleEN;
				$scope.feature_3_ArticleContent = response[2].contentEN;

				$scope.aboutus_ArticleTitle = response[3].titleEN;
				$scope.aboutus_ArticleContent = response[3].contentEN;

				$scope.contactus_ArticleTitle = response[4].titleEN;
				$scope.contactus_ArticleContent = response[4].contentEN;*/

			}).error(function(response) {
				$scope.error = response.message;
			});
			$scope.getLocation();
		};

		/*Get a content data as per selected language*/
		$scope.changeLanguage = function (key) {

			$translate.use(key);
			$localStorage.langSelected = key;

			if($location.path() === "/plans")
			{
				$rootScope.setPlans();
			}

			$scope.language = key;

			if(key == 'fr') // Convert content language by "French"
			{
				$scope.feature_1_ArticleTitle 	= $rootScope.articleContent[0].titleFR;
				$scope.feature_1_ArticleContent = $rootScope.articleContent[0].contentFR;

				$scope.feature_2_ArticleTitle 	= $rootScope.articleContent[1].titleFR;
				$scope.feature_2_ArticleContent = $rootScope.articleContent[1].contentFR;

				$scope.feature_3_ArticleTitle 	= $rootScope.articleContent[2].titleFR;
				$scope.feature_3_ArticleContent = $rootScope.articleContent[2].contentFR;

				$scope.aboutus_ArticleTitle 	= $rootScope.articleContent[3].titleFR;
				$scope.aboutus_ArticleContent 	= $rootScope.articleContent[3].contentFR;

				$scope.contactus_ArticleTitle 	= $rootScope.articleContent[4].titleFR;
				$scope.contactus_ArticleContent = $rootScope.articleContent[4].contentFR;
				
			} else if(key == 'es') { // Convert content language by "Spanish"
				
				$scope.feature_1_ArticleTitle 	= $rootScope.articleContent[0].titleES;
				$scope.feature_1_ArticleContent = $rootScope.articleContent[0].contentES;

				$scope.feature_2_ArticleTitle 	= $rootScope.articleContent[1].titleES;
				$scope.feature_2_ArticleContent = $rootScope.articleContent[1].contentES;

				$scope.feature_3_ArticleTitle 	= $rootScope.articleContent[2].titleES;
				$scope.feature_3_ArticleContent = $rootScope.articleContent[2].contentES;

				$scope.aboutus_ArticleTitle 	= $rootScope.articleContent[3].titleES;
				$scope.aboutus_ArticleContent 	= $rootScope.articleContent[3].contentES;

				$scope.contactus_ArticleTitle 	= $rootScope.articleContent[4].titleES;
				$scope.contactus_ArticleContent = $rootScope.articleContent[4].contentES;

			}else if(key == 'tw') { // Convert content language by "Mandarin Chinese" (Taiwan)
				
				//console.log("--Me here Taiwan---");
				$scope.feature_1_ArticleTitle 	= $rootScope.articleContent[0].titleTW;
				$scope.feature_1_ArticleContent = $rootScope.articleContent[0].contentTW;

				$scope.feature_2_ArticleTitle 	= $rootScope.articleContent[1].titleTW;
				$scope.feature_2_ArticleContent = $rootScope.articleContent[1].contentTW;

				$scope.feature_3_ArticleTitle 	= $rootScope.articleContent[2].titleTW;
				$scope.feature_3_ArticleContent = $rootScope.articleContent[2].contentTW;

				$scope.aboutus_ArticleTitle 	= $rootScope.articleContent[3].titleTW;
				$scope.aboutus_ArticleContent 	= $rootScope.articleContent[3].contentTW;

				$scope.contactus_ArticleTitle 	= $rootScope.articleContent[4].titleTW;
				$scope.contactus_ArticleContent = $rootScope.articleContent[4].contentTW;

			}else if(key == 'ch') { // Convert content language by "Simplified Chinese" (China)
				
				//console.log("--Me here China---");

				$scope.feature_1_ArticleTitle 	= $rootScope.articleContent[0].titleCH;
				$scope.feature_1_ArticleContent = $rootScope.articleContent[0].contentCH;

				$scope.feature_2_ArticleTitle 	= $rootScope.articleContent[1].titleCH;
				$scope.feature_2_ArticleContent = $rootScope.articleContent[1].contentCH;

				$scope.feature_3_ArticleTitle 	= $rootScope.articleContent[2].titleCH;
				$scope.feature_3_ArticleContent = $rootScope.articleContent[2].contentCH;

				$scope.aboutus_ArticleTitle 	= $rootScope.articleContent[3].titleCH;
				$scope.aboutus_ArticleContent 	= $rootScope.articleContent[3].contentCH;

				$scope.contactus_ArticleTitle 	= $rootScope.articleContent[4].titleCH;
				$scope.contactus_ArticleContent = $rootScope.articleContent[4].contentCH;

			} else { // Convert content language by "English"

				$scope.feature_1_ArticleTitle 	= $rootScope.articleContent[0].titleEN;
				$scope.feature_1_ArticleContent = $rootScope.articleContent[0].contentEN;

				$scope.feature_2_ArticleTitle 	= $rootScope.articleContent[1].titleEN;
				$scope.feature_2_ArticleContent = $rootScope.articleContent[1].contentEN;

				$scope.feature_3_ArticleTitle 	= $rootScope.articleContent[2].titleEN;
				$scope.feature_3_ArticleContent = $rootScope.articleContent[2].contentEN;

				$scope.aboutus_ArticleTitle 	= $rootScope.articleContent[3].titleEN;
				$scope.aboutus_ArticleContent 	= $rootScope.articleContent[3].contentEN;

				$scope.contactus_ArticleTitle 	= $rootScope.articleContent[4].titleEN;
				$scope.contactus_ArticleContent = $rootScope.articleContent[4].contentEN;
			}
		};

		/*Send Contact information by email*/
		$scope.contactInfo = function () {
			$scope.contact.time = Date();			

			$http.post('/api/site/contactInfo',$scope.contact).success(function(response) {
				
				if(response.status == 'succ') {
					
					jQuery("#name, #contactEmail, #contact, #message").val('');
					$("#contactUsButton").attr("disabled",true);
					
					/*jQuery("#contactEmail").val('');
					jQuery("#contact").val('');
					jQuery("#message").val('');*/

					$scope.success = [{ "msg" : "Your information was sent successfully" }];
					$scope.error = "";
				
				} else {
					if(response.status == 'fail') {
						
						$scope.success = "";
						$scope.error = [{ "msg" : response.msg }];
					
					} else {
						$scope.error = response.status
						$scope.success = "";
					}
				}	
			}).error(function(response) {
				$scope.success = "";
				$scope.error = [{ "msg" : response.message }];
			});
		};

		/*Nevigate on Terms and use page*/
		$scope.getTermsUsePage = function() {
			$location.path("/terms");
		};

		/*Get Terms and Content data*/
		$scope.getTemsContent = function() {
			console.log("Get terms content page");
			$http.post('/api/site/listContent','').success(function(response) {
				
				$scope.termsOfUseContent = response[5];
				console.log($scope.termsOfUseContent);

			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/*Nevigate on Privacy policy*/
		$scope.getPrivacyPolicyPage = function() {
			console.log("Get privacyPolicy page");
			$location.path("/privacyPolicy");
		};

		/*Set content on Privacy policy page*/
		$scope.getPrivacyPolicyContent = function() {
			
			$http.post('/api/site/listContent','').success(function(response) {
				$scope.privacyPolicyContent = response[6];
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/*Nevigate on getReplist Page*/
		$scope.getReplistPage = function() {
			$('.signinbox .close').trigger( "click" );
			$('.close-menu').trigger( "click" );
			$location.path("/repList");
		};

		/*Get a Rep List Information*/
		$scope.getRepList = function() {

			$http.post('/api/site/getRepList').success(function(response) {

				if(response.status == 'succ') {
					$scope.repList = response.data;
					$scope.success = "";
					$scope.error = "";
				
				} else {
					
					if(response.status == 'fail') {
						$scope.success = "";
						$scope.error = [{ "msg" : response.msg }];
					} else {
						$scope.error = response.status
						$scope.success = "";
					}
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : Sort parameter
		    Output : Get Sort list
		    Date   : 2015-11-09
		*/
		$scope.order = function(predicate) {
			$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
			$scope.predicate = predicate;
		};


		$('#back-top a').click(function () {
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });

		/*----Call function to hide Browser Console data-----*/
		//siteAuth.clearconsole();
		/*$http.get("/assets/language/ch.json").then(function (response) {
			console.log(response.data);
		});*/
	}
]);

/*Language translation process*/
siteHomepage.config(function ($translateProvider) {

	//English
	$translateProvider.translations('en', {
	  	'Language': {

		    'CompanyPunchLine'			: 'Practice Makes Perfect',
		    'CompanyPunchLineSmall'		: 'Accompaniment on Demand',
		    
		    'TitleFeature'				: 'Features',
		    'TitleAboutUs'				: 'About Us',
		    'TitleContactUs'			: 'Contact Us',
		    'TitleVideo'				: 'accompaniment by real professionals',
		    
		    'OwnerSigneture'			: 'Steven Maloney, B.M.',
		    'OwnerProfession'			: 'The Juilliard School',
		    
		    'BtnSignUp'					: 'Try It Free',
		    'BtnContactUs'				: 'Contact Us',
		    'BtnRepList'				: 'Rep list',
		    'BtnSubmit'					: 'Submit',
		    'BtnCancel'					: 'Cancel',
		    	    
		    'LabelMore'					: 'Learn More',
		    'LabelName'					: 'Name',
		    'LabelEmail'				: 'Email',
		    'LabelContact'				: 'Contact',
		    'LabelContactNumber'		: 'Contact Number',
		    'LabelFeedback'				: 'Feedback',
		    'LabelPhone'				: 'Phone',
		    'LabelFax'					: 'Fax',

		    'ErrMsgFirstNameReq'		: 'First name is required.',
		    'ErrMsgEmailReq'			: 'Email is required.',
		    'ErrMsgEmailValid'			: 'This needs to be a valid email',
		    'ErrMsgContactReq'			: 'Contact is required.',
		    'ErrMsgContactLength'		: 'Contact max length is 15 digit.',
		    'ErrMsgContactIsNumber'		: 'Must be a number.',
		    'ErrMsgMessageReq'			: 'Message is required.',

		    
		    'MenuHome'					: 'Home',
		    'MenuPricing'				: 'Pricing',
		    'MenuContactUs'				: 'Contact Us',
		    'MenuAboutUs'				: 'About Us',
		    'MenuSignIn'				: 'Sign In',
		    'MenuMusicLib'				: 'Music Library',
		    'MenuMyProfile'				: 'My Profile', 
		    'MenuRepList'				: 'Rep List',
		    'MenuSubscriptionStatus'	: 'Subscription Status', 
		    'MenuMyFavorite'			: 'My Favorites',
		    //Remaining AKAK
		    'MenuSignOut'				: 'Sign Out',
		    


		    'RLRepList'					: 'Rep List',
		    'RLComposerName'			: 'Composer Name',
		    'RLTitle'					: 'Title',
		    'RLGenre'					: 'Genre',
		    'RLSearchText'				: 'Search Text',

		    'LOGINSignIn'				: 'Sign In',
		    'LOGINPassword'				: 'Password',
		    'LOGINRememberMe'			: 'Remember Me',
		    'LOGINForgotPass'			: 'Forgot Password?',
		    'LOGINForgetPass'			: 'Forgot Password',

		    'REGRegistration'			: 'Registration',
		    'REGFirstName'				: 'First Name',
		    'REGLastName'				: 'Last Name',
		    'REGReTypePass'				: 'Re-type Password',
		    'REGEmail'					: 'Email',
		    'REGPassword'				: 'Password',
		    'REGDOB'					: 'Date of Birth',
		    'REGGender'					: 'Gender',
		    
		    'REGCountry'				: 'Country',
		    
		    'REGContact'				: 'Contact',
		    'REGSecQuestion'			: 'Secret Question',
		    'REGAnswe'					: 'Answer',
		    'REGSave'					: 'Save',
		    'REGMale'					: 'Male',
		    'REGFemale'					: 'Female',

		    'REGMyProfile'				: 'My Profile',
		    'REGChangePass'				: 'Do you want to change password?',
		    
		    'MUSICMusicLibrary'			: 'Music Library',
		    'MUSICSheetMusic'			: 'Sheet Music',
		    'MUSICSearchMusic'			: 'Search Music',
		    'MUSICInstrument'			: 'Instrument',
		    'MUSICLibrary'				: 'Library',
		    'MUSICNowPlaying'			: 'Now Playing',
		    'MUSICReplay'				: 'Replay',
		    'MUSICFavorite'				: 'Favorite',
		    'MUSICMyFavorite'			: 'My Favorites',

		    'SUBSubscriptionPlan'		: 'Subscription Plan',
		    'SUB6Month'					: 'Subscription for 6 months',
		    'SUB1Year'					: 'Subscription for 1 Year',
		    'SUBOnlyFor'				: 'for only',
		    'SUBCardType'				: 'Card Type',
		    'SUBCardNumber'				: 'Card Number',
		    'SUBExpDate'				: 'Expiration Date',
		    'SUBCardCVV'				: 'Card Verification Number',
		    'SUBAcceptTerms'			: 'I accept the Terms of Service',

		    'PRIPricingOption'			: 'Pricing Option',
		    'PRI6Month'					: '6 Month Plan',
		    'PRI12Month'				: '12 Month Plan',
		    'PRIMonth'					: 'month',
		    'PRIOneTimeCharge'			: 'one-time charge',
		    'PRISubscribe'				: 'Subscribe',

		    'SLOGTitle'					: 'Subscription Log',
		    'SLOGSubscription'			: 'Subscription',
		    'SLOGPlanStatus'			: 'Plan Status',
		    'SLOGStartDate'				: 'Start on',
		    'SLOGEndDate'				: 'Expire on',
		    'SLOGTransactionId'			: 'Transaction ID',
		    'SLOGAmount'				: 'Amount',
		    'SLOGPaymentStatus'			: 'Payment Status',
		    'SLOGCancelSub'				: 'Cancel Subscription',
		    'SLOGCacelRecSub'			: 'Cancel Recursive Subscription?',

		    //Footer section
		    'FOOTERTextTop'				: 'TOP',
		    'FOOTERMenuHome'			: 'Home',
		    'FOOTERMenuService'			: 'Terms of Service',
		    'FOOTERTextPolicy'			: 'Privacy Policy',
	  	}
	});
	
	//French
	$translateProvider.translations('fr', {
	  	'Language': {

		    'CompanyPunchLine'			: "C'est en pratiquant que l'on apprend",
		    'CompanyPunchLineSmall'		: 'Accompagnement sur demande',
		    
		    'TitleFeature'				: 'Caractéristiques',
		    'TitleAboutUs'				: 'À propos',
		    'TitleContactUs'			: 'Contactez-nous',
		    'TitleVideo'				: 'accompagnement par de vrais professionnels',
		    
		    'OwnerSigneture'			: 'Steven Maloney, B.M.',
		    'OwnerProfession'			: 'École Juilliard',
		    
		    'BtnSignUp'					: 'Essayez gratuitement',
		    'BtnContactUs'				: 'Contactez-nous',
		    'BtnRepList'				: 'Liste des répertoire ',
		    'BtnSubmit'					: 'Envoyer',
		    'BtnCancel'					: 'Annuler',
		    
		    'LabelMore'					: 'En savoir plus',
		    'LabelName'					: 'Nom',
		    'LabelEmail'				: 'Email',
		    'LabelContact'				: 'Contact',
		    'LabelContactNumber'		: 'Numéro de contact',
		    'LabelFeedback'				: 'Commentaires',
		    'LabelPhone'				: 'Téléphone',
		    'LabelFax'					: 'Fax',

		    'MenuHome'					: 'Domicile',
		    'MenuPricing'				: 'Tarifs',
		    'MenuContactUs'				: 'Contactez-nous',
		    'MenuAboutUs'				: 'À propos',
		    'MenuSignIn'				: 'Se connecter',
		    'MenuMusicLib'				: 'Archive de musique',
		    'MenuMyProfile'				: 'Mon profil',
		    'MenuRepList'				: 'Liste de répertoire',
		    'MenuSubscriptionStatus'	: 'État de l’abonnement', 
		    'MenuMyFavorite'			: 'Mes favoris',
		    //Remaining AKAK
		    'MenuSignOut'				: 'Terminer',




		    'RLRepList'					: 'Liste de répertoire',
		    'RLComposerName'			: 'Nom du compositeur',
		    'RLTitle'					: 'Titre',
		    'RLGenre'					: 'Genre',
		    'RLSearchText'				: 'Recherche texte',

		    'LOGINSignIn'				: 'Se connecter',
		    'LOGINPassword'				: 'Mot de passe',
		    'LOGINRememberMe'			: 'Se souvenir de moi',
		    'LOGINForgotPass'			: 'Mot de passe oublié ?',
		    'LOGINForgetPass'			: 'Mot de passe oublié',

		    'REGRegistration'			: 'Inscription',
		    'REGFirstName'				: 'Prénom',
		    'REGLastName'				: 'Nom',
		    'REGReTypePass'				: 'Saisissez de nouveau votre mot de passe',
		    'REGEmail'					: 'Email',
		    'REGPassword'				: 'Mot de passe',
		    'REGDOB'					: 'Date de naissance',
		    'REGGender'					: 'Sexe',
		    
		    'REGCountry'				: 'Pays',
		    
		    'REGContact'				: 'Contact',
		    'REGSecQuestion'			: 'Question secrète',
		    'REGAnswe'					: 'Réponse',
		    'REGSave'					: 'Enregistrer',
		    'REGMale'					: 'Masculin',
		    'REGFemale'					: 'Féminin',

		    'REGMyProfile'				: 'Mon profil',
		    'REGChangePass'				: 'Souhaitez-vous modifier votre mot de passe ?',
		    
		    'MUSICMusicLibrary'			: 'Archive de musique',
		    'MUSICSheetMusic'			: 'Partition',
		    'MUSICSearchMusic'			: 'Rechercher de la musique',
		    'MUSICInstrument'			: 'Instrument',
		    'MUSICLibrary'				: 'Archive de musique',
		    'MUSICNowPlaying'			: 'Lecture en cours',
		    'MUSICReplay'				: 'Rejouer',
		    'MUSICFavorite'				: 'Favoris',
		    'MUSICMyFavorite'			: 'Mes favoris',

		    "SUBSubscriptionPlan"		: "Type d'abonnementn",
		    'SUB6Month'					: 'Abonnement de 6 mois',
		    "SUB1Year"					: "Abonnement d'un an",
		    'SUBOnlyFor'				: 'pour seulement',
		    'SUBCardType'				: 'Type de carte',
		    'SUBCardNumber'				: 'Numéro de carte',
		    "SUBExpDate"				: "Date d'expiration",
		    'SUBCardCVV'				: 'Clé de vérification',
		    "SUBAcceptTerms"			: "J'accepte les conditions d'utilisation",

		    'PRIPricingOption'			: 'Tarifs disponibles',
		    'PRI6Month'					: 'Abonnement de 6 mois',
		    'PRI12Month'				: 'Abonnement de 12 mois',
		    'PRIMonth'					: 'mois',
		    "PRIOneTimeCharge"			: "Facturation à l'utilisation",
		    "PRISubscribe"				: "S'abonner",

		    'SLOGTitle'					: 'Record de souscription',
		    'SLOGSubscription'			: 'Souscription',
		    'SLOGPlanStatus'			: 'État du plan',
		    'SLOGStartDate'				: 'Commencer',
		    'SLOGEndDate'				: 'Expiration',
		    'SLOGTransactionId'			: 'Code de transaction',
		    'SLOGAmount'				: 'Somme',
		    'SLOGPaymentStatus'			: 'Statut de paiement',
		    'SLOGCancelSub'				: "Annuler l'abonnement",
		    'SLOGCacelRecSub'			: 'Cancel Recursive Subscription?',


		    //Footer section
		    'FOOTERTextTop'				: 'HAUT',
		    'FOOTERMenuHome'			: 'Domicile',
		    'FOOTERMenuService'			: "Conditions d'utilisation",
		    'FOOTERTextPolicy'			: 'Politique de confidentialité',
	  	}
	});

	//Spanish
	$translateProvider.translations('es', {
	  	'Language': {

		    'CompanyPunchLine'			: 'La práctica hace al maestro',
		    'CompanyPunchLineSmall'		: 'Acompañamiento siempre disponible',
		    
		    'TitleFeature'				: 'Características',
		    'TitleAboutUs'				: 'Quiénes somos',
		    'TitleContactUs'			: 'Contáctenos',
		    'TitleVideo'				: 'Acompañamiento por verdaderos profesionales',
		    
		    'OwnerSigneture'			: 'Steven Maloney, B.M.',
		    'OwnerProfession'			: 'The Juilliard School',
		    
		    'BtnSignUp'					: 'Ensáyelo gratis',
		    'BtnContactUs'				: 'Contáctenos',
		    'BtnRepList'				: 'Lista de repertorio',
		    'BtnSubmit'					: 'Envíe',
		    'BtnCancel'					: 'Cancele',
		    
		    'LabelMore'					: 'Infórmese',
		    'LabelName'					: 'Nombre',
		    'LabelEmail'				: 'Correo electrónico',
		    'LabelContact'				: 'Contacto',
		    'LabelContactNumber'		: 'Número de telefono',
		    'LabelFeedback'				: 'Comentarios',
		    'LabelPhone'				: 'Teléfono',
		    'LabelFax'					: 'Fax',

		    
		    'MenuHome'					: 'Inicio',
		    'MenuPricing'				: 'Precios',
		    'MenuContactUs'				: 'Contáctenos',
		    'MenuAboutUs'				: 'Quiénes somos',
		    'MenuSignIn'				: 'Ingreso',
		    'MenuMusicLib'				: 'Archivo de música',
		    'MenuMyProfile'				: 'Mi perfil',
		    'MenuRepList'				: 'Lista de repertorio',
		    'MenuSubscriptionStatus'	: 'Estado de Suscripción', 
		    'MenuMyFavorite'			: 'Mis favoritos',
		    //Remaining AKAK
		    'MenuSignOut'				: 'Salir',

		    

		    'RLRepList'					: 'Lista de repertorio',
		    'RLComposerName'			: 'Nombre del compositor',
		    'RLTitle'					: 'Título',
		    'RLGenre'					: 'Género',
		    'RLSearchText'				: 'Texto para búsqueda',

		    'LOGINSignIn'				: 'Ingreso',
		    'LOGINPassword'				: 'Contraseña',
		    'LOGINRememberMe'			: 'Grabe mis datos',
		    'LOGINForgotPass'			: '¿Olvido su contraseña?',
		    'LOGINForgetPass'			: 'Olvidó contraseña',

		    'REGRegistration'			: 'Registro',
		    'REGFirstName'				: 'Nombre',
		    'REGLastName'				: 'Apellido',
		    'REGReTypePass'				: 'Repita su contraseña',
		    'REGEmail'					: 'Correo electrónico',
		    'REGPassword'				: 'Contraseña',
		    'REGDOB'					: 'Fecha de nacimiento',
		    'REGGender'					: 'Género',
		    
		    'REGCountry'				: 'País',
		    
		    'REGContact'				: 'Contacto',
		    'REGSecQuestion'			: 'Pregunta confidencial',
		    'REGAnswe'					: 'Respuesta',
		    'REGSave'					: 'Guardar',
		    'REGMale'					: 'Masculino',
		    'REGFemale'					: 'Femenino',

		    'REGMyProfile'				: 'Mi perfil',
		    'REGChangePass'				: '¿Desea cambiar la contraseña?',
		    
		    'MUSICMusicLibrary'			: 'Archivo de música',
		    'MUSICSheetMusic'			: 'Partitura',
		    'MUSICSearchMusic'			: 'Buscar música',
		    'MUSICInstrument'			: 'Instrumento',
		    'MUSICLibrary'				: 'Archivo',
		    'MUSICNowPlaying'			: 'Selección actual',
		    'MUSICReplay'				: 'Repetición',
		    'MUSICFavorite'				: 'Favorito',
		    'MUSICMyFavorite'			: 'Mis favoritos',

		    'SUBSubscriptionPlan'		: 'Plan de Suscripción',
		    'SUB6Month'					: 'Suscripción por 6 meses',
		    'SUB1Year'					: 'Suscripción por 1 año',
		    'SUBOnlyFor'				: 'por solo',
		    'SUBCardType'				: 'Tipo de tarjeta (MC, Visa, Amex)',
		    'SUBCardNumber'				: 'Número de tarjeta',
		    'SUBExpDate'				: 'Fecha de caducidad',
		    'SUBCardCVV'				: 'Número de verificación de su tarjeta',
		    'SUBAcceptTerms'			: 'Acepto los Términos de servicio',

		    'PRIPricingOption'			: 'Opciónes de pago',
		    'PRI6Month'					: 'Plan de 6 meses',
		    'PRI12Month'				: 'Plan de 12 meses',
		    'PRIMonth'					: 'mes',
		    'PRIOneTimeCharge'			: 'Un solo cobro',
		    'PRISubscribe'				: 'Suscribir',

		    'SLOGTitle'					: 'Record de Suscripción',
		    'SLOGSubscription'			: 'Suscripción',
		    'SLOGPlanStatus'			: 'Estado de Plan',
		    'SLOGStartDate'				: 'Inicio',
		    'SLOGEndDate'				: 'Vencimiento',
		    'SLOGTransactionId'			: 'Codigo de Transacción',
		    'SLOGAmount'				: 'Suma',
		    'SLOGPaymentStatus'			: 'Estado de Cuenta',
		    'SLOGCancelSub'				: 'Cancelar Suscripción',
		    'SLOGCacelRecSub'			: 'Cancel Recursive Subscription?',


		    //Footer section
		    'FOOTERTextTop'				: 'PARTE SUPERIOR',
		    'FOOTERMenuHome'			: 'Inicio',
		    'FOOTERMenuService'			: 'Condiciones de servicio',
		    'FOOTERTextPolicy'			: 'Politica de confidencialidad',



	  	}
	});

	//Mandarin Chinese (zhongwen) as used in Taiwan, HK, Traditional
	$translateProvider.translations('tw', {
	  	'Language': {

		    'CompanyPunchLine'			: '熟能生巧',
		    'CompanyPunchLineSmall'		: '按需選擇伴奏',
		    
		    'TitleFeature'				: '特點',
		    'TitleAboutUs'				: '關於我們',
		    'TitleContactUs'			: '聯絡我們',
		    'TitleVideo'				: '由專業人士伴奏',
		    
		    'OwnerSigneture'			: '史帝芬馬龍尼, 音樂學士',
		    'OwnerProfession'			: '茱莉亞學院',
		    
		    'BtnSignUp'					: '免費試用',
		    'BtnContactUs'				: '聯絡我們',
		    'BtnRepList'				: '樂曲目錄',
		    'BtnSubmit'					: '提交',
		    'BtnCancel'					: '取消',
		    
		    'LabelMore'					: '了解更多',
		    'LabelName'					: '姓名',
		    'LabelEmail'				: '電郵地址',
		    'LabelContact'				: '聯絡',
		    'LabelContactNumber'		: '聯絡電話',
		    'LabelFeedback'				: '意見',
		    'LabelPhone'				: '電話',
		    'LabelFax'					: '傳真',
		    
		    'MenuHome'					: '首頁',
		    'MenuPricing'				: '價格',
		    'MenuContactUs'				: '聯絡我們',
		    'MenuAboutUs'				: '關於我們',
		    'MenuSignIn'				: '登入',
		    'MenuMusicLib'				: '音樂庫',
		    'MenuMyProfile'				: '個人簡介',
		    'MenuRepList'				: '曲目表',
		    'MenuSubscriptionStatus'	: '訂閱狀態', 
		    'MenuMyFavorite'			: '我的收藏',
		    //Remaining AKAK
		    'MenuSignOut'				: '登出',


		    'RLRepList'					: '曲目表',
		    'RLComposerName'			: '作曲者姓名',
		    'RLTitle'					: '曲名',
		    'RLGenre'					: '音樂風格',
		    'RLSearchText'				: '搜索文本',

		    'LOGINSignIn'				: '登入',
		    'LOGINPassword'				: '密碼',
		    'LOGINRememberMe'			: '記住我',
		    'LOGINForgotPass'			: '忘了密碼嗎？',
		    'LOGINForgetPass'			: '忘記密碼',

		    'REGRegistration'			: '登記',
		    'REGFirstName'				: '名',
		    'REGLastName'				: '姓',
		    'REGReTypePass'				: '重新輸入密碼',
		    'REGEmail'					: '電郵地址',
		    'REGPassword'				: '密碼',
		    'REGDOB'					: '出生日期',
		    'REGGender'					: '性別',
		    
		    'REGCountry'				: '國家',
		    
		    'REGContact'				: '聯絡',
		    'REGSecQuestion'			: '密碼提示問題',
		    'REGAnswe'					: '回答',
		    'REGSave'					: '保存',
		    'REGMale'					: '男',
		    'REGFemale'					: '女',

		    'REGMyProfile'				: '個人簡介',
		    'REGChangePass'				: '您想更改密碼嗎？',
		    
		    'MUSICMusicLibrary'			: '音樂庫',
		    'MUSICSheetMusic'			: '樂譜',
		    'MUSICSearchMusic'			: '搜索音樂',
		    'MUSICInstrument'			: '樂器',
		    'MUSICLibrary'				: '庫',
		    'MUSICNowPlaying'			: '正在播放',
		    'MUSICReplay'				: '重播',
		    'MUSICFavorite'				: '收藏',
		    'MUSICMyFavorite'			: '我的收藏',

		    'SUBSubscriptionPlan'		: '訂用計劃',
		    'SUB6Month'					: '訂用6個月',
		    'SUB1Year'					: '訂用1年',
		    'SUBOnlyFor'				: '只',
		    'SUBCardType'				: '信用卡種類',
		    'SUBCardNumber'				: '卡號',
		    'SUBExpDate'				: '到期日',
		    'SUBCardCVV'				: '信用卡驗證碼',
		    'SUBAcceptTerms'			: '我接受服務條款',

		    'PRIPricingOption'			: '定價方案',
		    'PRI6Month'					: '6個月計劃',
		    'PRI12Month'				: '12個月計劃',
		    'PRIMonth'					: '月',
		    'PRIOneTimeCharge'			: '一次性收費',
		    'PRISubscribe'				: '訂閱',

		    'SLOGTitle'					: '訂閱檔案',
		    'SLOGSubscription'			: '訂閱',
		    'SLOGPlanStatus'			: '規劃',
		    'SLOGStartDate'				: '開始訂閱日期',
		    'SLOGEndDate'				: '結束訂閱日期',
		    'SLOGTransactionId'			: '交易帳號',
		    'SLOGAmount'				: '金額',
		    'SLOGPaymentStatus'			: '支付狀態',
		    'SLOGCancelSub'				: '取消訂閱',
		    'SLOGCacelRecSub'			: 'Cancel Recursive Subscription?',


		    //Footer section
		    'FOOTERTextTop'				: '最佳',
		    'FOOTERMenuHome'			: '首頁',
		    'FOOTERMenuService'			: '服務條款',
		    'FOOTERTextPolicy'			: '隱私政策',


		}
	});

	//Simplified Chinese (putonghua) ("common language") is used only in China
	$translateProvider.translations('ch', {
	  	'Language': {

		    'CompanyPunchLine'			: '熟能生巧',
		    'CompanyPunchLineSmall'		: '按需选择伴奏',
		    
		    'TitleFeature'				: '特点',
		    'TitleAboutUs'				: '关于我们',
		    'TitleContactUs'			: '联络我们',
		    'TitleVideo'				: '由专业人士伴奏',
		    
		    'OwnerSigneture'			: '史帝芬马龙尼, 音乐学士',
		    'OwnerProfession'			: '茱莉亚学院',
		    
		    'BtnSignUp'					: '免费试用',
		    'BtnContactUs'				: '联络我们',
		    'BtnRepList'				: '乐曲目录',
		    'BtnSubmit'					: '提交',
		    'BtnCancel'					: '取消',
		    	    
		    'LabelMore'					: '了解更多',
		    'LabelName'					: '姓名',
		    'LabelEmail'				: '电邮地址',
		    'LabelContact'				: '联络',
		    'LabelContactNumber'		: '联络电话',
		    'LabelFeedback'				: '意见',
		    'LabelPhone'				: '电话',
		    'LabelFax'					: '传真',

		    'MenuHome'					: '首页',
		    'MenuPricing'				: '价格',
		    'MenuContactUs'				: '联络我们',
		    'MenuAboutUs'				: '关于我们',
		    'MenuSignIn'				: '登入',
		    'MenuMusicLib'				: '音乐库',
		    'MenuMyProfile'				: '个人简介', 
		    'MenuRepList'				: '曲目表',
		    'MenuSubscriptionStatus'	: '订阅状态', 
		    'MenuMyFavorite'			: '我的收藏',
		    
		    //Remaining AKAK
		    'MenuSignOut'				: '登出',


		    'RLRepList'					: '曲目表',
		    'RLComposerName'			: '作曲者姓名',
		    'RLTitle'					: '曲名',
		    'RLGenre'					: '音乐风格',
		    'RLSearchText'				: '搜索文本',

		    'LOGINSignIn'				: '登入',
		    'LOGINPassword'				: '密码',
		    'LOGINRememberMe'			: '记住我',
		    'LOGINForgotPass'			: '忘了密码吗？',
		    'LOGINForgetPass'			: '忘记密码',

		    'REGRegistration'			: '登记',
		    'REGFirstName'				: '名',
		    'REGLastName'				: '姓',
		    'REGReTypePass'				: '重新输入密码',
		    'REGEmail'					: '电邮地址',
		    'REGPassword'				: '密码',
		    'REGDOB'					: '出生日期',
		    'REGGender'					: '性别',
		    
		    'REGCountry'				: '国家',

		    'REGContact'				: '联络',
		    'REGSecQuestion'			: '密码提示问题',
		    'REGAnswe'					: '回答',
		    'REGSave'					: '保存',
		    'REGMale'					: '男',
		    'REGFemale'					: '女',

		    'REGMyProfile'				: '个人简介',
		    'REGChangePass'				: '您想更改密码吗？',
		    
		    'MUSICMusicLibrary'			: '音乐库',
		    'MUSICSheetMusic'			: '乐谱',
		    'MUSICSearchMusic'			: '搜索音乐',
		    'MUSICInstrument'			: '乐器',
		    'MUSICLibrary'				: '库',
		    'MUSICNowPlaying'			: '正在播放',
		    'MUSICReplay'				: '重播',
		    'MUSICFavorite'				: '收藏',
		    'MUSICMyFavorite'			: '我的收藏',

		    'SUBSubscriptionPlan'		: '訂用計劃',
		    'SUB6Month'					: '订用6个月',
		    'SUB1Year'					: '订用1年',
		    'SUBOnlyFor'				: '只',
		    'SUBCardType'				: '信用卡种类',
		    'SUBCardNumber'				: '卡号',
		    'SUBExpDate'				: '到期日',
		    'SUBCardCVV'				: '信用卡验证码',
		    'SUBAcceptTerms'			: '我接受服务条款',

		    'PRIPricingOption'			: '定价方案',
		    'PRI6Month'					: '6个月计划',
		    'PRI12Month'				: '12个月计划',
		    'PRIMonth'					: '月',
		    'PRIOneTimeCharge'			: '一次性收费',
		    'PRISubscribe'				: '订阅',

		    'SLOGTitle'					: '订阅档案',
		    'SLOGSubscription'			: '订阅',
		    'SLOGPlanStatus'			: '规划',
		    'SLOGStartDate'				: '开始订阅日期',
		    'SLOGEndDate'				: '结束订阅日期',
		    'SLOGTransactionId'			: '交易帐号',
		    'SLOGAmount'				: '金额',
		    'SLOGPaymentStatus'			: '支付状态',
		    'SLOGCancelSub'				: '取消订阅',
		    'SLOGCacelRecSub'			: 'Cancel Recursive Subscription?',



		    //Footer section
		    'FOOTERTextTop'				: '最佳',
		    'FOOTERMenuHome'			: '首页',
		    'FOOTERMenuService'			: '服务条款',
		    'FOOTERTextPolicy'			: '隐私政策',
	  	}
	});

	$translateProvider.preferredLanguage('en');
});

siteHomepage.directive('matchPassword', function() {
  	return {
    	restrict: 'A',
    	require: ['^ngModel', '^form'],
    	link: function(scope, element, attrs, ctrls) {
      		
      		var formController = ctrls[1];
      		var ngModel = ctrls[0];
      		var otherPasswordModel = formController[attrs.matchPassword];
  
      		ngModel.$validators.passwordMatch = function(modelValue, viewValue) {
        		var password = modelValue || viewValue;
        		var otherPassword = otherPasswordModel.$modelValue || otherPasswordModel.viewValue;
        		//console.log('modelValue || viewValue', password, otherPassword);
        		return password === otherPassword;
      		};
    	} // end link
  	}; // end return
});

siteHomepage.directive('uniqueEmail', function($http, $q) {
  	return {
    	require : 'ngModel',
    	link : function($scope, element, attrs, ngModel) {
      		
      		ngModel.$asyncValidators.uniqueEmail = function(modelValue, viewValue) {
        		var email = modelValue || viewValue;
        		return $http.post('/api/site/uniqueEmail', {email: email}).then(function(res) {
          			if (res.data.exists == 'true') {
            			return $q.reject();
          			}
          			return $q.when();
        		});
      		}; // end async
    	} // end link
  	}; // end return 
});

siteHomepage.directive('errSrc', function() {
  	return {
    	link: function(scope, element, attrs) {
      		scope.$watch(function() {
          		return attrs['ngSrc'];
        	}, function (value) {
          		if (!value) {
            		element.attr('src', attrs.errSrc);  
          		}
      		});
      		element.bind('error', function() {
        		element.attr('src', attrs.errSrc);
      		});
    	}
  	}
});