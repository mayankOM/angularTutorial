/**
	* Main AngularJS Web Application
*/
var app = angular.module('homePageModule', [
  	'ngRoute',
  	'pascalprecht.translate'
]);

app.config(['$routeProvider', function ($routeProvider) {
	
	$routeProvider.when("/signup", {
		templateUrl: "templates/site/partials/home/signup.html"
	});
	$routeProvider.when("/terms", {
		resolve:{loggedInUser:loadLoggedInUser},
		templateUrl: "templates/site/partials/home/terms.html"
	});
	$routeProvider.when("/privacyPolicy", {
		resolve:{loggedInUser:loadLoggedInUser},
		templateUrl: "templates/site/partials/home/privacypolicy.html"
	});
	$routeProvider.when("/forgetPassword", {
		resolve:{loggedInUser:loadLoggedInUser},
		templateUrl: "templates/site/partials/home/forgetPassword.html",
	});
	$routeProvider.when("/setNewPassword/:userid", {
		resolve:{loggedInUser:loadLoggedInUser},
		templateUrl: "templates/site/partials/home/setNewPassword.html",
	});

	$routeProvider.when("/setNewPassword/:mitext/:userid", {
		resolve:{loggedInUser:loadLoggedInUser},
		templateUrl: "templates/site/partials/home/setNewPassword.html",
	});
	$routeProvider.when("/repList", {
		resolve:{loggedInUser:loadLoggedInUser},
		templateUrl: "templates/site/partials/home/repList.html"
	});
  	
  	
  	$routeProvider.when("/", {
  		resolve:{loggedInUser:loadLoggedInUser},
  		templateUrl: "templates/site/partials/home/home.html"
  	});

}]);