'use strict';
var homePageModule = angular.module('homePageModule');

homePageModule.controller('homeController', ['$scope','$http', '$location', '$timeout', '$routeParams','siteAuth',
	function($scope, $http, $location, $timeout, $routeParams,siteAuth) {

		$scope.contact = "";

		$scope.signup = function() {
			if(siteAuth.getCurrentUser()) {
				var userdata = siteAuth.getCurrentUser();
				if (userdata){
					alert("You are already Logged In");
				}
			} else {
				//alert('Hello');
				$('.signinbox .close').trigger( "click" );
				$('.close-menu').trigger("click");
				$location.path("/signup");
			}
		};
	}
]);