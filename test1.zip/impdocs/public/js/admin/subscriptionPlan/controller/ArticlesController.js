var subscriptionPlanModule = angular.module('subscriptionPlanModule');


subscriptionPlanModule.controller('adminSubscriptionPlanController', ['$rootScope','$scope','$http', '$location', '$routeParams',
	
	function($rootScope,$scope, $http, $location, $routeParams) {

		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};
		
		// Create new Composer
		$scope.create = function() {

			$http.post('/api/admin/addArticle',$scope.article).success(function(response) {

				if(response.status == 'success') {
					$rootScope.saveContentMsg="New Content Successfully Saved.";
			        $location.path("/admin/listArticles");
				
				} else {
					
					if(response.status == 'fail') {
						
					} else {
						$scope.error = response.status
						
					}	
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		// Create new Composer
		$scope.listArticles = function() {
			$http.get('/api/admin/listArticles').success(function(response) {
				$scope.articles = response;
				if ($rootScope.saveContentMsg && $rootScope.saveContentMsg != null) {
					$scope.success = [{ "msg" :  $rootScope.saveContentMsg }];
					$rootScope.saveContentMsg = '';
				}
				
				//Pagination param
				$scope.currentPage = 1;
  				$scope.pageSize = 10;

			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		// Edit new Composer
		$scope.getArticle = function() {
			var articleID = $routeParams.articleID;
			
			var articleObj = {
				id	: articleID
			};			
			
			$http.post('/api/admin/getArticle', articleObj).success(function(response) {
				$scope.article = response;
			}).error(function(response) {
				$scope.error = response.message;
			});
		
		};

		// Create new Composer
		$scope.update = function() {

			var articleObj = {
				id:$scope.article.id,
				titleEN: $scope.article.titleEN,
				contentEN:$scope.article.contentEN,
				titleFR: $scope.article.titleFR,
				contentFR:$scope.article.contentFR,
				titleES: $scope.article.titleES,
				contentES:$scope.article.contentES,
			}
			
			$http.post('/api/admin/updatearticle',articleObj).success(function(response) {
				
				if(response.status == 'success') {	
					$rootScope.saveContentMsg="Content Successfully Saved.";
					$location.path("/admin/listArticles");
				
				} else {
					
					if(response.status == 'fail') {
					} else {
						$scope.error = response.status;
					}
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		// Remove existing Expense
		$scope.delete = function(id) {

			if(id) {
				
				var articleObj = {
					id  : id
				}
				
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/deleteArticle',articleObj).success(function(response) {
						
						if(response.status == 'success') {
							
							var article_id = '#list_'+id; 
							$(article_id).remove();
							$scope.success = [{ "msg" :  "Article deleted Successfully	" }];;

						} else {
						}	
					}).error(function(response) {
					});
				}
			
			} else {
			}	
		};
		$scope.cancel = function (req , res) {
			$location.path('/admin/listArticles');
		};
	}
]);