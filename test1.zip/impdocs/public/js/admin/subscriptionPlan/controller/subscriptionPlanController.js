var subscriptionPlanModule = angular.module('subscriptionPlanModule');


subscriptionPlanModule.controller('adminSubscriptionPlanController', ['$rootScope','$scope','$http', '$location', '$routeParams',
	
	function($rootScope,$scope, $http, $location, $routeParams) {

		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};
		
		// Create new Composer
		$scope.create = function() {

			$http.post('/api/admin/addSubscriptionPlan',$scope.plan).success(function(response) {

				if(response.status == 'success') {
					$rootScope.saveContentMsg="Record successfully saved.";
			        $location.path("/admin/listSubscriptionPlan");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status
						
					}	
				}	
			}).error(function(response) {
				//$scope.error = response.message;
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Create new Composer
		$scope.listSubscriptionPlan = function() {
			$http.get('/api/admin/listSubscriptionPlan').success(function(response) {

				$scope.subscriptionPlan = response;
				if ($rootScope.saveContentMsg && $rootScope.saveContentMsg != null) {
					$scope.success = [{ "msg" :  $rootScope.saveContentMsg }];
					$rootScope.saveContentMsg = '';
				}
				
				//Pagination param
				$scope.currentPage = 1;
  				$scope.pageSize = 10;

			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Edit new get Subscription Plan
		$scope.getSubscriptionPlan = function() {
			var planID = $routeParams.planID;
			
			var planObj = {
				id	: planID
			};			
			
			$http.post('/api/admin/getSubscriptionPlan', planObj).success(function(response) {
				$scope.plan = response;
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Create new Composer
		$scope.update = function() {

			var planObj = {
				id 				: $scope.plan.id,
				name 			: $scope.plan.name,
				price 			: $scope.plan.price,
				description 	: $scope.plan.description,
				descriptionFR 	: $scope.plan.descriptionFR,
				descriptionES 	: $scope.plan.descriptionES,
				descriptionTW 	: $scope.plan.descriptionTW,
				descriptionCH 	: $scope.plan.descriptionCH,
			}
			$http.post('/api/admin/updatesubscriptionplan',planObj).success(function(response) {
				if(response.status == 'success') {	
					$rootScope.saveContentMsg="Record successfully updated.";
					$location.path("/admin/listSubscriptionPlan");
				} else {
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status;
					}
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Remove existing Expense
		$scope.delete = function(id) {

			if(id) {
				
				var planObj = {
					id  : id
				}
				
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/deletesubscriptionplan',planObj).success(function(response) {
						
						if(response.status == 'success') {
							
							var plan_id = '#list_'+id; 
							$(plan_id).remove();
							$scope.success = [{ "msg" :  "Record successfully deleted." }];

						} else {
							$scope.error = [{ "msg" :  "Something went wrong." }];
						}	
					}).error(function(response) {
						$scope.error = [{ "msg" :  "Something went wrong." }];
					});
				}
			
			} else {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			}	
		};
		$scope.cancel = function (req , res) {
			$location.path('/admin/listSubscriptionPlan');
		};
	}
]);