/**
    * Subscription Plan module routes
*/
var app = angular.module('subscriptionPlanModule', [
    'ngRoute',
    'angularUtils.directives.dirPagination',
    'colorpicker.module',
    'wysiwyg.module',
]);

app.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
    .when("/admin/listSubscriptionPlan", {
        resolve:{loggedIn:onlyLoggedInAdmin}, 
        templateUrl: "templates/admin/partials/subscriptionPlan/index.html",
    })
    .when("/admin/addSubscriptionPlan", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/subscriptionPlan/addPlan.html", 
    })
    .when("/admin/editSubscriptionPlan/:planID", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/subscriptionPlan/edit.html", 
    })
    /*.when("/admin/subscriptionReminder", {
        controller: "reminderCtrl" ,
        templateUrl: "templates/admin/partials/subscriptionPlan/subReminder.html",
    })*/
    .otherwise("/admin/login");
}]);


app.controller('reminderCtrl', function ($scope, $route, $timeout, $location, $http) {
    
    //console.log("Reminder mail");
    $http.post('/api/admin/subscriptionReminder').success(function(response) {
        //console.log("----Get result----");
        //console.log(response);

    }).error(function(response) {
        $scope.error = [{ "msg" : "Something went wrong" }];
    });
});