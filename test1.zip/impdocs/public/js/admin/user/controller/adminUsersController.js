'use strict';

var adminUsers_module = angular.module('userPageModule');

adminUsers_module.controller('adminUsersController', ['$rootScope','$scope', '$route', '$http', '$location', '$timeout', '$routeParams', 'Upload', 'Auth',
	function($rootScope, $scope, $route, $http, $location, $timeout, $routeParams, Upload, Auth) {

		$scope.user = "";
		$scope.UserProfilePicture = "";


		
		// START: Datepicker Settings ==============================================
		$scope.status1 = {
            opened: false
        };
        $scope.status2 = {
            opened: false
        };

        $scope.formats = ['MM/dd/yyyy','dd/MMMM/yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
  		$scope.format = $scope.formats[0];
        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 1
        };
        
        $scope.open1 = function($event) {
            $scope.status1.opened = true;
        };

        $scope.open2 = function($event) {
            $scope.status2.opened = true;
        };
		
        // End: Datepicker Settings ==============================================




		/*Get a list of days as per selected Month and Year*/
		$scope.getDaysArray = function() {
			var month = $scope.birthdayMonth;
			var year = $scope.birthdayYear;
			$scope.getDays(month, year);
		}

		/*Function for calculating days of month as per selected month and year*/
		$scope.getDays = function(month, year) {
			
		  	if(month == '01' || month == '03' || month == '05' || month == '07' || month == '08' || month == '10' ||  month == '12'){
		  		var startDay = 1;
		  		var endDay = 31;
			}
			else if(month == '04' || month == '06' || month == '09' || month == '11'){
				var startDay = 1;
		  		var endDay = 30;
			}
			else if(month == '02'){
				if ((parseInt(year)%4) == 0){
					if (parseInt(year)%100 == 0){
						if (parseInt(year)%400 == 0){
							var startDay = 1;
	  						var endDay = 29;
						}
						else {
							var startDay = 1;
	  						var endDay = 28;
						}	
					}else{
						var startDay = 1;
  						var endDay = 29;
					}
				}else{
					var startDay = 1;
					var endDay = 28;
				}
			}else	
			{
				var startDay = 1;
		  		var endDay = 31;
			}

		  	var fullDay = [];
		    for (var i=startDay; i<=endDay; i++) {

		    	if(i<=9)
		    		i = '0'+i;

		    	var newarray = {
		    		'value' : i,
		    		'day' : i 
		    	};
				fullDay.push(newarray);
		    }
		    $scope.bDay = fullDay;
		};


		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};
      

      	/*Get a list of days as per selected Month and Year*/
		$scope.preFillData = function() {
			
			var currentUrl = $location.path();
			var res = currentUrl.split("/");
			console.log(res);
			if(res[2] == 'editAdmin' || res[2] == 'addAdmin') {
			
				$scope.pageTitle = "Admin";
				$scope.isAdmin = 1;
			
			} else {
			
				$scope.pageTitle = "Subscriber";
				$scope.isAdmin = 0;
			
			}

			var curYear = new Date().getFullYear();
		  	var startYear = 1900;
		  	$scope.birthdayYear = 1980;
		  	$scope.birthdayDay = '01';
		    $scope.birthdayMonth = '01';
		    $scope.gender = 'Male';
		  	var fullYear = [];
		    for (var i=startYear; i<=curYear; i++) {

		    	var newarray = {
		    		'value' : i,
		    		'year' : i 
		    	};

				fullYear.push(newarray);
		    }
		    $scope.bYear = fullYear;
		    $scope.getDays($scope.birthdayMonth , $scope.birthdayYear);

			// Get list of secret Questions
			$scope.secretQuestion = '';
			$http.get('/api/general/listsecretquestions').success(function(response) {
				$scope.questionId = response[0].id;
				$scope.secretQuestion = response;	
			}).error(function(response) {
				$scope.error = response.message;
			});
		}

		// Create new User
		$scope.create = function() {

			if($scope.birthdayYear != "" && $scope.birthdayYear != undefined && $scope.birthdayMonth != "" && $scope.birthdayMonth != undefined && $scope.birthdayDay != "" && $scope.birthdayDay != undefined ) {
				var birthday = $scope.birthdayYear+"-"+$scope.birthdayMonth+"-"+$scope.birthdayDay;	
			} else {
				$scope.error = [{ "msg" : "Date is Required." }];
				return false;
			}
			
			$scope.user.gender = $scope.gender
			$scope.user.birthday = birthday;
			$scope.user.questionId = $scope.questionId;
			$scope.user.isAdmin = $scope.isAdmin;
			$scope.user.userStatus = 1;

			
			$http.post('/api/admin/user/adduser',$scope.user).success(function(response) {

				if(response.status == 'success') {	
					$scope.user = '';
					if($scope.isAdmin == 1) {
			        	$rootScope.saveUserMsg = [{ "msg" : "Record successfully saved." }];
			        	$location.path("/admin/admin");
			        } else {
			        	$rootScope.saveUserMsg = [{ "msg" : "Record successfully saved." }];
			        	$location.path("/admin/user");	
			        }
				} else {
					if(response.status == 'fail') {
						$scope.error = [{"msg":"Failed to save."}];
						$scope.success = "";
					} else {
						$scope.error = response.status;
					}	
				}
			}).error(function(err) {
				$scope.error = [{ "msg" : err.message }];
			});
		};

		
		//Create new User
		$scope.list_user = function() {

			var curPath = '';
			var listTitle = '';
			var currentUrl = $location.path();
			var res = currentUrl.split("/");
			if(res[2] == 'admin') {
			
				curPath = 'admin';
				listTitle = "Admin";
			
			} else {
				
				curPath = 'subscriber';
				listTitle = "Subscriber";
			
			}	
			var obj = {
				curPath : curPath
			};

			$http.post('/api/admin/user/listuser',obj).success(function(response) {

				//$scope.success = [{ "msg" :  $rootScope.showmessage }];
				if ($rootScope.saveUserMsg && $rootScope.saveUserMsg != null) {
					$scope.success = $rootScope.saveUserMsg;
					$rootScope.saveUserMsg = '';
				}
				
				//$scope.a  =  $rootScope.showmessage;
				$scope.listTitle =  listTitle;
				$scope.users = response;
				
				//Pagination param
				$scope.currentPage = 1;
  				$scope.pageSize = 10;

			}).error(function(response) {
				$scope.error = response.message;
			});
		};


		/* Get a profile data of current logged in user */
		$scope.getUser = function() {
			
			if($routeParams.id != "" || $routeParams.id != undefined) {
				
				var user_id = $routeParams.id;
				var useridobj = {
					user_id		: user_id
				}

				var currentUrl = $location.path();
				var res = currentUrl.split("/");
				
				if(res[2] == 'editAdmin' || res[2] == 'addAdmin'){
					$scope.pageTitle = "Admin";
				} else{
					$scope.pageTitle = "Subscriber";
				}

				// Get list of secret Questions
				$scope.secretQuestion = '';
				$http.get('/api/general/listsecretquestions').success(function(response) {
					$scope.secretQuestion = response;
				}).error(function(response) {
					$scope.error = response.message;
				});

				$http.post('/api/admin/user/getuser',useridobj).success(function(response) {
					
					


					$scope.user 	= response;
					$scope.user_id 	= response.id;
					
					//$scope.user = usersession;
					$scope.user.password = "";

				  	/*var d = new Date($scope.user.birthday);
				  	$scope.birthdayYear = d.getFullYear();
				  	if(d.getDate() < 10) {
				  		$scope.birthdayDay = ("0" + d.getDate()).slice(-2);	
				  	} else {
				  		$scope.birthdayDay = d.getDate();	
				  	}
				  	$scope.birthdayMonth = ("0" + (d.getMonth() + 1)).slice(-2);*/

				    var arrayYear 	= $scope.user.birthday.split('T');
				  	var fullDate   	= arrayYear[0].split('-') 
				  	

				  	$scope.birthdayYear 	= parseInt(fullDate[0]);
				  	$scope.birthdayMonth    = fullDate[1];
				  	$scope.birthdayDay 		= (parseInt(fullDate[2]) < 10) ?  ("0" + (fullDate[2])).slice(-2) : parseInt(fullDate[2]);


				    $scope.gender = $scope.user.gender;
				    $scope.questionId = $scope.user.questionId;
				  	
					
					var curYear = new Date().getFullYear();
				  	var startYear = 1900;
				  	var fullYear = [];
				    for (var i = startYear; i <= curYear; i++) {

				    	var newarray = {
				    		'value' : i,
				    		'year' : i 
				    	};
						fullYear.push(newarray);
				    }
				    
				    $scope.bYear = fullYear;

					$scope.user.startAt = new Date(response.Subscriptions[0].startAt);
					$scope.user.endAt 	= new Date(response.Subscriptions[0].endAt);
				    
				    
				    //Call function for get proper number of day for date selection
				    $scope.getDays($scope.birthdayMonth, $scope.birthdayYear);
					$scope.change_pw = 0;


				}).error(function(response) {
					$scope.error = response.message;
				});    
			
			} else {
				$scope.user = "";
				$location.path("/");
			}	
		};

		/* Update user profile */
		$scope.updateProfile = function() {

			$scope.userAuthenticated = $scope.user;

			if($scope.birthdayYear != "" && $scope.birthdayYear != undefined && $scope.birthdayMonth != "" && $scope.birthdayMonth != undefined && $scope.birthdayDay != "" && $scope.birthdayDay != undefined ) {
				var birthday = $scope.birthdayYear+"-"+$scope.birthdayMonth+"-"+$scope.birthdayDay;	
			} else {
				$scope.error = [{ "msg" : "Date is Required" }];
				return false;
			}
			
			$scope.userAuthenticated.gender = $scope.gender;
			$scope.userAuthenticated.birthday = birthday;
			$scope.userAuthenticated.questionId = $scope.questionId;
			$scope.userAuthenticated.change_pw = $scope.change_pw;

			if($scope.userAuthenticated.change_pw == 1) {
				$scope.userAuthenticated.password = $scope.password;
			}	

			//console.log($scope.userAuthenticated);

			$http.post('/api/admin/user/updateuser	',$scope.userAuthenticated).success(function(response) {
				
				//console.log(response);
				if(response.status == 'success') {	
		        	
		        	$rootScope.saveUserMsg = [{ "msg" : "Record successfully updated." }];
					
					if($scope.userAuthenticated.isAdmin == true) {
			        	$location.path("/admin/admin");
			        } else {
			        	$location.path("/admin/user");	
			        }
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{"msg":"Failed to update record."}];
					} else {
						$scope.error = response.status;
					}
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};


		// Create new User
		$scope.update = function() {
			$scope.user.change_pw = $scope.change_pw;

			if($scope.user.change_pw == 1) {
				$scope.user.password = $scope.password;
			}	

			$http.post('/api/admin/user/updateuser',$scope.user).success(function(response) {
				if(response.status == 'success') {	
					$location.path("/admin/user");
				} else {
					
					if(response.status != 'fail') {
						$scope.error = response.status;
					}
				}	
			}).error(function(response) {
				$scope.error = response.message;
				
			});
		};

		// Remove existing Expense
		$scope.delete = function(userid, index) {
			if(userid) {
				var userobj = {
					user_id  : userid
				}
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/user/deluser',userobj).success(function(response) {
						if(response.status == 'success') {
							$scope.users.splice(index, 1);
							var user_id = '#list_'+userid; 
							$(user_id).remove();
							$scope.success = [{ "msg" : "Record successfully deleted." }];
						}else {
							$scope.error = [{ "msg" :  "Something went wrong." }];
						}							
					}).error(function(response) {
			            $scope.error = [{ "msg" :  "Something went wrong." }];
					});
				}
			}			
		};

		$scope.cancel = function (req , res) {
			
			var currentUrl = $location.path();
			var res = currentUrl.split("/");
			if(res[2] == 'editAdmin'){
				$location.path('/admin/admin');
			} else {
				$location.path('/admin/user');
			}
		};

		/* Upload user profile picture */
		$scope.uploadFiles = function(file, errFiles) {
	       	var usersession = Auth.getCurrentUser();
			var user_id = $routeParams.id;

			console.log(user_id);

	        if (file) {
	            file.upload = Upload.upload({
	                url: '/api/general/imageUpload',
	                data: {file: file, user_id : user_id, idType : "normal"}
	            });
	            file.upload.then(function (response) {
	            	if(response.data.status == "succ")
	            	{
	            		$scope.user.profilePicture = response.data.filename;
	            		$route.reload();
	            	}	
	            	else
	            	{
	            		$scope.UserProfilePicture = "";
	            	}	
	            }, function (response) {
	            	$scope.error = response.status + ': ' + response.data;
	            }, function (evt) {
	                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
	            });
	        }   
	    };

	}
]);


adminUsers_module.directive('matchPassword', function() {
  	return {
    	
    	restrict: 'A',
    	require: ['^ngModel', '^form'],
    	
    	link: function(scope, element, attrs, ctrls) {
      		
      		var formController = ctrls[1];
      		var ngModel = ctrls[0];
      		var otherPasswordModel = formController[attrs.matchPassword];
  
      		ngModel.$validators.passwordMatch = function(modelValue, viewValue) {
        		var password = modelValue || viewValue;
        		var otherPassword = otherPasswordModel.$modelValue || otherPasswordModel.viewValue;
        		//console.log('modelValue || viewValue', password, otherPassword);
        		return password === otherPassword;
      		};

    	} // end link
  	}; // end return
});

adminUsers_module.directive('uniqueEmail', function($http, $q) {
  	return {
    	require : 'ngModel',
    	link : function($scope, element, attrs, ngModel) {
      		ngModel.$asyncValidators.uniqueEmail = function(modelValue, viewValue) {
        		var email = modelValue || viewValue;
        		
        		return $http.post('/api/admin/user/uniqueEmail', {email: email}).then(function(res) {
          			console.log(res.data);	
          			if (res.data.exists == 'true') {
            			return $q.reject();
          			}
          			return $q.when();
        		});
      		}; // end async
    	} // end link
  	}; // end return 
});

adminUsers_module.directive('uniqueEmailEdit', function($http, $q, $routeParams) {
  	return {
    	require : 'ngModel',
    	link : function($scope, element, attrs, ngModel) {
	      	ngModel.$asyncValidators.uniqueEmailEdit = function(modelValue, viewValue) {
	        	
	        	var email 		= modelValue || viewValue;
	        	var user_id 	= $routeParams.id;
	        	var isAdmin 	= ($scope.pageTitle == 'Admin') ? true : false;
	        	
	        	return $http.post('/api/admin/user/uniqueEmailEdit', {email : email, user_id : user_id, isAdmin : isAdmin}).then(function(res) {
	          		if (res.data.exists == 'true') {
	            		return $q.reject();
	          		}
	          		return $q.when();
	        	});
	      	
	      	}; // end async
    	} // end link
  	}; // end return 
});