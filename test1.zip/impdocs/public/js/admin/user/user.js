/**
    * User Module Routes
*/
var app = angular.module('userPageModule', [
    'ngRoute',
    'angularUtils.directives.dirPagination',
]);

app.config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when("/admin/user", {
            resolve:{loggedIn:onlyLoggedInAdmin},
            templateUrl: "templates/admin/partials/user/index.html", 
        })
        .when("/admin/admin", {
            resolve:{loggedIn:onlyLoggedInAdmin},
            templateUrl: "templates/admin/partials/user/adminUser.html", 
        })
        .when("/admin/addSubscriber", {
            resolve:{loggedIn:onlyLoggedInAdmin},
            templateUrl: "templates/admin/partials/user/addUser.html", 
        })
      .when("/admin/editSubscriber/:id", {
          resolve:{loggedIn:onlyLoggedInAdmin},
          templateUrl: "templates/admin/partials/user/edit.html", 
      })
      .when("/admin/addAdmin", {
          resolve:{loggedIn:onlyLoggedInAdmin},
          templateUrl: "templates/admin/partials/user/addUser.html", 
      })
      .when("/admin/editAdmin/:id", {
          resolve:{loggedIn:onlyLoggedInAdmin},
          templateUrl: "templates/admin/partials/user/edit.html", 
      })
}]);