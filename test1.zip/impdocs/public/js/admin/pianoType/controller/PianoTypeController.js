var pianoTypeModule = angular.module('pianoTypeModule');

adminComposersModule.controller('adminPianoTypeController', ['$rootScope','$scope','$http', '$location', '$routeParams',
	
	function($rootScope,$scope, $http, $location, $routeParams) {


		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};
		
		// Create new Composer
		$scope.create = function() {
			
			//console.log($scope.pianoType);

			$http.post('/api/admin/addPianoType',$scope.pianoType).success(function(response) {

				if(response.status == 'success') {
					$scope.user = '';
				   
					$rootScope.savePianoTypeMsg="Record successfully saved.";
			        $location.path("/admin/listPianoType");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status
					}	
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Create new Composer
		$scope.listPianoType = function() {
			$http.get('/api/admin/listPianoType').success(function(response) {

				$scope.pianoTypes = response;
				if ($rootScope.savePianoTypeMsg && $rootScope.savePianoTypeMsg != null) {
					$scope.success = [{ "msg" :  $rootScope.savePianoTypeMsg }];
					$rootScope.savePianoTypeMsg = '';
				}
				
				//Pagination param
				$scope.currentPage = 1;
  				$scope.pageSize = 10;

			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Edit new PianoType
		$scope.getPianoType = function() {
			
			var pianoTypeID = $routeParams.pianoTypeID;
			
			var pianoTypeObj = {
				id	: pianoTypeID
			}			
			
			$http.post('/api/admin/getPianoType', pianoTypeObj).success(function(response) {
				$scope.pianoType = response;
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		
		};

		// Create new Composer
		$scope.update = function() {

			var pianoTypeObj = {
				id:$scope.pianoType.id,
				title: $scope.pianoType.title
			}
			
			$http.post('/api/admin/updatePianoType',pianoTypeObj).success(function(response) {
				
				if(response.status == 'success') {	
					
					
					$rootScope.savePianoTypeMsg="Record successfully updated.";
					$location.path("/admin/listPianoType");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status;
					}
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Remove existing Expense
		$scope.delete = function(id, index) {

			if(id) {
				
				var pianoTypeObj = {
					id  : id
				}
				
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/deletePianoType',pianoTypeObj).success(function(response) {
						
						if(response.status == 'success') {
							$scope.pianoTypes.splice(index, 1);
							var pianoType_id = '#list_'+id; 
							$(pianoType_id).remove();
							$scope.success = [{ "msg" :  "Record successfully deleted." }];
						} else {
							$scope.error = [{ "msg" :  "Something went wrong." }];
						}	
					}).error(function(response) {
						$scope.error = [{ "msg" :  "Something went wrong." }];
					});
				}
			} else {
				$scope.error = [{ "msg" :  "Select any Piano type." }];
			}	
		};
		$scope.cancel = function (req , res) {
			$location.path('/admin/listPianoType');
		};
	}
]);