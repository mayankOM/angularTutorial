/**
 * Piano Type Module routes
 */
var app = angular.module('pianoTypeModule', [
  'ngRoute',
  'angularUtils.directives.dirPagination',
]);

app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
      .when("/admin/listPianoType", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/pianoType/index.html", 
      })
      .when("/admin/addPianoType", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/pianoType/addPianoType.html", 
      })
      .when("/admin/editPianoType/:pianoTypeID", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/pianoType/edit.html", 
      })
}]);