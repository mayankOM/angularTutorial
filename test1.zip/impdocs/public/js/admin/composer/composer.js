/**
 * Composer Module Routes
 */
var app = angular.module('composerModule', [
  'ngRoute',
  'angularUtils.directives.dirPagination',
  'ngSanitize',
  'ngCsv',
]);

app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
      .when("/admin/listComposers", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/composer/index.html"
      })
      .when("/admin/jsonComposerExport", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/composer/composerJSONExport.html", 
      })
      .when("/admin/xmlComposerExport", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/composer/composerXMlExport.xml", 
      })
      .when("/admin/addComposer", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/composer/addComposer.html", 
      })
      .when("/admin/editComposer/:composerID", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/composer/edit.html", 
      })
}]);