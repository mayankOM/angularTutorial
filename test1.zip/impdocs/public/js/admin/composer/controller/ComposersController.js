var adminComposersModule = angular.module('composerModule');

adminComposersModule.controller('adminComposersController', ['$rootScope','$scope','$http', '$location', '$routeParams', '$filter', '$window',
	
	function($rootScope,$scope, $http, $location, $routeParams, $filter, $window) {

		$scope.composerDataCSV = "";
		$rootScope.getComposerJSONData = "";
		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};
		
		// Create new Composer
		$scope.create = function() {
			
			$http.post('/api/admin/addComposer',$scope.user).success(function(response) {

				if(response.status == 'success') {
					$scope.user = '';
				   
					$rootScope.saveComposerMsg="Record saved successfully.";
			        $location.path("/admin/listComposers");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Record failed to save." }];
					} else {
						$scope.error = response.status
					}	
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Create new Composer
		$scope.listComposers = function() {
			$http.get('/api/admin/listComposers').success(function(response) {

				$scope.composers = response;
				if ($rootScope.saveComposerMsg && $rootScope.saveComposerMsg != null) {
					$scope.success = [{ "msg" :  $rootScope.saveComposerMsg }];
					$rootScope.saveComposerMsg = '';
				}
				
				//Pagination param
				$scope.currentPage = 1;
  				$scope.pageSize = 10;

  				$rootScope.getComposerJSONData = response;

  				//get a list of Cumposer for export data
	    		//$scope.getComposerCSV();
	    		var today  = new Date();
				var todayDate = $filter('date')(today, "yyyy-MM-dd");
  				$scope.filename = "composerCSV_"+todayDate;
				$scope.composerDataCSV = response;
				$scope.getHeader = ["Composer ID", "First Name", "Last Name", "Created At", "Updated At"];
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Edit new Composer
		$scope.getComposer = function() {
			
			var composerID = $routeParams.composerID;
			var composerObj = {
				id	: composerID
			}			
			
			$http.post('/api/admin/getComposer', composerObj).success(function(response) {
				$scope.composer = response;
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Create new Composer
		$scope.update = function() {

			var composerObj = {
				id:$scope.composer.id,
				firstName: $scope.composer.firstName,
				lastName:$scope.composer.lastName
			}
			$http.post('/api/admin/updatecomposer',composerObj).success(function(response) {
				if(response.status == 'success') {	

					$rootScope.saveComposerMsg="Record updated successfully.";
					$location.path("/admin/listComposers");

				} else {

					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Record failed to save." }];
					} else {
						$scope.error = response.status;
					}

				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Remove existing Expense
		$scope.delete = function(id, index) {
			if(id) {
				var composerObj = {
					id  : id
				}
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/deleteComposer',composerObj).success(function(response) {
						if(response.status == 'success') {
							$scope.composers.splice(index, 1);
							var composer_id = '#list_'+id; 
							$(composer_id).remove();
							$scope.success = [{ "msg" :  "Record deleted successfully." }];
						} else {
						}	
					}).error(function(response) {
						$scope.error = [{ "msg" :  "Something went wrong." }];
					});
				}
			
			} else {
				$scope.error = [{ "msg" :  "Please select composer." }];
			}	
		};
		$scope.cancel = function (req , res) {
			$location.path('/admin/listComposers');
		};


		/*Get a composer data for export data*/
		$scope.getComposerData = function(exportBy, e) {

			var obj = {
				'exportBy' : exportBy	//JSON or XML
			};

			$http.post('/api/admin/getExportData',obj).success(function(response) {
				
				if(response.status == "fail") {
					
					$scope.error = [{ "msg" :  "Failed to load data." }];
					$scope.composerDataCSV = "";
				} else {
					
					if(exportBy == 'JSON') {
						window.open('/dwld/json','_blank');
						$scope.success = [{ "msg" :  "jSON File Exported." }];
					} else {
						window.open('/dwld/xml','_blank');
						$scope.success = [{ "msg" :  "XML File Exported." }];
						$scope.error = "";
					}					
				}
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};		
	}
]);