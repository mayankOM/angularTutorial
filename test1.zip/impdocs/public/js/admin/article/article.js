/**
 * Article module routes
 */
var app = angular.module('articleModule', [
  'ngRoute',
  'angularUtils.directives.dirPagination',
  'colorpicker.module',
  'wysiwyg.module',
]);

app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
      .when("/admin/listArticles", {
        resolve:{loggedIn:onlyLoggedInAdmin}, 
        templateUrl: "templates/admin/partials/article/index.html",
      })
      .when("/admin/addArticle", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/article/addArticle.html", 
      })
      .when("/admin/editArticle/:articleID", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/article/edit.html", 
      })
      .otherwise("/admin/login");
}]);