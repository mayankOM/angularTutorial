'use strict';

angular.module('authModule').factory('Auth', function Auth($location, $rootScope, $http, $cookieStore, $q, $localStorage) {
    
    var currentUser = {};
    var getCookies = {};

    if($cookieStore.get('token')) {
        //currentUser = $sessionStorage.get('userSession');
        currentUser = $localStorage.localStorageData;
    }

    /*var currentUser = {};
  
    if($cookieStore.get('token')) {
        var currentUser = {};
        if($cookieStore.get('token')) {
            currentUser = User.get();
        } else {
            $location.path("/admin/login");
        }


    }*/

    return {

        /**
            * Authenticate user and save token
            *
            * @param  {Object}   user     - login info
            * @param  {Function} callback - optional
            * @return {Promise}
        */
        
        /*login: function(user, callback) {
            
            var cb = callback || angular.noop;
            var deferred = $q.defer();

            
            $http.defaults.useXDomain = true;

            var rememberMe = user.rememberMe;
            var rememberEmail = user.email;
            var rememberPass = user.password;

            $http.post("/api/admin/auth/signin", user).success(function(data) {
                
                console.log("---Get a login user data----");
                console.log(data);

                if(data.status == 'fail') {
                    deferred.reject({ status: "Login failed in res" });
                } else {
                    
                    var rand = Math.random().toString(36).substr(2);  
                    $cookieStore.put('token', rand);
                    deferred.resolve(data);
                    return cb();
                    
                } 
                
            }).error(function(err) {
            
                this.logout();
                deferred.reject(err);
                return cb(err);
            
            }.bind(this));
            return deferred.promise;
        },*/


        login: function(user, callback) {
            
            var cb = callback || angular.noop;
            var deferred = $q.defer();

            console.log("----In admin auth ----");
            console.log(user);

            var rememberMe = user.rememberMe;
            var rememberEmail = user.email;
            var rememberPass = user.password;
            user.loginBy = 'admin';
            $http.post("/api/admin/auth/signin", user).success(function(data) {

                if(data.status == 'fail') {
                    deferred.reject({ status: "Login failed in res" });
                } else {

                    var rand = Math.random().toString(36).substr(2);  
                    $cookieStore.put('token', rand);

                    if(rememberMe == true)
                    {
                        var obj = {
                            'rememberMe'    :   rememberMe,
                            'rememberEmail' :   rememberEmail,
                            'rememberPass'  :   rememberPass
                        };
                        $http.post('/api/admin/auth/enc',obj).success(function(response) {
                            $cookieStore.put('setMeAdmin', rememberMe);
                            $cookieStore.put('cookieEmailAdmin', response.encEmail);
                            $cookieStore.put('cookiePasswordAdmin', response.encPass);
                        }).error(function(response) {
                            $scope.error = response.message;
                        });                        
                    }
                    else
                    {
                        $cookieStore.put('setMeAdmin', false);
                        $cookieStore.put('cookieEmailAdmin', '');
                        $cookieStore.put('cookiePasswordAdmin', ''); 
                    }
                    $localStorage.localStorageData = data;
                    deferred.resolve(data);
                }
                return cb();
            
            }).error(function(err) {
            
                this.logout();
                //$sessionStorage.remove('userSession');
                //$sessionStorage.empty();
                $localStorage.localStorageData = '';
                //$localStorage.$reset();
                deferred.reject(err);
                return cb(err);
            
            }.bind(this));
            return deferred.promise;
        },


        /**
            * Delete access token and user info
            *
            * @param  {Function}
        */
        logout: function() {
            /*$cookieStore.remove('token');
            currentUser = {};
            return $http.get("/api/admin/auth/signout");*/
            $cookieStore.remove('token');
            $localStorage.localStorageData = '';
            //$localStorage.$reset();
            currentUser = {};
            return $http.get("/api/admin/auth/signout");
        },

        /**
            * Create a new user
            *
            * @param  {Object}   user     - user info
            * @param  {Function} callback - optional
            * @return {Promise}
        */
        createUser: function(user, callback) {
            
            var cb = callback || angular.noop;
            return User.save(user, function(data) {
            
                $cookieStore.put('token', data.token);
                currentUser = User.get();
                return cb(user);
            
            }, function(err) {
                this.logout();
                return cb(err);
            }.bind(this)).$promise;
        },

        /**
            * Change password
            *
            * @param  {String}   oldPassword
            * @param  {String}   newPassword
            * @param  {Function} callback    - optional
            * @return {Promise}
        */
        changePassword: function(oldPassword, newPassword, callback) {
            
            var cb = callback || angular.noop;
            return User.changePassword({ id: currentUser._id }, {
                oldPassword: oldPassword,
                newPassword: newPassword
            }, function(user) {
                return cb(user);
            }, function(err) {
                return cb(err);
            }).$promise;
        },

        /**
            * Gets all available info on authenticated user
            *
            * @return {Object} user
        */
        getCurrentUser: function() {
            /*User.get().$promise.then(function(user){
                currentUser = user;
                console.log("rajat again in getcurrent");
                console.log(currentUser);
                return currentUser;
            });*/
           return currentUser = $localStorage.localStorageData;
        },

        getAuth: function() {
            var promise = $http({ 
                method: 'GET', 
                url: '/api/admin/auth/getSession' 
            });
            promise.success(function(data, status, headers, conf) {
                if(!data.id) {
                    $location.path("/admin/login");
                }
            });
            return promise;
        },

        /**
            * Waits for currentUser to resolve before checking if user is logged in
        */
        isLoggedInAsync: function(cb) {
            //if($sessionStorage.get('userSession')) {
            if($localStorage.localStorageData) {
                cb(true);
            } else {
                cb(false);
            } 
        },

        /**
            * Check if a user is logged in
            *
            * @return {Boolean}
        */
        isLoggedIn: function(cb) {
            return currentUser.hasOwnProperty('role');
        },

        /**
            * Check if a user is an admin
            *
            * @return {Boolean}
        */
        isAdmin: function() {
            return currentUser.isAdmin === true;
        },

        /**
            * Get auth token which is stored in cookie
        */
        getToken: function() {
            return $cookieStore.get('token');
        },

        /**
            * Get Cookies data
        */
        getCookies: function() {
            //console.log($cookieStore.get('token'));
            return getCookies = {
                'setMeAdmin' : $cookieStore.get('setMeAdmin'),
                'cookieEmailAdmin' : $cookieStore.get('cookieEmailAdmin'),
                'cookiePasswordAdmin' : $cookieStore.get('cookiePasswordAdmin')
            };
        }


    };
});
