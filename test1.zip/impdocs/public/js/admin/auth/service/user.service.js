'use strict';

angular.module('authModule').factory('User', function ($resource) {
    return $resource('/api/admin/auth/getSession', {
        id: '@_id'
    },{
        get: {
            method: 'GET',
            url: '/api/admin/auth/getSession'
        },getUser: {
            method: 'GET',
            url: '/api/admin/auth/getSession'
        },
    });
});
