//Authentication Controller
var authController = angular.module("authModule");

authController.controller('authController', ["$rootScope","$scope","$timeout","$location", "$http", "Auth",
	function($rootScope, $scope, $timeout, $location, $http, Auth) {

		$scope.userAuthentication = "";
		$rootScope.adminUserAuthenticated = "";
		var config = {};
		
		/* Get Cookies Detail */
		$scope.getCookieData = function() {
			if(!Auth.getCurrentUser()) {
				var cookiesData = Auth.getCookies();
		        $scope.credentials = {};
		        $scope.credentials.rememberMe = cookiesData.setMeAdmin;
		        if(cookiesData.setMeAdmin == true)
		        {
					$http.post('/api/admin/auth/dec',cookiesData).success(function(response) {
		                $scope.credentials.rememberMe = cookiesData.setMeAdmin;
			        	$scope.credentials.email = response.decEmail;
			        	$scope.credentials.password = response.decPass;
		            }).error(function(response) {
		                $scope.error = response.message;
		            });
		        }
			}
		}

		$scope.signin = function() {
			Auth.login({
				email: $scope.credentials.email,
				password: $scope.credentials.password,
				rememberMe: $scope.credentials.rememberMe
			}).then(function() {
				$location.path('/admin');
			}).catch( function(err) {
				$scope.error = [{ "msg" : "Email or Password is invalid." }];
			});
		};
		
		$scope.logout = function() {
			
			Auth.logout().success(function (data) {
				
				if(data && data.status && data.status == "success") {
						$location.path('/admin/login');
				
				} else {

					alert("There is Some Problem in Logout.");
				
					/*setTimeout(function () {
						growl.error("something went wrong", config);
					}, 200);*/
				
				}
			});
		};
		
		/*Get a list of days as per selected Month and Year*/
		$scope.checkUser = function() {
			console.log("---Hello cehck user----");
			if(Auth.getCurrentUser()) {
			
				var usersession = Auth.getCurrentUser();
				var user_id = usersession.id;
				var useridobj = {
					user_id		: user_id
				}
				$http.post('/api/admin/auth/getuser',useridobj).success(function(response) {
					$rootScope.adminUserAuthenticated = response;
					$scope.userAuthentication = response;
				}).error(function(response) {
					$scope.error = response.message;
				}); 
			}
		}

	}
]);