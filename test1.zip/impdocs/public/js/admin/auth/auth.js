/**
* Auth Module Routes
*/
var app = angular.module('authModule', [
  	'ngRoute',
  	'ngCookies',
  	'ngResource',
]);

app.config(['$routeProvider', function ($routeProvider) {

	$routeProvider.when("/admin/login", {
		templateUrl: "templates/admin/partials/auth/login.html"
	});

}]);