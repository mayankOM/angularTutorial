var adminInstrumentsModule = angular.module('instrumentModule');


adminInstrumentsModule.controller('adminInstrumentsController', ['$rootScope','$scope','$http', '$location', '$routeParams',
	
	function($rootScope,$scope, $http, $location, $routeParams) {

		var config = {};
		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};		
		// Create new Composer
		$scope.create = function() {

			$http.post('/api/admin/addInstrument',$scope.instrument).success(function(response) {

				if(response.status == 'success') {
					
					$rootScope.saveInstrumentMsg="Record successfully saved.";
			        $location.path("/admin/listInstruments");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status
					}	
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// List Genres/ libraries
		$scope.listInstruments = function() {
			$http.get('/api/admin/listInstruments').success(function(response) {
				$scope.instruments = response;	
				if ($rootScope.saveInstrumentMsg && $rootScope.saveInstrumentMsg != null) {
					$scope.success = [{ "msg" :  $rootScope.saveInstrumentMsg }];
					$rootScope.saveInstrumentMsg = '';
				}			
				$scope.currentPage = 1;
  				$scope.pageSize = 10;

			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Edit Genre/Library
		$scope.getInstrument = function() {
			
			var instrumentID = $routeParams.instrumentID;
			
			var instrumentObj = {
				id	: instrumentID
			};			
			
			$http.post('/api/admin/getInstrument', instrumentObj).success(function(response) {
				$scope.instrument = response;
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		
		};

		//  Update Genre/Library
		$scope.update = function() {

			var instrumentObj = {
				id:$scope.instrument.id,
				title: $scope.instrument.title,
			}
			
			$http.post('/api/admin/updateinstrument',instrumentObj).success(function(response) {
				
				if(response.status == 'success') {	
					$rootScope.saveInstrumentMsg="Instrument successfully updated.";
					$location.path("/admin/listInstruments");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status;
					}
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Remove existing genre/library
		$scope.delete = function(id, index) {

			if(id) {
				var instrumentObj = {
					id  : id
				}
				
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/deleteInstrument',instrumentObj).success(function(response) {
						
						if(response.status == 'success') {
							$scope.instruments.splice(index, 1);
							var instrument_id = '#list_'+id; 
							$(instrument_id).remove();
							$scope.success = [{ "msg" :  "Record successfully deleted." }];
						} else {
							$scope.error = [{ "msg" :  "Something went wrong." }];
						}	
					}).error(function(response) {
					});
				}
			
			} else {
				$scope.error = [{ "msg" :  "Select any Instrument." }];
			}	
		};
		$scope.cancel = function (req , res) {
			$location.path('/admin/listInstruments');
		};
	}
]);