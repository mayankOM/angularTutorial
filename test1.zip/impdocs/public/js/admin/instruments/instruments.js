/**
 * Instruments Module Routes
 */
var app = angular.module('instrumentModule', [
  'ngRoute',
  'angularUtils.directives.dirPagination',
]);

app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
      .when("/admin/listInstruments", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/instrument/index.html", 
      })
      .when("/admin/addInstrument", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/instrument/addInstrument.html", 
      })
      .when("/admin/editInstrument/:instrumentID", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/instrument/edit.html", 
      })
}]);