/**
 * Dashboard module routes
 */
var app = angular.module('dashboardPageModule', [
  'ngRoute',
  'angularUtils.directives.dirPagination',
  'chart.js',
]);
app.config(['$routeProvider', function ($routeProvider) {
	$routeProvider
		.when('/admin', {
			templateUrl : 'templates/admin/partials/dashboard/index.html',
	    	resolve:{loggedIn:onlyLoggedInAdmin},
		})
		.when('/admin/userProfile', {
			resolve:{loggedIn:onlyLoggedInAdmin},
			templateUrl : 'templates/admin/partials/dashboard/profile.html',
		})
		.when('/admin/subscribedUserList', {
			resolve:{loggedIn:onlyLoggedInAdmin},
			templateUrl : 'templates/admin/partials/dashboard/subscribedUserList.html',
		})
		.when('/admin/freeUserList', {
			resolve:{loggedIn:onlyLoggedInAdmin},
			templateUrl : 'templates/admin/partials/dashboard/freeUserList.html',
		})
		.when('/admin/curYearSubscribedUserList', {
			resolve:{loggedIn:onlyLoggedInAdmin},
			templateUrl : 'templates/admin/partials/dashboard/curYearSubscribedUserList.html',
		})
		.when('/admin/totalYearSubscribedUserList', {
			resolve:{loggedIn:onlyLoggedInAdmin},
			templateUrl : 'templates/admin/partials/dashboard/totalYearSubscribedUserList.html',
		});
}]);