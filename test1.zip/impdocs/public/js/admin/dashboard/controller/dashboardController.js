var dashboardController = angular.module("dashboardPageModule");

dashboardController.controller('dashboardController', ["$scope", "$route", "$timeout","$location", "$http", "Auth", "Upload", "$rootScope",
	function($scope, $route, $timeout, $location, $http, Auth, Upload, $rootScope) {

		$scope.user = "";
		$scope.UserProfilePicture = "";

		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};

		/*Get a list of days as per selected Month and Year*/
		$scope.getDaysArray = function() {
			var month = $scope.birthdayMonth;
			var year = $scope.birthdayYear;
			$scope.getDays(month, year);
		}

		/*Function for calculating days of month as per selected month and year*/
		$scope.getDays = function(month, year) {
			
		  	if(month == '01' || month == '03' || month == '05' || month == '07' || month == '08' || month == '10' ||  month == '12'){
		  		var startDay = 1;
		  		var endDay = 31;
			}
			else if(month == '04' || month == '06' || month == '09' || month == '11'){
				var startDay = 1;
		  		var endDay = 30;
			}
			else if(month == '02'){
				if ((parseInt(year)%4) == 0){
					if (parseInt(year)%100 == 0){
						if (parseInt(year)%400 == 0){
							var startDay = 1;
	  						var endDay = 29;
						}
						else {
							var startDay = 1;
	  						var endDay = 28;
						}	
					}else{
						var startDay = 1;
  						var endDay = 29;
					}
				}else{
					var startDay = 1;
					var endDay = 28;
				}
			}else	
			{
				var startDay = 1;
		  		var endDay = 31;
			}

		  	var fullDay = [];
		    for (var i=startDay; i<=endDay; i++) {

		    	if(i<=9)
		    		i = '0'+i;

		    	var newarray = {
		    		'value' : i,
		    		'day' : i 
		    	};
				fullDay.push(newarray);
		    }
		    $scope.bDay = fullDay;
		};


		/*Get a list of days as per selected Month and Year*/
		$scope.getUser = function() {
			if(Auth.getCurrentUser()) {
				var usersession = Auth.getCurrentUser();
				var user_id = usersession.id;
				var useridobj = {
					user_id		: user_id
				}
				$http.post('/api/admin/auth/getuser',useridobj).success(function(response) {
					$scope.user = response;
					$scope.user_id = response.id;
				}).error(function(response) {
					$scope.error = [{ "msg" : "Something went wrong." }];
				}); 
			}
		}


		/* Get a profile data of current logged in user */
		$scope.getProfileData = function() {
			if(Auth.getCurrentUser())
			{
				var usersession = Auth.getCurrentUser();
				var user_id = usersession.id;
				var useridobj = {
					user_id		: user_id
				}

				// Get list of secret Questions
				$scope.secretQuestion = '';
				$http.get('/api/general/listsecretquestions').success(function(response) {
						$scope.secretQuestion = response;	
					}).error(function(response) {
						$scope.error = [{ "msg" : "Something went wrong." }];
				});

				$http.post('/api/admin/auth/getuser',useridobj).success(function(response) {
					$scope.user = response;
					$scope.user_id = response.id;
					//$scope.user = usersession;
					$scope.user.password = "";
					var curYear = new Date().getFullYear();
				  	var startYear = 1900;

				  	var d = new Date($scope.user.birthday);
				  	$scope.birthdayYear = d.getFullYear();
				  	
				  	if(d.getDate() < 10)
				  	{
				  		$scope.birthdayDay = ("0" + d.getDate()).slice(-2);	
				  	}	
				  	else
				  	{
				  		$scope.birthdayDay = d.getDate();	
				  	}

				  	$scope.birthdayMonth = ("0" + (d.getMonth() + 1)).slice(-2);

				    $scope.gender = $scope.user.gender;
				    $scope.questionId = $scope.user.questionId;
				  	var fullYear = [];
				    for (var i=startYear; i<=curYear; i++) {

				    	var newarray = {
				    		'value' : i,
				    		'year' : i 
				    	};

						fullYear.push(newarray);
				    }
				    $scope.bYear = fullYear;

				    //Call function for get proper number of day for date selection
				    $scope.getDays($scope.birthdayMonth, $scope.birthdayYear);
				    				
					$scope.change_pw = 0;
				}).error(function(response) {
					$scope.error = [{ "msg" : "Something went wrong." }];
				});    
			}
			else
			{
				$scope.user = "";
				$location.path("/admin/login");
			}	
		};

		/* Update user profile */
		$scope.updateProfile = function() {

			$scope.userAuthenticated = $scope.user;

			if($scope.birthdayYear != "" && $scope.birthdayYear != undefined && $scope.birthdayMonth != "" && $scope.birthdayMonth != undefined && $scope.birthdayDay != "" && $scope.birthdayDay != undefined ) {
				var birthday = $scope.birthdayYear+"-"+$scope.birthdayMonth+"-"+$scope.birthdayDay;	
			} else {
				$scope.error = [{ "msg" : "Date is Required." }];
				return false;
			}
			
			$scope.userAuthenticated.gender = $scope.gender;
			$scope.userAuthenticated.birthday = birthday;
			$scope.userAuthenticated.questionId = $scope.questionId;
			$scope.userAuthenticated.change_pw = $scope.change_pw;

			if($scope.userAuthenticated.change_pw == 1) {
				$scope.userAuthenticated.password = $scope.password;
			}	

			$http.post('/api/admin/user/updateProfile',$scope.userAuthenticated).success(function(response) {
				
				if(response.status == 'success') {	
					$scope.success = [{ "msg" : "Record successfully updated." }];
					$scope.error = "" ;
					$route.reload();
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{"msg":"Failed to update."}];
						$scope.success = "";
						$route.reload();
					
					} else {
						$scope.error = response.status;
						$scope.success = "";
					}
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];;
			});
		};


		/* Cancel the transaction and load homepage */
		$scope.cancel = function() {
			$location.path("/admin");
		};

		/* Upload user profile picture */
		$scope.uploadFiles = function(file, errFiles) {
	       	var usersession = Auth.getCurrentUser();
			var user_id = usersession.id;

	        if (file) {
	            file.upload = Upload.upload({
	                url: '/api/general/imageUpload',
	                data: {file: file, user_id : user_id}
	            });
	            file.upload.then(function (response) {
	            	if(response.data.status == "succ")
	            	{
	            		$scope.user.profilePicture = response.data.filename;

	            		$route.reload();
	            	}	
	            	else
	            	{
	            		$scope.UserProfilePicture = "";
	            		$scope.error = [{ "msg" : response.msg }];
	            	}	
	            }, function (response) {
	            	//$scope.error = response.status + ': ' + response.data;
	            	$scope.error = [{ "msg" : "Something went wrong while uploading picture." }];
	            }, function (evt) {
	                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
	            });
	        }   
	    };


	    /* Get Dashborad Report data */
	    $scope.getReportData = function() {

	    	var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
							  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

		  	var d = new Date();
            var current_year = d.getFullYear();
            var current_month = d.getMonth();
            var subUser_array = [];
            var currentYearSubAmt = 0;
            var totalYearSubAmt = 0;
            var last_six_month_Year = new Array();
            var last_six_month_no = new Array();
            var last_six_month_name = new Array();

            for(var j=0; j < 6; j++)
            {
            	var df = new Date();
	            var MonthDate = df.setMonth(df.getMonth()-j);

	            var Year = new Date(MonthDate).getFullYear();
	            last_six_month_Year.push(Year);

	            var Month = new Date(MonthDate).getMonth();
	            last_six_month_no.push(Month);

	            var MonthName = monthNames[Month];
	            last_six_month_name.push(MonthName.toString());
            }	

            /* Get List of Subscribed and Free User's for Dashboard representation */
			$http.get('/api/admin/dashboard/listSubscribedUser').success(function(response) {
				
				$scope.subscribedUserCount = response.userCount;
				$http.get('/api/admin/dashboard/listFreeUser').success(function(response1) {
					
					$scope.freeUserCount = response1.userCount;
					$scope.labels_pie = ["Subscribed Users", "Free Users"];
		  			$scope.data_pie = [$scope.subscribedUserCount, $scope.freeUserCount];

		  			var monthArray = last_six_month_no;
		  			var yearArray = last_six_month_Year;

	                var subChartArray = [];
	                var freeChartArray = [];
	                for(var j=0; j < monthArray.length; j++)
	                {
	                    var cntPaid = 0;
	                    for (var i = 0; i < response.userList.length; i++) 
	                    {
	                        var sd = new Date(response.userList[i].Subscriptions[0].startAt);
	                        var subscribedDate_year = sd.getFullYear();
	                        var subscribed_month = sd.getMonth();
	                        if(monthArray[j] == subscribed_month && yearArray[j] == subscribedDate_year)
	                        {
	                            cntPaid = cntPaid +1;
	                        }    
	                    }
	                    var subChart = {
	                        'month'     :    monthArray[j],
	                        'count'     :    cntPaid,
	                    }
	                    subChartArray.push(subChart);

	                    var cntFree = 0;
	                    for (var i = 0; i < response1.userList.length; i++) 
	                    {
	                        var fd = new Date(response1.userList[i].createdAt);
	                        var freeDate_year = fd.getFullYear();
	                        var free_month = fd.getMonth();
	                        if(monthArray[j] == free_month && yearArray[j] == freeDate_year)
	                        {
	                            cntFree = cntFree +1;
	                        }    
	                    }
	                    var freeChart = {
	                        'month'     :    monthArray[j],
	                        'count'     :    cntFree,
	                    }
	                    freeChartArray.push(freeChart);
	                } 
	                $scope.subChartArray = subChartArray;
	                $scope.freeChartArray = freeChartArray;
	                
	                $scope.labels_bar = last_six_month_name;
	                $scope.series_bar = ['Paid user', 'Free User'];
	                $scope.data_bar = [
						[$scope.subChartArray[0].count, $scope.subChartArray[1].count, $scope.subChartArray[2].count, $scope.subChartArray[3].count, $scope.subChartArray[4].count, $scope.subChartArray[5].count],
						[$scope.freeChartArray[0].count, $scope.freeChartArray[1].count, $scope.freeChartArray[2].count, $scope.freeChartArray[3].count, $scope.freeChartArray[4].count, $scope.freeChartArray[5].count]
					];	

					/* //Bar CHaRT eXAMPLE
					$scope.labels_bar = ['Jan', 'Dec','Nov', 'Oct', 'Sep', 'Aug'];
	                $scope.series_bar = ['Paid user', 'Free User'];
					$scope.data_bar = [
						[652, 529, 803, 813, 564, 556],					
						[$rootScope.resArray[0].count, $rootScope.resArray[1].count, $rootScope.resArray[2].count, $rootScope.resArray[3].count, $rootScope.resArray[4].count, $rootScope.resArray[5].count],
						[65, 59, 80, 81, 56, 55]
					];*/

				}).error(function(response) {
					$scope.error = [{ "msg" : "Something went wrong." }];
				});

			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];
			});


			/*Get Subscription Amount*/
			$http.get('/api/admin/dashboard/getSubscribedAmt').success(function(response) {

				var d = new Date();
				var current_year = d.getFullYear();
				var current_month = d.getMonth();
				//console.log(current_month);
				var currentYearSubAmt = 0;
				var totalYearSubAmt = 0;

				var janMonthAmt = 0;
				var febMonthAmt = 0;
				var marMonthAmt = 0;
				var aprMonthAmt = 0;
				var mayMonthAmt = 0;
				var junMonthAmt = 0;
				var julMonthAmt = 0;
				var augMonthAmt = 0;
				var sepMonthAmt = 0;
				var octMonthAmt = 0;
				var novMonthAmt = 0;
				var decMonthAmt = 0;

				var firstYearAmt = 0;
				var secondYearAmt = 0;
				var thirdYearAmt = 0;
				var forthYearAmt = 0;
				var fifthYearAmt = 0;
				var sixtYearAmt = 0;

				var subscribedMonthArray = new Array();
	            var last_six_month_no = new Array();
	            var last_six_month_name = new Array();

	            //Year Drop down box
			  	var startYear = current_year - 4;
			  	$scope.defaultYear = current_year;
			  	var fullYear = [];
			  	var yearAmtArray = [];
			    for (var i=startYear; i<=current_year; i++) {
			    	
			    	var newarray = {
			    		'value' : i,
			    		'year' : i 
			    	};
					
					fullYear.push(newarray);
					yearAmtArray.push(i);
			    }
			    
			    $scope.subYear = fullYear;
			    //console.log($scope.subYear.length);
			    // Year array filled end 

				for (var i = 0; i < response.length; i++) {
					
					var sd = new Date(response[i].createdAt);
					var subscribedDate_year = sd.getFullYear();
					var subscribedDate_month = sd.getMonth();
					
					//console.log("---get--"+subscribedDate_year+"---"+subscribedDate_month);

					if(current_year == subscribedDate_year) {
						
						//console.log("--get a year in side---"+current_year);
						currentYearSubAmt += response[i].price;

						// Sum Month wise Subscription amount
						for (var j = 0; j < 12; j++)  {
							
							if(j == 0 && j == subscribedDate_month) {
								janMonthAmt += response[i].price;
							} else if(j == 1 && j == subscribedDate_month) {
								febMonthAmt += response[i].price;
							} else if(j == 2 && j == subscribedDate_month) {
								marMonthAmt += response[i].price;
							} else if(j == 3 && j == subscribedDate_month) {
								aprMonthAmt += response[i].price;
							} else if(j == 4 && j == subscribedDate_month) {
								mayMonthAmt += response[i].price;
							} else if(j == 5 && j == subscribedDate_month) {
								junMonthAmt += response[i].price;
							} else if(j == 6 && j == subscribedDate_month) {
								julMonthAmt += response[i].price;
							} else if(j == 7 && j == subscribedDate_month) {
								augMonthAmt += response[i].price;
							} else if(j == 8 && j == subscribedDate_month) {
								sepMonthAmt += response[i].price;
							} else if(j == 9 && j == subscribedDate_month) {
								octMonthAmt += response[i].price;
							} else if(j == 10 && j == subscribedDate_month) {
								novMonthAmt += response[i].price;
							} else if(j == 11 && j == subscribedDate_month) {
								decMonthAmt += response[i].price;
							}
							else {}
						}
					}
					totalYearSubAmt += response[i].price;

					if(subscribedDate_year == $scope.subYear[0].value) {
						firstYearAmt += response[i].price;
					} else if(subscribedDate_year == $scope.subYear[1].value) {
						secondYearAmt += response[i].price;
					} else if(subscribedDate_year == $scope.subYear[2].value) {
						thirdYearAmt += response[i].price;
					} else if(subscribedDate_year == $scope.subYear[3].value) {
						forthYearAmt += response[i].price;
					} else if(subscribedDate_year == $scope.subYear[4].value) {
						fifthYearAmt += response[i].price;
					}
					else { }

				}

				$scope.currentYear 			= current_year;
				$scope.currentYearSubAmt 	= parseFloat(currentYearSubAmt).toFixed(2);
				$scope.selectedYearSubAmt 	= parseFloat(currentYearSubAmt).toFixed(2);
				$scope.totalYearSubAmt 		= parseFloat(totalYearSubAmt).toFixed(2);

				/* Graph for the Year wise all month's subscription amout status [STart]*/
				$scope.labels_bar_subAmt = monthNames;
                $scope.series_bar_subAmt = ['Subscription Amount ($)'];
                
                $scope.data_bar_subAmt = [
                	[parseFloat(janMonthAmt).toFixed(2), parseFloat(febMonthAmt).toFixed(2), parseFloat(marMonthAmt).toFixed(2), parseFloat(aprMonthAmt).toFixed(2), parseFloat(mayMonthAmt).toFixed(2), parseFloat(junMonthAmt).toFixed(2), parseFloat(julMonthAmt).toFixed(2), parseFloat(augMonthAmt).toFixed(2), parseFloat(sepMonthAmt).toFixed(2), parseFloat(octMonthAmt).toFixed(2), parseFloat(novMonthAmt).toFixed(2), parseFloat(decMonthAmt).toFixed(2)]
				];
				/* Graph for the Year wise all month's subscription amout status [End]*/

				/* Graph for all year's subscription amout status [STart]*/
				$scope.labels_bar_subAmtAll = yearAmtArray;
                $scope.series_bar_subAmtAll = ['Subscription Amount ($)'];
                $scope.data_bar_subAmtAll = [
                	[parseFloat(firstYearAmt).toFixed(2), parseFloat(secondYearAmt).toFixed(2), parseFloat(thirdYearAmt).toFixed(2), parseFloat(forthYearAmt).toFixed(2), parseFloat(fifthYearAmt).toFixed(2)]
				];
				/* Graph for all yeasr's subscription amout status [End]*/
			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];
			});


			/*Get All user for Country wise representation Amount*/
			$http.get('/api/admin/dashboard/listUsers').success(function(response) {

				var registeredCountry = [];
				var registeredCountryCnt = [];
				
	            for (var i = 0; i < response.length; i++) 
				{
					registeredCountry.push(response[i].country);
					registeredCountryCnt.push(response[i].countryCount);
				}

				console.log(registeredCountry);
				// console.log(registeredCountryCnt);


				/* Graph of User's LOcation Country representation [STart]*/
				$scope.labels_pie_countryUser = registeredCountry;
	  			$scope.data_pie_countryUser = registeredCountryCnt;
				/* Graph of User's LOcation Country representation [End]*/

			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];
			});



		};

		/* Get Chart of Subscribed Amount with selected Year */
	    $scope.subscribedAmountYear = function(year) {
			
			var monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
							  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

			$http.get('/api/admin/dashboard/getSubscribedAmt').success(function(response) {

				var current_year = year;
				var currentYearSubAmt = 0;
				var janMonthAmt = 0;
				var febMonthAmt = 0;
				var marMonthAmt = 0;
				var aprMonthAmt = 0;
				var mayMonthAmt = 0;
				var junMonthAmt = 0;
				var julMonthAmt = 0;
				var augMonthAmt = 0;
				var sepMonthAmt = 0;
				var octMonthAmt = 0;
				var novMonthAmt = 0;
				var decMonthAmt = 0;

				var subscribedMonthArray = new Array();
	            var last_six_month_no = new Array();
	            var last_six_month_name = new Array();

				for (var i = 0; i < response.length; i++) 
				{
					var sd = new Date(response[i].createdAt);
					var subscribedDate_year = sd.getFullYear();
					var subscribedDate_month = sd.getMonth();

					if(current_year == subscribedDate_year)
					{
						currentYearSubAmt += response[i].price;
						// Sum Month wise Subscription amount
						for (var j = 0; j < 12; j++) 
						{
							if(j == 0 && j == subscribedDate_month)
							{
								janMonthAmt += response[i].price;
							}
							else if(j == 1 && j == subscribedDate_month)
							{
								febMonthAmt += response[i].price;
							}
							else if(j == 2 && j == subscribedDate_month)
							{
								marMonthAmt += response[i].price;
							}
							else if(j == 3 && j == subscribedDate_month)
							{
								aprMonthAmt += response[i].price;
							}
							else if(j == 4 && j == subscribedDate_month)
							{
								mayMonthAmt += response[i].price;
							}
							else if(j == 5 && j == subscribedDate_month)
							{
								junMonthAmt += response[i].price;
							}
							else if(j == 6 && j == subscribedDate_month)
							{
								julMonthAmt += response[i].price;
							}
							else if(j == 7 && j == subscribedDate_month)
							{
								augMonthAmt += response[i].price;
							}
							else if(j == 8 && j == subscribedDate_month)
							{
								sepMonthAmt += response[i].price;
							}
							else if(j == 9 && j == subscribedDate_month)
							{
								octMonthAmt += response[i].price;
							}
							else if(j == 10 && j == subscribedDate_month)
							{
								novMonthAmt += response[i].price;
							}
							else if(j == 11 && j == subscribedDate_month)
							{
								decMonthAmt += response[i].price;
							}
							else {}
						}
					}
				}

				$scope.selectedYearSubAmt = parseFloat(currentYearSubAmt).toFixed(2);
				$scope.labels_bar_subAmt = monthNames;
                $scope.series_bar_subAmt = ['Subscription Amount ($)'];
                $scope.data_bar_subAmt = [
                	[janMonthAmt, febMonthAmt, marMonthAmt, aprMonthAmt, mayMonthAmt, junMonthAmt,
                	 julMonthAmt, augMonthAmt, sepMonthAmt, octMonthAmt, novMonthAmt, decMonthAmt ]
				];

			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];
			});
			
		};


		/* Get List of Subscribed Users data */
	    $scope.subscribedUserList = function() {
			
			$http.get('/api/admin/dashboard/listSubscribedUser').success(function(response) {
				$scope.users = response.userList;
				$scope.currentPage = 1;
  				$scope.pageSize = 10;
			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];
			});
		};

		/* Get List of Free Users data */
	    $scope.freeUserList = function() {
			
			$http.get('/api/admin/dashboard/listFreeUser').success(function(response) {
				$scope.users = response.userList;
				$scope.currentPage = 1;
  				$scope.pageSize = 10;
			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];
			});
		};


		/* Get List of Subscribed current year Users data */
	    $scope.curYearSubscribedUserList = function(type) {
			
	    	console.log("---sub amt paid here ---")

			$http.get('/api/admin/dashboard/currentYearSubscribedUserList').success(function(response) {
				
				var curYearSUb_array = new Array();
				var totalYearSUb_array = new Array();
				var d = new Date();
				var current_year = d.getFullYear();
				var current_month = d.getMonth();
				var currentYearSubAmt = 0;
				var totalYearSubAmt = 0;
				for (var i = 0; i < response.length; i++) 
				{

					var sd = new Date(response[i].SubscriptionLogs[0].createdAt);
					var subscribedDate_year = sd.getFullYear();
					console.log("---get--"+subscribedDate_year);

					if(current_year == subscribedDate_year)
					{
						console.log("--get a year in side---"+current_year);
						//currentYearSubAmt += response[i].price;
						var obj = {
							'id'			:  	response[i].id,
							'firstname'		:  	response[i].firstname,
							'lastname'		:  	response[i].lastname,
							'userStatus'	:  	response[i].userStatus,
							'isPaid'		:  	response[i].isPaid,
							'amount'		:  	response[i].SubscriptionLogs[0].price,
							'startAt'		:  	response[i].Subscriptions[0].startAt,
							'endAt'			:  	response[i].Subscriptions[0].endAt,
						};
						curYearSUb_array.push(obj);
						currentYearSubAmt += response[i].SubscriptionLogs[0].price;
					}
					var objTotal = {
						'id'			:  	response[i].id,
						'firstname'		:  	response[i].firstname,
						'lastname'		:  	response[i].lastname,
						'userStatus'	:  	response[i].userStatus,
						'isPaid'		:  	response[i].isPaid,
						'amount'		:  	response[i].SubscriptionLogs[0].price,
						'startAt'		:  	response[i].Subscriptions[0].startAt,
						'endAt'			:  	response[i].Subscriptions[0].endAt,
					};
					totalYearSUb_array.push(objTotal);
					totalYearSubAmt += response[i].SubscriptionLogs[0].price;
				}
				if(curYearSUb_array)
				{
					if(type == 'current') {
						
						$scope.users = curYearSUb_array;
						$scope.currentYear = current_year;
						$scope.currentYearSubAmt = parseFloat(currentYearSubAmt).toFixed(2);
					
					} else {
						$scope.users = totalYearSUb_array;	
						$scope.totalYearSubAmt = parseFloat(totalYearSubAmt).toFixed(2);	
					}	
				}
				//Pagination param
				$scope.currentPage = 1;
  				$scope.pageSize = 10;
			}).error(function(response) {
				$scope.error = [{ "msg" : "Something went wrong." }];
			});
		};


	}
]);

dashboardController.directive('matchPassword', function() {
  	return {
    	restrict: 'A',
    	require: ['^ngModel', '^form'],
    	link: function(scope, element, attrs, ctrls) {
      		
      		var formController = ctrls[1];
      		var ngModel = ctrls[0];
      		var otherPasswordModel = formController[attrs.matchPassword];
  
      		ngModel.$validators.passwordMatch = function(modelValue, viewValue) {
        		
        		var password = modelValue || viewValue;
        		var otherPassword = otherPasswordModel.$modelValue || otherPasswordModel.viewValue;
        		//console.log('modelValue || viewValue', password, otherPassword);
        		return password === otherPassword;
      		};

    	} // end link
  	}; // end return
});

dashboardController.directive('uniqueEmailEditProfile', function($http, $q, $routeParams) {

  	return {
    	require : 'ngModel',
    	link : function($scope, element, attrs, ngModel) {
      		
      		ngModel.$asyncValidators.uniqueEmailEdit = function(modelValue, viewValue) {
        		
        		var email 	= modelValue || viewValue;
        		var isAdmin = true;
        		
        		return $http.post('/api/admin/user/uniqueEmailEdit', {email : email, user_id : $scope.user_id, isAdmin : isAdmin}).then(function(res) {
          			if (res.data.exists == 'true') {
            			return $q.reject();
          			}
          			return $q.when();
        		});
      		}; // end async
    	} // end link
  	}; // end return 
});

dashboardController.directive('errSrc', function() {
  	return {
    	link: function(scope, element, attrs) {

      		scope.$watch(function() {
          		return attrs['ngSrc'];
        	}, function (value) {
          		if (!value) {
            		element.attr('src', attrs.errSrc);  
          		}
      		});

      		element.bind('error', function() {
        		element.attr('src', attrs.errSrc);
      		});
    	}
  	}
});