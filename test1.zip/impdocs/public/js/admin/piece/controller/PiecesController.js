var adminPiecesModule = angular.module('pieceModule');

adminPiecesModule.controller('adminPiecesController', ['$rootScope','$scope','$http', '$location', '$routeParams', 'Upload',
	
	function($rootScope,$scope, $http, $location, $routeParams, Upload) {

		var config = {};
		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};
		
		
		//Create new Piece
		$scope.create = function() {

			var libraryValidation = $scope.piece.libraryId;
			var cnt = 0;
			
			for(var i=1; i<= $scope.libraryList.length;i++)
			{
				if(libraryValidation != undefined)
				{
					if($scope.piece.libraryId[i] == true)
					{
						cnt += 1;
					}	
				}				
			}

			var instrumentsValidation = $scope.piece.instrumentId;
			var cntIns = 0;
			
			for(var i=1; i<= $scope.instrumentList.length;i++)
			{
				if(instrumentsValidation != undefined)
				{
					if($scope.piece.instrumentId[i] == true)
					{
						cntIns += 1;
					}	
				}				
			}
			//console.log(cnt);
			
			if(libraryValidation == undefined || cnt == 0 || instrumentsValidation == undefined || cntIns == 0)
			{
				if(libraryValidation == undefined || cnt == 0)
				{
					$scope.libValid = false;
				}
				if(instrumentsValidation == undefined || cntIns == 0)
				{
					$scope.instrumentValid = false;
				}
			}
			else
			{
				$scope.libValid = true;
				$http.post('/api/admin/addPiece',$scope.piece).success(function(response) {
					
					if(response.status == 'success') {

						$scope.piece = '';
						$rootScope.savePieceMsg="Record successfully saved.";
				        $location.path("/admin/listPieces");
					} else {
						
						if(response.status != 'fail') {
							$scope.error = [{ "msg" :  "Failed to save record." }];
						} else {
							$scope.error = response.status
						}	
					}	
				}).error(function(response) {
					$scope.error = [{ "msg" :  "Something went wrong." }];
				});
			}
		};

		// Multiple Checkbox validation hide show manage
		$scope.checkLib = function(libValid, libList) {

			if(libValid == undefined)
			{
				$scope.libValid = false;
			}
			else
			{
				$scope.libValid = true;
			}
		};

		// Instruments Multiple Checkbox validation hide show manage
		$scope.checkInstrument = function(instrumentValid, libList) {

			if(instrumentValid == undefined)
			{
				$scope.instrumentValid = false;
			}
			else
			{
				$scope.instrumentValid = true;
			}
		};

		// Create new Piece
		$scope.listPieces = function() {
			
			$http.get('/api/admin/listPieces').success(function(response) {

				$scope.pieces = response;
				if ($rootScope.savePieceMsg && $rootScope.savePieceMsg != null) {
					$scope.success = [{ "msg" :  $rootScope.savePieceMsg }];
					$rootScope.savePieceMsg = '';
				}
				
				//Pagination param
				$scope.currentPage = 1;
  				$scope.pageSize = 10;

			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Edit new Piece
		$scope.getPiece = function() {
			
			var pieceID = $routeParams.pieceID;
			var pieceObj = {
				id	: pieceID
			}			
			$http.post('/api/admin/getPiece', pieceObj).success(function(response) {
				$scope.piece = response;
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		
		};

		// Create new Piece
		$scope.update = function() {
			
			$http.post('/api/admin/updatePiece',$scope.piece).success(function(response) {
				
				if(response.status == 'success') {	
					
					$rootScope.savePieceMsg="Record successfully updated.";
					$location.path("/admin/listPieces");
				
				} else {
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to update piece." }];
					} else {
						$scope.error = response;
					}
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Remove existing Expense
		$scope.delete = function(id, index) {
			if(id) {
				var pieceObj = {
					id : id
				}
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/deletePiece',pieceObj).success(function(response) {
						if(response.status == 'success') {
							$scope.pieces.splice(index, 1);
							var piece_id = '#list_'+id; 
							$(piece_id).remove();
							$scope.success = [{ "msg" : "Record successfully deleted." }];
						} else {
							$scope.error = [{ "msg" :  "Something went wrong." }];
						}	
					}).error(function(response) {
						$scope.error = [{ "msg" :  "Something went wrong." }];
					});
				}
			
			} else {
				$scope.error = [{ "msg" :  "Please select Piece." }];
			}	
		};
		
		$scope.cancel = function (req , res) {
			$location.path('/admin/listPieces');
		};


		$scope.preFillData = function() {
			
			var pieceID = ($routeParams.pieceID) ? $routeParams.pieceID : '';
			
			if(pieceID) {
				
				var pieceObj = { id	: pieceID };			
				$http.post('/api/admin/getPiece', pieceObj).success(function(response) {
										
					$scope.piece = response;
				
					var librariesList = $scope.piece.Libraries;
					var libraryId = new Object();
					librariesList.map(function (libObj) {
			    		libraryId[libObj.id] = true
				    });
					$scope.piece.libraryId = libraryId;

					var InstrumentsList = $scope.piece.Instruments;
					var instrumentId = new Object();
					InstrumentsList.map(function (libObj) {
			    		instrumentId[libObj.id] = true
				    });
					$scope.piece.instrumentId = instrumentId;
					

				}).error(function(response) {
					$scope.error = [{ "msg" :  "Something went wrong." }];
				});
			
			} else {
				$scope.piece = '';
			}


			//Get list of secret Questions
			$scope.cpmposerList = '';
			$http.get('/api/general/getComposerList').success(function(response) {
				$scope.composerList = response;	
			}).error(function(response) {
				$scope.error = [{ "msg" :  response.message }];
			});

			//List of Instruments
			$scope.instrumentList = '';
			$http.post('/api/general/getInstrumentList','').success(function(response) {
				$scope.instrumentList = response;	
			}).error(function(response) {
				$scope.error = [{ "msg" :  response.message }];
			});

			//List of Music library
			$scope.libraryList = '';
			$http.post('/api/general/getLibraryList','').success(function(response) {
				$scope.libraryList = response;	
			}).error(function(response) {
				$scope.error = [{ "msg" :  response.message }];
			});
			
			//List of Piano Type
			$scope.pianoTypeList = '';
			$http.get('/api/general/getPianoTypeList').success(function(response) {
				$scope.pianoTypeList = response;	
			}).error(function(response) {
				$scope.error = [{ "msg" :  response.message }];
			});

			//List of Tempo list
			$scope.tempoList = '';
			$http.get('/api/general/getTempoList').success(function(response) {
				$scope.tempoList = response;	
			}).error(function(response) {
				$scope.error = [{ "msg" :  response.message }];
			});

			//List of key list
			$scope.keyList = '';
			$http.get('/api/general/getKeyList').success(function(response) {
				$scope.keyList = response;	
			}).error(function(response) {
				$scope.error = [{ "msg" :  response.message }];
			});

			//List of Tunning list
			$scope.tuningList = '';
			$http.get('/api/general/getTuningList').success(function(response) {
				$scope.tuningList = response;	
			}).error(function(response) {
				$scope.error = $scope.error = [{ "msg" :  response.message }];
			});
		}

		$scope.syncAudioFiles = function (pieceID) {
			
			var obj = {
				'pieceId'  :  pieceID
			};

			$http.post('/api/admin/syncAudioList',obj).success(function(response) {

				if(response.status == 'success'){
					
					$scope.success = [{ "msg":"Audio file(s) synchronized successfully." }];
					$scope.process = "";
					$scope.error = "";
				
				}else if(response.status == 'missing'){
					
					$scope.process = [{ "msg":"Audio file(s) synchronized parially completed." }];
					$scope.success = "";
					$scope.error = "";
				
				}else{
					
					$scope.error = [{ "msg":"Failed to synchronize audio files." }];
					$scope.success = "";
					$scope.process = "";					
				}

			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong" }];
				$scope.success = "";
			});
		};


		$scope.getAudioFile = function () {

			var pieceID = ($routeParams.pieceAudioID) ? $routeParams.pieceAudioID : '';

			var obj = {
				'id'  :  pieceID
			};

			$http.post('/api/admin/getPiece',obj).success(function(response) {

				$scope.selPieceId = pieceID;
				$scope.pieceTitle = response.title;
				
			}).error(function(response) {
				$scope.error = [{ "msg" :  response.message }];
				$scope.success = "";
			});
			

			if(pieceID != "" || pieceID != null || pieceID != undefined )
			{
				$http.post('/api/admin/getAudioList',obj).success(function(response) {

					$scope.audioList = response;
					$scope.currentPage = 1;
  					$scope.pageSize = 10;
				}).error(function(response) {
					$scope.error = [{ "msg" :  response.message }];
					$scope.success = "";
				});
			}
			else
			{
				$scope.error = [{ "msg" :  "Select Piece ID" }];
			}
		};
	

		/* Upload user profile picture */
		$scope.importPiecesByXlsx = function(file, errFiles) {
	       	
	        if (file) {
	            file.upload = Upload.upload({
	                url: '/api/admin/importPiecesByXlsx',
	                data: {file: file}
	            });
	            
	            file.upload.then(function (response) {
	            	if(response.data.status == "succ") {
	            		$scope.success = [{ "msg":"Piece(s) imported successfully." }];
	            	} else {
	            		$scope.error = [{ "msg" : response.msg }];
	            	}	
	            }, function (response) {
	            	$scope.error = [{ "msg" : "Something went wrong while importing data." }];
	            }, function (evt) {
	                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
	            });
	        }   
	    };
	}
]);

adminPiecesModule.directive('checkboxGroupins', function() {


  return {
    restrict: 'E',
    controller: function($scope, $attrs) {
      var self = this;
      var ngModels = [];
      var minRequired;
      self.validate = function() {
        var checkedCount = 0;
        angular.forEach(ngModels, function(ngModel) {
          if ( ngModel.$modelValue ) {
            checkedCount++;
          }
        });
        
        //console.log('minRequired', minRequired);
        //console.log('checkedCount', checkedCount);
        
        var minRequiredValidityIns = checkedCount >= minRequired;
        //console.log(minRequiredValidity);
        $scope.minRequiredValidityIns = minRequiredValidityIns;
        angular.forEach(ngModels, function(ngModel) {
          ngModel.$setValidity('checkboxGroupins-minRequired', minRequiredValidityIns, self);
        });
      };
      
      self.register = function(ngModel) {
        ngModels.push(ngModel);
      };
      
      self.deregister = function(ngModel) {
        var index = this.ngModels.indexOf(ngModel);
        if ( index != -1 ) {
          this.ngModels.splice(index, 1);
        }
      };
        
      $scope.$watch($attrs.minRequired, function(value) {
        minRequired = parseInt(value, 10);
        self.validate();
      });
    }
  };
});
adminPiecesModule.directive('input', function() {
	
  return {
    restrict: 'E',
    require: ['?^checkboxGroupins','?ngModel'],
    link: function(scope, element, attrs, controllers) {
      var checkboxGroup = controllers[0];
      var ngModel = controllers[1];
      if ( attrs.type=='checkbox' && checkboxGroup && ngModel ) {
        checkboxGroup.register(ngModel);
        scope.$watch(function() { return ngModel.$modelValue; }, checkboxGroup.validate );
        // In case we are adding and removing checkboxes dynamically we need to tidy up after outselves.
        //scope.$on('$destroy', function() { checkboxGroup.deregister(ngModel); });
      }
    }
  };
});
adminPiecesModule.directive('checkboxGroup', function() {


  return {
    restrict: 'E',
    controller: function($scope, $attrs) {
      var self = this;
      var ngModels = [];
      var minRequired;
      self.validate = function() {
        var checkedCount = 0;
        angular.forEach(ngModels, function(ngModel) {
          if ( ngModel.$modelValue ) {
            checkedCount++;
          }
        });
        
        //console.log('minRequired', minRequired);
        //console.log('checkedCount', checkedCount);
        
        var minRequiredValidity = checkedCount >= minRequired;
        //console.log(minRequiredValidity);
        $scope.minRequiredValidity = minRequiredValidity;
        angular.forEach(ngModels, function(ngModel) {
          ngModel.$setValidity('checkboxGroup-minRequired', minRequiredValidity, self);
        });
      };
      
      self.register = function(ngModel) {
        ngModels.push(ngModel);
      };
      
      self.deregister = function(ngModel) {
        var index = this.ngModels.indexOf(ngModel);
        if ( index != -1 ) {
          this.ngModels.splice(index, 1);
        }
      };
        
      $scope.$watch($attrs.minRequired, function(value) {
        minRequired = parseInt(value, 10);
        self.validate();
      });
    }
  };
});

adminPiecesModule.directive('input', function() {
	
  return {
    restrict: 'E',
    require: ['?^checkboxGroup','?ngModel'],
    link: function(scope, element, attrs, controllers) {
      var checkboxGroup = controllers[0];
      var ngModel = controllers[1];
      if ( attrs.type=='checkbox' && checkboxGroup && ngModel ) {
        checkboxGroup.register(ngModel);
        scope.$watch(function() { return ngModel.$modelValue; }, checkboxGroup.validate );
        // In case we are adding and removing checkboxes dynamically we need to tidy up after outselves.
        //scope.$on('$destroy', function() { checkboxGroup.deregister(ngModel); });
      }
    }
  };
});
