/**
* Piece Module Routes
*/
var app = angular.module('pieceModule', [
    'ngRoute',
]);

app.config(['$routeProvider', 
    function ($routeProvider) {
        
        $routeProvider
            .when("/admin/listPieces", {
                resolve:{loggedIn:onlyLoggedInAdmin},
                templateUrl: "templates/admin/partials/piece/index.html", 
            })
            .when("/admin/importPieces", {
                resolve:{loggedIn:onlyLoggedInAdmin},
                templateUrl: "templates/admin/partials/piece/importPieces.html", 
            })
            .when("/admin/addPiece", {
                resolve:{loggedIn:onlyLoggedInAdmin},
                templateUrl: "templates/admin/partials/piece/addPiece.html", 
            })
            .when("/admin/getAudioFiles/:pieceAudioID", {
                resolve:{loggedIn:onlyLoggedInAdmin},
                templateUrl: "templates/admin/partials/piece/getAudioFiles.html", 
            })
            .when("/admin/editPiece/:pieceID", {
                resolve:{loggedIn:onlyLoggedInAdmin},
                templateUrl: "templates/admin/partials/piece/edit.html", 
            })
    }
]);