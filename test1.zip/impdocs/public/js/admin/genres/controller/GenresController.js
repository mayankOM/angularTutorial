var adminArticlesModule = angular.module('genreModule');


adminArticlesModule.controller('adminGenresController', ['$rootScope','$scope','$http', '$location', '$routeParams',
	
	function($rootScope,$scope, $http, $location, $routeParams) {

		var config = {};
		$scope.sort = function(predicate) {
        	$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
        	$scope.predicate = predicate;
      	};		
		// Create new Composer
		$scope.create = function() {

			$http.post('/api/admin/addGenre',$scope.genre).success(function(response) {

				if(response.status == 'success') {
					
					$rootScope.saveGenreMsg="Record successfully saved.";
			        $location.path("/admin/listGenres");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status;
					}	
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// List Genres/ libraries
		$scope.listGenres = function() {
			$http.get('/api/admin/listGenres').success(function(response) {
				$scope.genres = response;	
  				//console.log($scope.genres[2]);
				if ($rootScope.saveGenreMsg && $rootScope.saveGenreMsg != null) {
					$scope.success = [{ "msg" :  $rootScope.saveGenreMsg }];
					$rootScope.saveGenreMsg = '';
				}			
				$scope.currentPage = 1;
  				$scope.pageSize = 10;
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		// Edit Genre/Library
		$scope.getGenre = function() {
			
			var genreID = $routeParams.genreID;
			
			var genreObj = {
				id	: genreID
			};			
			$http.post('/api/admin/getGenre', genreObj).success(function(response) {
				$scope.genre = response;
				
			}).error(function(response) {
				$scope.error = response.message;
			});
		
		};

		//  Update Genre/Library
		$scope.update = function() {

			var genreObj = {
				id:$scope.genre.id,
				title: $scope.genre.title,
			}
			
			$http.post('/api/admin/updategenre',genreObj).success(function(response) {
				
				if(response.status == 'success') {	
					$rootScope.saveGenreMsg="Record successfully updated.";
					$location.path("/admin/listGenres");
				
				} else {
					
					if(response.status == 'fail') {
						$scope.error = [{ "msg" :  "Failed to save record." }];
					} else {
						$scope.error = response.status;
					}
				}	
			}).error(function(response) {
				$scope.error = [{ "msg" :  "Something went wrong." }];
			});
		};

		// Remove existing genre/library
		$scope.delete = function(id, index) {
			
			if(id) {
				var genreObj = {
					id  : id
				}
				
				if (confirm("Are you sure to delete?")) {
				    $http.post('/api/admin/deleteGenre',genreObj).success(function(response) {
						
						if(response.status == 'success') {
							//$scope.genre[];
							$scope.genres.splice(index, 1);
							var genre_id = '#list_'+id; 
							$(genre_id).remove();
							$scope.success = [{ "msg" :  "Record successfully deleted." }];
						} else {
							$scope.error = [{ "msg" :  "Something went wrong." }];
						}	
					}).error(function(response) {
						$scope.error = [{ "msg" :  "Something went wrong." }];
					});
				}
			
			} else {
			}	
		};
		$scope.cancel = function (req , res) {
			$location.path('/admin/listGenres');
		};
	}
]);