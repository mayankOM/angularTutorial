/**
 * Generes Module routes
 */
var app = angular.module('genreModule', [
  'ngRoute',
  'angularUtils.directives.dirPagination',
]);

app.config(['$routeProvider', function ($routeProvider) {
  $routeProvider
      .when("/admin/listGenres", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/genre/index.html", 
      })
      .when("/admin/addGenre", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/genre/addGenre.html", 
      })
      .when("/admin/editGenre/:genreID", {
        resolve:{loggedIn:onlyLoggedInAdmin},
        templateUrl: "templates/admin/partials/genre/edit.html", 
      })
}]);