/**
    * Admin end Main JS file for Angular (Injecting different modules of admin end )
*/
var app = angular.module('adminApp', [
    'authModule',
    'ngRoute',
    'ngCookies',
    'ngResource',
    'ngMessages',
    'colorpicker.module',
    'wysiwyg.module',
    'ngStorage',
    'ngFileUpload',
    'ngSanitize',
    'dashboardPageModule',
    'userPageModule',
    'composerModule',
    'pianoTypeModule',
    'articleModule',
    'subscriptionPlanModule',
    'genreModule',
    'instrumentModule',
    'angular-loading-bar',
    'pieceModule',
    'ui.bootstrap'
]).config(['$routeProvider','$locationProvider', function ($routeProvider,$locationProvider) {

    $routeProvider.otherwise("/");
    $locationProvider.html5Mode(true);

}]).run(function($http) {
    $http.get('/api/general/abc').success(function(response) {
    }).error(function(response) {});
});

/*Check authentication*/
var onlyLoggedInAdmin = function ($location,$q,Auth) {
    var deferred = $q.defer();
    console.log("Hello inteligent code----");
    Auth.isLoggedInAsync(function(loggedIn) {
        if (loggedIn) {
            deferred.resolve();
        } else {
            deferred.reject();
            $location.url('/admin/login');
        }
    });
    return deferred.promise;
};
