/**
 	* Main AngularJS Web Application
*/
var app = angular.module('mainApp', [
  	'ngRoute',
  	'siteApp',
  	'adminApp',
]);

app.config(['$routeProvider','$locationProvider', function ($routeProvider,$locationProvider) {
  	$routeProvider.otherwise("/");
  	$locationProvider.html5Mode(true);
}]);