/*!
 * jQuery.scrollto.js 0.0.1 - https://github.com/yckart/jQuery.scrollto.js
 * Scroll smooth to any element in your DOM.
 *
 * Copyright (c) 2012 Yannick Albert (http://yckart.com)
 * Licensed under the MIT license (http://www.opensource.org/licenses/mit-license.php).
 * 2013/02/17
 **/
jQuery.scrollTo = jQuery.fn.scrollTo = function(x, y, options){
    if (!(this instanceof jQuery)) return jQuery.fn.scrollTo.apply(jQuery('html, body'), arguments);

    options = jQuery.extend({}, {
        gap: {
            x: 0,
            y: 0
        },
        animation: {
            easing: 'swing',
            duration: 600,
            complete: jQuery.noop,
            step: jQuery.noop
        }
    }, options);

    return this.each(function(){
        var elem = jQuery(this);
        elem.stop().animate({
            scrollLeft: !isNaN(Number(x)) ? x : jQuery(y).offset().left + options.gap.x,
            scrollTop: !isNaN(Number(y)) ? y : jQuery(y).offset().top + options.gap.y
        }, options.animation);
    });
};