'use strict';

var musicLibrary = require('../controller/musicLibraryController');

module.exports = function(app) {
	
	/*app.get('/api/site/listinstruments', musicLibrary.getInstruments);
	app.get('/api/site/listlibraries', musicLibrary.getLibraries);*/
	
	app.get('/api/site/listMuscilibrary', musicLibrary.getMuscilibrary);
	app.post('/api/site/listFilteredMuscilibrary', musicLibrary.getFilteredMuscilibrary);
	app.post('/api/site/musicDetail', musicLibrary.getmusicDetail);
	app.post('/api/site/updateFavourite', musicLibrary.updateFavourite);
	app.post('/api/site/updateLastPlayedPiece', musicLibrary.updateLastPlayedPiece);
	app.post('/api/site/updateStartEndTime', musicLibrary.updateStartEndTime);
	app.post('/api/site/getCoudFrontUrl', musicLibrary.getCoudFrontUrl);
};
