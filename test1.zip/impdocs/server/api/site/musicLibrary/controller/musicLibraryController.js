'use strict';

var db                  = require('../../../../config/sequelize');
var generalConfig       = require('../../../../config/generalConfig');


/*
    Module : MusicLibrary
    Author : Mayank [SOFTWEB]
    Output : return cloudFront signed url
    Date   : 2016-01-07
*/
exports.getCoudFrontUrl = function(req, res) {
    
    var cloudFrontClass = require('aws-cloudfront-sign');
    var fileName        = req.body.fileName;
    var pieceID         = req.body.pieceID;
    
    //var cloudFrontConfig = generalConfig.cloudFront.development.webDistribution;
    var cloudFrontConfig = generalConfig.cloudFront.production.webDistribution;
    var signingParams = {
        keypairId: cloudFrontConfig.keypairId,
        privateKeyPath: cloudFrontConfig.privateKeyPath,
        expireTime: new Date().getTime()+360000
    }
    var absolutePath = cloudFrontConfig.domainName+cloudFrontConfig.innerFolder+pieceID+'/'+fileName;
    var signedUrl = cloudFrontClass.getSignedUrl(
        absolutePath,
        signingParams
    );
    res.jsonp({status:"succ", data : signedUrl , msg : "SignedUrl Cteated"});


    /*var cloudFrontConfig = generalConfig.cloudFront.development.RTMPDistribution;
    var signingParams = {
        keypairId: cloudFrontConfig.keypairId,
        privateKeyPath: cloudFrontConfig.privateKeyPath,
        //expireTime: new Date().getTime()+10000
    }
    var absolutePath = cloudFrontConfig.domainName+cloudFrontConfig.innerFolder+pieceID+'/'+fileName;
    var signedRTMPUrlObj = cloudFrontClass.getSignedRTMPUrl(cloudFrontConfig.domainName, cloudFrontConfig.innerFolder+pieceID+'/'+fileName, signingParams);
    console.log('RTMP Server Path: ' + signedRTMPUrlObj.rtmpServerPath);
    console.log('Signed Stream Name: ' + signedRTMPUrlObj.rtmpStreamName);
    res.jsonp({status:"succ", data : signedRTMPUrlObj.rtmpServerPath+'/'+signedRTMPUrlObj.rtmpStreamName , msg : "SignedUrl Cteated"});*/
};


/*
	Module : MusicLibrary
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : List of Instruments
	Date   : 2015-10-28
*/
exports.getInstruments = function(req, res) {
    db.Instruments.findAll().then(function(instruments){

    	//console.log("----get instruments----");
    	//console.log(instruments);
        if(instruments)	{
        	res.json({status:"succ", data : instruments, msg : "Data loaded successfully"});
        
        } else {
        	res.json({status:"fail", data : null, msg : "Fail to load data"});	
        }	
    }).catch(function(err){
    	res.json({status:"fail", data : null, msg : err});		
    });
};


/*
	Module : MusicLibrary
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : List of Libraries
	Date   : 2015-10-28
*/
exports.getLibraries = function(req, res) {
    db.Libraries.findAll().then(function(libraries){

        if(libraries) {
        	res.json({status:"succ", data : libraries, msg : "Data loaded successfully"});
        } else {
        	res.json({status:"fail", data : null, err : "Fail to load data"});	
        }	
    }).catch(function(err){
    	res.json({status:"fail", data : null, err : err});		
    });
};


/*
	Module : MusicLibrary
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : List of Music Libraries (Pieces)
	Date   : 2015-10-28
*/
exports.getMuscilibrary = function(req, res) {

    console.log("Session value------->"+req.body.userID);
    
    var user_ID = 11;
    var decryptedUserID = parseInt(user_ID);

    var userid = decryptedUserID;

    console.log(userid);

	db.Pieces.findAll({
        attributes : ['id','title'],
        include: [
            { model : db.Composer, attributes : ['firstName','lastName']},
            //{ model : db.PianoTypes, attributes : ['title']},
            { model : db.Libraries, attributes : ['title']},
            //{ model : db.User, attributes : ['firstname','lastname'], required : false },
            { model: db.UsersPieces, attributes : ['isFavourite','lastPlayed'], where : userid ? { 
                $and: {
                  userID: userid
                } 
            } : null,  required : false },
            //{ model: db.UsersPieces, where : userid ? { userID : userid } : null }

        ], 
        order: 'id DESC'
    }).then(function(pieces){

		if(pieces) {
        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
        } else {
        	res.json({status:"fail", data : null, err : "Fail to load data"});	
        }	
    }).catch(function(err){
    	res.json({status:"fail", data : null, err : err.message});		
    });
};

/*
    Module : MusicLibrary
    Author : Mayank [SOFTWEB]
    Inputs : 
    Output : List of Music Libraries (Pieces)
    Date   : 2015-10-28
*/
exports.getFilteredMuscilibrary = function(req, res) {

    /*console.log("Hello Here => "+ req.body.libraries);
    console.log("instruments Here => "+ req.body.instruments);
    console.log("keyword Here => "+ req.body.q);
    console.log(req.body);*/
    
    var user_ID = decrypt(req.body.userID);
    var userid = parseInt(user_ID);

    db.Pieces.findAll({
        
        attributes : ['id','title'],
        include: [
            { model : db.Composer, attributes : ['firstName','lastName'] },
            { model : db.Instruments, attributes : {exclude:['id','title','createdAt','updatedAt']}, through:{ attributes: {include:[], exclude:['pieceID','instrumentID','createdAt','updatedAt','InstrumentId','PieceId']} }, where : req.body.instruments ? { id : req.body.instruments } : null },
            { model : db.Libraries, attributes : { exclude:['title','id','createdAt','updatedAt'] }, through:{ attributes: {include:[], exclude:['libraryID','pieceID','createdAt','updatedAt','LibraryId','PieceId']} }, where : req.body.libraries ? { id : req.body.libraries } : null },
            { model : db.UsersPieces, attributes : ['isFavourite','lastPlayed'], where : userid ? { 
                $and: {
                    userID: userid,
                    isFavourite: true
                } 
            } : null, required : req.body.favorite == 'YES' ? true : false },
            { model : db.AudioFiles, attributes:[[db.sequelize.fn('COUNT', db.sequelize.col('`AudioFiles`.`id`')), 'fileCount']] },
        ], 
        where  : req.body.q ? { 
            $and: {
                title : { $like: '%'+req.body.q+'%' },
                isActive : { $eq : true}
            }
        } : {
            $and: {
                isActive : { $eq : true},
            }
        },
        group  : '`Pieces`.`id`',
        having : {
            '`AudioFiles`.`fileCount`' : {
                $gt: 0
            }
        },
        order  : '`Pieces`.`id`'
    }).then(function(pieces){

        if(pieces) {
            res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
        } else {
            res.json({status:"fail", data : null, err : "Fail to load data"});  
        }   
    
    }).catch(function(err){
        res.json({status:"fail", data : null, err : err.message});      
    });
};

/*
    Module : MusicLibrary
    Author : Mayank Patel [SOFTWEB]
    Inputs : MisucLibraryId (PieceID)
    Output : Get Detail of selected Piece
    Date   : 2015-11-04
*/
exports.getmusicDetail = function(req, res) {

    var user_ID = decrypt(req.body.userID);
    var userid = parseInt(user_ID);
    
    db.Pieces.findAll({
        attributes : ['id','title','tempo'],
        include: [ 
            { model : db.AudioFiles, attributes : ['id','tempo','file']},
            { model : db.UsersPieces, attributes : ['isFavourite','startLoop','endLoop'], where : userid ? { 
                $and : {
                    userID  : userid,
                    pieceID : req.body.pieceID
                } 
            } : null,  required : false },
        ],
        
        where: {
            id   :  req.body.pieceID       
        },
        //order: ' CAST(`AudioFiles.tempo` AS UNSIGNED) '
        order: '`AudioFiles.tempo`'
    }).then(function(pieces){
    
        if(pieces) {
            res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
        } else {
            res.json({status:"fail", data : null, err : "Fail to load data"});  
        }   
    
    }).catch(function(err){
        res.json({status:"fail", data : null, err : err.message});      
    });
};

/*
    Module : MusicLibrary
    Author : Mayank Patel [SOFTWEB]
    Inputs : pieceID, userID
    Output : Update Favorite or UnFavorite Piece
    Date   : 2015-11-20
*/
exports.updateFavourite = function(req, res) {

    var userID = decrypt(req.body.userID);
    userID = parseInt(userID);
    
    var pieceID = req.body.pieceID;
    var UsersPieces = db.UsersPieces;

    UsersPieces.findOrCreate({
        where : { 
            $and: {
                userID : userID,
                pieceID : pieceID
            }
        }
    }).then(function(data){
        var userPiece = data[0];
        if(userPiece){
            var tmp = (userPiece.isFavourite == true) ? false : true;
            var obj = {
                'userID':userID,
                'pieceID':pieceID,
                'isFavourite':tmp
            }
            userPiece.updateAttributes(obj);
            res.json({status:"succ", data : tmp, msg : "isFavourite Updated Successfully"});
        }

    }).catch(function(err){
        res.json({status:err});
    });
};




/*
    Module : MusicLibrary
    Author : Mayank Patel [SOFTWEB]
    Inputs : PieceID, UserID
    Output : Update last played Start And End Time
    Date   : 2015-12-18
*/
exports.updateStartEndTime = function(req, res) {

    var userID = parseInt(decrypt(req.body.userID));
    var pieceID = req.body.pieceID;
    var UsersPieces = db.UsersPieces;

    UsersPieces.findOrCreate({
        where : { 
            $and: {
                userID  : userID,
                pieceID : pieceID
            }
        }
    }).then(function(data){
        var userPiece = data[0];
        if(userPiece){
            
            var obj = {
                'userID'        : userID,
                'pieceID'       : pieceID,
                'startLoop'     : req.body.startLoop.toString(),
                'endLoop'       : req.body.endLoop.toString()
            }
            userPiece.updateAttributes(obj).then(function(){
                res.json({status:"succ", data : '', msg : "Start And End Time Updated Successfully"});    
            });
        }

    }).catch(function(err){
        res.json({status:err});
    });

};

/*
    Module : MusicLibrary
    Author : Mayank Patel [SOFTWEB]
    Inputs : PieceID, UserID
    Output : Update last played Pice time
    Date   : 2015-11-23
*/
exports.updateLastPlayedPiece = function(req, res) {

    var userID = parseInt(decrypt(req.body.userID));
    var pieceID = req.body.pieceID;
    
    var UsersPieces = db.UsersPieces;
    UsersPieces.findOrCreate({
        where : { 
            $and: {
                userID  : userID,
                pieceID : pieceID
            }
        }
    }).then(function(data){
        var userPiece = data[0];
        if(userPiece){
            var cur_date = new Date().toISOString();
            var obj = {
                'userID'        : userID,
                'pieceID'       : pieceID,
                'lastPlayed'    : cur_date
            }
            userPiece.updateAttributes(obj).then(function(){
                res.json({status:"succ", data : cur_date, msg : "Last Played Piece Updated Successfully"});    
            });
        }

    }).catch(function(err){
        res.json({status:err});
    });

};


/*
    Module : Encryption function
    Author : Mayank [SOFTWEB]
    Inputs : text
    Output : Encrypt text
    Date   : 2015-12-03
*/
function encrypt(text){
    var cipher = generalConfig.cryptoAuthentication.crypto.createCipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
    var crypted = cipher.update(text,'utf8','hex');
    crypted += cipher.final('hex');
    return crypted;
}

/*
    Module : Decryption function
    Author : Mayank [SOFTWEB]
    Inputs : Encrypted text
    Output : Simple text
    Date   : 2015-12-03
*/ 
function decrypt(text){
    var decipher = generalConfig.cryptoAuthentication.crypto.createDecipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
    var dec = decipher.update(text,'hex','utf8');
    dec += decipher.final('utf8');
    return dec;
}