'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');

var multiparty = require('multiparty');
var fs = require('fs-extra');


/**
    * Create user
*/
exports.create = function(req, res) {
    
	/*
    console.log("----Get a post data------");
	console.log(req.body);*/

	if(req.body != "") {
		req.checkBody('email', 'Email required').notEmpty();
		req.checkBody('email', 'Valid email required').isEmail();
		req.checkBody('firstname', 'Firstname required').notEmpty();
		req.checkBody('lastname', 'Lastname required').notEmpty();
		req.checkBody('contact', 'Contact required').notEmpty();
		req.checkBody('password', 'Password required').notEmpty();
		req.checkBody('birthday', 'Birthdate required').notEmpty();
		req.checkBody('answer', 'Anser required').notEmpty();
		req.checkBody('questionId', 'Secret Question required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		
		var message = null;
		req.body.isPaid = 0;
	    var user = db.User.build(req.body);

	    //START Default subscription end date set (Free user)
	    var CurrentDate = new Date();
	    var curDate = new Date();
		
		var end_date = CurrentDate.setDate(CurrentDate.getDate() + generalConfig.defaultFreeSubscriptionPeriod);
		
		var dateTime = new Date(end_date);
		var end_dateTime = dateTime.toISOString(); 
	    //END Default subscription end date set (Free user)

	    var emailContainer = generalConfig.emailTemplate;

		
		var	dataString = "<p>Hello "+req.body.firstname+",</p>";
			dataString += "<p>Thank you for signing up with Om!</p>";
			dataString += "<p>If you’d like to log in, make changes to your profile, or just start practicing, please click here : <a href='"+generalConfig.impconfig.websiteURL+"'>Om</a></p>";
		var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;


		// EMail content
	    var message = {
		   from			: generalConfig.impconfig.noRplyEmail,  //Like : Om music, LLC <no-reply@accompanymusic.com> 
		   to 			: req.body.email,
		   subject 		: emailContainer.signUpEmailSubject,
		   attachment 	: [
		       { data:emailContainerString, alternative:true },
		   ]
		};

	    //user.provider = 'local';
	    user.salt = user.makeSalt();
	    user.hashedPassword = user.encryptPassword(req.body.password, user.salt);
	    
	    user.save().then(function(data){
	    	
	    	//Save Free subscription for new user
	    	var subscriptionObj = {
				'userID'		 : 	data.id,
				'startAt'		 : 	curDate,
				'endAt'		     : 	end_dateTime
			};
			var subscription = db.Subscription.build(subscriptionObj);
    		subscription.save().then(function(){ });
	        
    		// Send Email
            generalConfig.getServer.send(message, function(err, message) { console.log(err || message); });
	        res.json({status:"success"});
	    
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		res.json({status:mappedErrors});	
	}
};

/**
    * Update user
*/
exports.update = function(req, res) {

	if(req.body != "") {
		
		req.checkBody('email', 'Email required').notEmpty();
		req.checkBody('email', 'Valid email required').isEmail();
		req.checkBody('firstname', 'Firstname required').notEmpty();
		req.checkBody('lastname', 'Lastname required').notEmpty();
		req.checkBody('contact', 'Contact required').notEmpty();
		req.checkBody('birthday', 'Birthdate required').notEmpty();
		req.checkBody('answer', 'Anser required').notEmpty();
		req.checkBody('questionId', 'Secret Question required').notEmpty();
		
		if(req.body.change_pw == 1) {
			req.checkBody('password', 'Password required').notEmpty();
		}	
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		
		var message = null;
	    var user = db.User.build(req.body);
	    if(req.body.change_pw == 1) {
			
			

			var salt = user.makeSalt();
			var hashedPassword = user.encryptPassword(req.body.password, salt);

			var obj = {
				'firstname'		: 	req.body.firstname,
				'lastname'		: 	req.body.lastname,
				'email'			: 	req.body.email,
				'contact'		: 	req.body.contact,
				'gender'		: 	req.body.gender,
				'country'		: 	req.body.country,
				'birthday'		: 	req.body.birthday,
				'questionId'	: 	req.body.questionId,
				'answer'		: 	req.body.answer,
				'hashedPassword': 	hashedPassword,
				'salt'			: 	salt
			};
		
		} else {
			
			var obj = {
				'firstname'		: 	req.body.firstname,
				'lastname'		: 	req.body.lastname,
				'email'			: 	req.body.email,
				'contact'		: 	req.body.contact,
				'gender'		: 	req.body.gender,
				'country'		: 	req.body.country,
				'birthday'		: 	req.body.birthday,
				'questionId'	: 	req.body.questionId,
				'answer'		: 	req.body.answer
			};	
		}	

	  	db.User.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		
		res.json({status:mappedErrors});	
	}   
};
/**
    * Send User
*/
exports.delete = function(req, res) {
    db.User.destroy({ where : { id : req.body.user_id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    * Send User
*/
exports.me = function(req, res) {
    res.jsonp(req.user || null);
};


/**
    * Find all user
*/
exports.list = function(req, res, next) {
    db.User.findAll().then(function(user){
        if (!user) 
            return next(new Error('Failed to load User ' + id));
        req.profile = user;
        res.json(user);
        //next();
    }).catch(function(err){
    	res.json({status:"fail"});
        //next(err);
    });
};

/**
    * Find user by id
*/
exports.getById = function(req, res, next) {

	var decryptedUserID = decrypt(req.body.user_id);
	var id = parseInt(decryptedUserID);

    db.User.find({
    	attributes : ['id','email','firstname','lastname','birthday','contact','gender','country','profilePicture','isAdmin','userStatus','questionId','answer','isPaid'],
    	include: [
            { model : db.Subscription, attributes : ['userID','planID','profileStatus','startAt','endAt']},
        ],
    	where : { id: id }
    }).then(function(user){
    	if (!user) 
            return next(new Error('Failed to load User ' + id));
        req.profile = user;
        res.json(user);
        //next();
    }).catch(function(err){
    	res.json({status:err});
        //next(err);
    });
};

exports.imageUpload = function(req, res) {
 	var tstamp = Date.now();

 	//var user_id = req.body.user_id;
 	var decryptedUserID = decrypt(req.body.user_id);
	var user_id = parseInt(decryptedUserID);

	var file = req.files.file;
    var tmpPath = file.path;
	//var extIndex = tmpPath.lastIndexOf('.');
	//var extension = (extIndex < 0) ? '' : tmpPath.substr(extIndex);
    
    var fileName = tstamp+'_'+file.name;
    var destPath = 'public/assets/Site/userprofile/'+fileName;

    if(user_id != "" && file.name != "")
    {
    	var obj = {
			'profilePicture'	: 	fileName
		};	

		var userData = "";

		//var id = req.body.user_id;
		var id = user_id;
	    db.User.find({
	    	attributes : ['id','profilePicture'],
	    	where : { id: id }
	    }).then(function(user){
    		if(user)
    		{	
    			db.User.update(obj,{ where : { id : user_id }}).then(function(){
		    		fs.copy(tmpPath, destPath, { replace: false }, function (err) {

				    	if (err) {
							res.json({status:"fail", msg : err});
						} else {				
							if(user.profilePicture != "")
							{
								fs.unlink('public/assets/Site/userprofile/'+user.profilePicture);
							}	
							res.json({status:"succ", msg : "File upload done.", filename : fileName });
						}
					});
			    }).catch(function(err){
			        res.json({status:"fail", msg : err });
			    });
    		}		
    		else
    		{
    			res.json({status:"fail", msg : "User not found" });
    		}	
	    }).catch(function(err){
	        //next(err);
	        res.json({status:"fail", msg : err });
	    });
    }	
    else
    {
		res.json({status:"fail", msg : "Username or file name missing." });
    }	
};


/**
    * Get a list of secret Questions all user
*/
exports.getSecretQuestions = function(req, res, next) {

    db.SecretQuestion.findAll({
    	attributes : ['id','question']
    }).then(function(list){
        if (!list) 
            return next(new Error('Failed to load Question list '));
        
        res.json(list);
    }).catch(function(err){
    	res.json({status:"fail"});
    });
};


/**
    * Generic require login routing middleware
*/
exports.requiresLogin = function(req, res, next) {
    if (!req.isAuthenticated()) {
        return res.send(401, 'User is not authorized');
    }
    next();
};

/**
    * User authorizations routing middleware
*/
exports.hasAuthorization = function(req, res, next) {
    if (req.profile.id != req.user.id) {
      return res.send(401, 'User is not authorized');
    }
    next();
};

/**
    * CHeck for Unique Email during signup process
*/
exports.uniqueEmail = function (req, res, next) {
	
	db.User.find({
		attributes : ['id','email'],
		where : { email: req.body.email, isAdmin:{ $eq : false}}
	}).then(function(user){
		if(!user) {
			res.json({exists:"false"});
		} else {
			console.log("Hello Here" + user)
			res.json({exists:"true"});
		}	
        //next();
    }).catch(function(err){
    	res.json({exists:err});
        //next(err);
    });
};

/**
    * CHeck for Unique Email during Update user profile
*/
exports.uniqueEmailEdit = function (req, res, next) {
	var decryptedUserID = decrypt(req.body.user_id);
	var current_user_id = parseInt(decryptedUserID);

	db.User.find({
		attributes : ['id','email'],
		where : { email: req.body.email, id: { $ne: current_user_id }, isAdmin:{ $eq : false}}
	}).then(function(user){
		if(!user) {
			res.json({exists:"false"});
		} else {
			res.json({exists:"true"});
		}	
        //next();
    }).catch(function(err){
    	res.json({exists:err});
        //next(err);
    });
};

/*
	Module : Encryption function
	Author : Mayank [SOFTWEB]
	Inputs : text
	Output : Encrypt text
	Date   : 2015-12-03
*/
function encrypt(text){
  var cipher = generalConfig.cryptoAuthentication.crypto.createCipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  var crypted = cipher.update(text,'utf8','hex');
  crypted += cipher.final('hex');
  return crypted;
}

/*
	Module : Decryption function
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted text
	Output : Simple text
	Date   : 2015-12-03
*/ 
function decrypt(text){
  var decipher = generalConfig.cryptoAuthentication.crypto.createDecipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  var dec = decipher.update(text,'hex','utf8');
  dec += decipher.final('utf8');
  return dec;
}