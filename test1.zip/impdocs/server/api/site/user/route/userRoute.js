'use strict';

var siteUser = require('../controller/userController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
	
	app.post('/api/site/getuser', siteUser.getById);
	app.post('/api/site/listsecretquestions', siteUser.getSecretQuestions);
	app.post('/api/site/registeruser', siteUser.create);
	app.post('/api/site/updateuser', siteUser.update);
	app.post('/api/site/imageUpload', multipartMiddleware, siteUser.imageUpload);
	
	app.post('/api/site/uniqueEmail', siteUser.uniqueEmail);
	app.post('/api/site/uniqueEmailEdit', siteUser.uniqueEmailEdit);
};