'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');

/*
	Module : Subscription Plan
	Author : Vipul [SOFTWEB]
	Inputs : 
	Output : List of Subscription Plans
	Date   : 2015-10-28
*/
exports.getContentArticle =function (req , res) {

	db.Article.findAll().then(function(list){
        if (!list) 
            return next(new Error('Failed to load Article list '));
        
        res.json(list);
    }).catch(function(err){
    	res.json({status:"fail"});
    });

};

/*
	Module : Contact us
	Author : Mayank [SOFTWEB]
	Inputs : Name, email, contact number, message 
	Output : Send mail to admin with above detail
	Date   : 2015-12-09
*/
exports.sendContactInfo =function (req , res) {

	if(req.body != "") {
		
		req.checkBody('email', 'Email required').notEmpty();
		req.checkBody('email', 'Valid email required').isEmail();
		req.checkBody('name', 'Name required').notEmpty();
		req.checkBody('contact', 'Contact required').notEmpty();
		req.checkBody('message', 'Message required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	
	if(mappedErrors == false) {
		
		var message 	= null;
		var fromUser 	= req.body.email;
		var toUser 		= generalConfig.impconfig.adminEmail;
		var name 		= req.body.name;
		var email 		= req.body.email;
		var contact 	= req.body.contact;
		var msg 		= req.body.message;
		
	    
	    var emailContainer = generalConfig.emailTemplate;

		var ip = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
		if(ip != '') {
			
			/*var geoip 			= require('geoip-lite');
			var ipArray 		= ip.split('ffff:');
			var ipAddress 		= (ipArray[1] != '') ? ipArray[1] : '';*/
			
			var geoip 			= require('geoip-lite');
			var ipAddress 		= ip;
			var geo 			= geoip.lookup(ipAddress);
			
			if(geo) {
				var isoCountries 	= generalConfig.isoCountries;
				var countryName  	= (geo.country) ? (isoCountries.hasOwnProperty(geo.country)) ? isoCountries[geo.country] : '' : '';
			} else {
				var countryName = '';
			}

		} else {
			var ipAddress 	= '';
			var countryName = '';
		}


		var	dataString = "<p>Hello Om Admin,</p>";
			dataString += "<p>You have received a new message on "+req.body.time+" from:</p>";
			dataString += "<div class='row'><table class='table'>";
				
				dataString += "<thead>";
					dataString += "<tr><td><b>Name</b>&nbsp;:&nbsp;"+name+"</td></tr>";
					dataString += "<tr><td><b>Email</b>&nbsp;:&nbsp;"+email+"</td></tr>";
					dataString += "<tr><td><b>Contact</b>&nbsp;:&nbsp;"+contact+"</td></tr>";

					dataString += "<tr><td><b>IP address</b>&nbsp;:&nbsp;"+ipAddress+"</td></tr>";
					dataString += "<tr><td><b>Country</b>&nbsp;:&nbsp;"+countryName+"</td></tr>";
					
					dataString += "<tr><td><b>Message</b>&nbsp;:</td></tr>";
					dataString += "<tr><td>"+msg+"</td></tr>";
				dataString += "</thead>";
			
			dataString += "</table></div>";


		var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;

		//res.json({status:"succ", data : emailContainerString, msg : "Your information send successfully"});
	    
	    var message = {
	       	
	       	from:    fromUser, 
	       	to:    	 toUser,
	       	cc:      generalConfig.impconfig.tempAdminEmail,
	       	subject: emailContainer.contactUsEmailSubject,
	       	attachment: [
	        	{ data: emailContainerString,alternative:true },
	       	]
	    }; 
        generalConfig.getServer.send(message, function(err, message) { 
        	console.log(err);
            if(err) {
                res.json({status:"fail", data : null, msg : "Failed to send information."});
            } else {
                res.json({status:"succ", data : null, msg : "Your information was sent successfully."});
            }
        });
	
	} else {
		res.json({status:mappedErrors});	
	}
};