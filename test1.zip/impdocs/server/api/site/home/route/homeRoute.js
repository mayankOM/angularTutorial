'use strict';

var homepage = require('../controller/homeController');

module.exports = function(app) {
	app.post('/api/site/listContent', homepage.getContentArticle);
	app.post('/api/site/contactInfo', homepage.sendContactInfo);
	
	/* DO Not Delete */ 
	//app.get('/site/paypalIpncallBack', subscription.paypalIpncallBack);
};