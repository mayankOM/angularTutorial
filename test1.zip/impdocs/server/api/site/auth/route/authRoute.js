'use strict';

var siteAuth = require('../controller/authController');

module.exports = function(app) {
	app.post('/api/site/auth/signin', siteAuth.signin);
	app.get('/api/site/auth/signout', siteAuth.signout);
	app.post('/api/site/auth/enc', siteAuth.encryptCookies);
	app.post('/api/site/auth/dec', siteAuth.decryptCookies);
	app.post('/api/site/forgetPassword', siteAuth.forgetPassword);
	app.post('/api/site/resetPassword', siteAuth.resetPassword);
	app.post('/api/site/getRepList', siteAuth.getRepList);
	
};