'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');
var passport = require('passport');
var http = require('http');
var url = require('url');

/*
	Module : Login
	Author : Mayank [SOFTWEB]
	Inputs : Email, Password
	Output : Login and Generate server side session
	Date   : 2015-10-15
*/
exports.signin = function(req, res, next) {
	
	passport.authenticate('local', function(err, user, info) {
		
		if(!user) {
			if(err) {
				console.log("----Out and failed to session----"+err);
				res.json({status:err});	
			} else {
				console.log("----Out and failed to session ----"+info);
				res.json({status:'fail'});	
			}	
		} else {

			console.log("Om : get resp 002--");
			console.log(user);

			if(user.resetPassword == '1') {
				
				console.log("---In data migration----"+user.id);
				var curUserID = user.id;
	            var curUserID = encrypt(curUserID.toString());
				res.json({'resetPassword':'YES', 'userMigrateID' : curUserID});	
			} else {
				console.log("============== In success and set session =================");
				var curUserID = user.id;
	            var curUserID = encrypt(curUserID.toString());
				req.session.user = user;
				res.json({id : curUserID});		
			}			
		}	
	})(req, res, next);
};

/*
	Module : Login
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : Destroy server side session
	Date   : 2015-10-15
*/
exports.signout = function (req, res) {
	console.log("---------- Session Destroy user -----------");
	delete req.session.user;
	res.json({status:"success"});
	/*req.session.destroy(function(err) {
		res.json({status:"success"});
	})*/
};

/*
	Module : Session data
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : Session data
	Date   : 2015-10-15
*/	
exports.getSession = function(req, res){
	if(req.session.user) {
		res.json(req.session.user);
	} else {
		res.json({status:'fail'});
	}
};

/*
	Module : Forget Password
	Author : Mayank [SOFTWEB]
	Inputs : Email
	Output : Send password by email on requested id and update new password
	Date   : 2015-12-03
*/
exports.forgetPassword = function(req, res){

	if(req.body.forgetPasswordEmail != "" && req.body.forgetPasswordEmail != undefined)
    {
        var email = req.body.forgetPasswordEmail;
        db.User.findAndCountAll({
            attributes : ['id','email','firstname','lastname'],
            where : { 
                $and: {
                  	email : email,
                  	isAdmin : 0
                }
            }
        
        }).then(function(data){
            
        	if(data.count > 0) {
    			
    			var message 		= null;
    			var userID 			= data.rows[0].id;
    			var encUserID 		= encrypt(userID.toString());
    			var domainName 		= url.parse(req.url,true).host;
    			var protocolName	= url.parse(req.url,true).protocol;
				    			
				var hostname 		= req.headers.host; // hostname = 'localhost:8080'
				//var pathname 		= url.parse(req.url).pathname; // pathname = '/MyApp'
	            
				var emailContainer = generalConfig.emailTemplate;

				var	dataString = "<p>Hello "+data.rows[0].firstname+",</p>";
					dataString += "<p>You recently requested a password reset. Please click the link below to create your new password:</p>";
					dataString += "<p><a href='http://"+hostname+"/setNewPassword/"+encUserID+"' target='_blank'>Reset Password</a><p>";

				var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;

	            var message = {
	            	from:    generalConfig.impconfig.noRplyEmail,  //Like : Om music, LLC <no-reply@accompanymusic.com>
	               	to:      email,
	               	subject: emailContainer.forgetPasswordEmailSubject,
	               	attachment: [
	                	{ data:emailContainerString, alternative:true },
	               	]
	            }; 
	            
	            //setTimeout(function () {
	                generalConfig.getServer.send(message, function(err, message) { 
	                	console.log(err);
	                    if(err) {
	                        res.json({status:"fail", data : null, msg : "Failed to send email.!"});
	                    } else {
	                        res.json({status:"succ", data : null, msg : "New Password setup link sent to you by email"});
	                    }
	                });
	            //}, 1000);
        	} else {
        		res.json({status:"fail", data : null, msg : "Email address not exist."});
        	}		
   

        }).catch(function(err){
            res.json({status:"fail", data : null, msg : err.message});
        });
    }   
    else
    {
        res.json({status:"fail", data : null, msg : "Please enter valid email address."});
    }
};


/*
	Module : reSet Password
	Author : Mayank [SOFTWEB]
	Inputs : userID, Password
	Output : Confirmation by message
	Date   : 2015-12-04
*/
exports.resetPassword = function(req, res){

	if((req.body.userId != "" && req.body.userId != undefined) || (req.body.password != "" && req.body.password != undefined))
    {
    	req.body.id = decrypt(req.body.userId);
    	var decryptedUserID = parseInt(req.body.id);
    	var user = db.User.build(req.body);
	    var salt = user.makeSalt();
		var hashedPassword = user.encryptPassword(req.body.password, salt);

		
		console.log("---Get a list of rest param---");
		console.log(req.body);

		if(req.body.migrate == 'migrate')
		{
			var obj = {
	            'hashedPassword'	: 	hashedPassword,
				'salt'				: 	salt,
				'isPassUpdateStatus': 	1
	        };
		}
		else
		{
			var obj = {
	            'hashedPassword'	: 	hashedPassword,
				'salt'				: 	salt
	        };
		}	
    	
        db.User.update(obj,{ 
            where : { 
	                    id : decryptedUserID
                    }
        }).then(function(data){
        	
        	console.log(data);

        	if(req.body.migrate == 'migrate')
			{
				//START Default subscription end date set (Free user)
			    var curDate = new Date();
				console.log("---Get a  dat----");
			    var CurrentDate = new Date();
				console.log("---Get a  dat----001");
				var end_date = CurrentDate.setDate(CurrentDate.getDate() + generalConfig.defaultFreeSubscriptionPeriod);
				console.log("---Get a  dat----002");
				var dateTime = new Date(end_date);
				console.log("---Get a  dat----003");
				var end_dateTime = dateTime.toISOString(); 
				console.log("---Get a  dat----004");
			    //END Default subscription end date set (Free user)

				//Save Free subscription for new user
		    	var subscriptionObj = {
					'userID'		 : 	decryptedUserID,
					'startAt'		 : 	curDate,
					'endAt'		     : 	end_dateTime
				};
				
				console.log("---Get a subscription detail----");
				console.log(subscriptionObj);
				var subscription = db.Subscription.build(subscriptionObj);
	    		subscription.save().then(function(){ 

	    			db.User.find({
					    attributes : ['id','email','firstname','lastname'],
					    where : { 
			                $and: {
			                  id : decryptedUserID
			                }
			            }
					}).then(function(data){

						console.log(data.email);
						var toEmail = data.email;

						var emailContainer = generalConfig.emailTemplate;

						

						var	dataString = "<p>Dear "+data.firstname+",</p>";
							dataString += "<p>You have successfully reset your password. Welcome to Om!</p>";
							dataString += "<p>We welcome your feedback – please let us know what you think of the new app, and feel free to suggest any improvements.</p>";
							
						var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;

						// EMail content
					    var message = {
						   	from:    generalConfig.impconfig.noRplyEmail,  //Like : Om music, LLC <no-reply@accompanymusic.com>
						   	to:      toEmail,
						   	subject: emailContainer.thanksEmailSubject,
						   	attachment: [
						      	{ data:emailContainerString, alternative:true },
						   	]
						};
		    			// Send Email Welcome to upgraded version of Om, LLc. 
		            	generalConfig.getServer.send(message, function(err, message) { console.log(err || message); });
		            	res.json({status:"succ", data : null, msg : "Your user account upgraded with "+generalConfig.impconfig.organizationName+"."});

					}).catch(function(err){
					    res.json({status:"fail", data : null, msg : err.message});
					});
	    		});
			}
			else
			{
				res.json({status:"succ", data : null, msg : "Password re-set successfully"});
			}
        }).catch(function(err){
        	console.log("Fail");
            res.json({status:"fail", data : null, msg : err.message});  
        });
    }
    else
    {
        res.json({status:"fail", data : null, msg : "Missing data User or Password"}); 
    }
};

/*
	Module : Login Cookie Encryption
	Author : Mayank [SOFTWEB]
	Inputs : PLain format of Email, Password
	Output : Encrypt inputed Email and Password
	Date   : 2015-12-03
*/
exports.encryptCookies = function(req, res){
	var encryptedPassword = encrypt(req.body.rememberPass);
	var encryptedEmail = encrypt(req.body.rememberEmail);
	res.json({encEmail : encryptedEmail , encPass : encryptedPassword});
};

/*
	Module : Login Cookie Decryption
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted format of Email, Password
	Output : Decrypt posted Email and Password
	Date   : 2015-12-03
*/
exports.decryptCookies = function(req, res){
	var decryptedEmail = decrypt(req.body.cookieEmail);
	var decryptedPassword = decrypt(req.body.cookiePassword);
	res.json({decEmail : decryptedEmail , decPass : decryptedPassword});
};


/*
	Module : Rep List
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : Rep List
	Date   : 2016-01-06
*/
exports.getRepList = function(req, res) {

    db.Pieces.findAll({
        attributes : ['id','title'],
        include: [
            { model : db.Composer, attributes : ['firstName','lastName']},
            { model : db.Libraries, attributes : { include:['id','title'] ,exclude:['createdAt','updatedAt'] }, through:{ attributes: { include:[], exclude:['libraryID','pieceID','createdAt','updatedAt','LibraryId','PieceId'] }}},
        ],
        where : { 
            $and: {
              isActive : true
            }
        },
        order  : '`composer`.`lastName`, `Pieces`.`id` '
    }).then(function(pieces){
		if(pieces) {
        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
        } else {
        	res.json({status:"fail", data : null, err : "Fail to load data"});	
        }	
    }).catch(function(err){
    	res.json({status:"fail", data : null, err : err.message});		
    });
};

/*
	Module : Encryption function
	Author : Mayank [SOFTWEB]
	Inputs : text
	Output : Encrypt text
	Date   : 2015-12-03
*/
function encrypt(text){
  	
  	var cipher = generalConfig.cryptoAuthentication.crypto.createCipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  	var crypted = cipher.update(text,'utf8','hex');
  	crypted += cipher.final('hex');
  	return crypted;

}

/*
	Module : Decryption function
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted text
	Output : Simple text
	Date   : 2015-12-03
*/ 
function decrypt(text){
  	
  	var decipher = generalConfig.cryptoAuthentication.crypto.createDecipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  	var dec = decipher.update(text,'hex','utf8');
  	dec += decipher.final('utf8');
  	return dec;

}