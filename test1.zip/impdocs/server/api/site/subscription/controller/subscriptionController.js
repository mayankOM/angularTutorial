'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');

/*  DO NOT DELETE */
exports.paypalIpncallBack =function (req , res) {
	
	
	
	var util = require('util');
	var message = {
	   	from:    generalConfig.impconfig.noRplyEmail,  //Like : Om music, LLC <no-reply@accompanymusic.com>
	   	to:      "ajay.khunti@gmail1.com.com",
	   	subject: generalConfig.impconfig.organizationName+" : Thanks for Subscription!",
	   	attachment: [
	      	{ data:"Hello, <br><br>"+util.inspect(req.body), alternative:true },
	   	]
	};
	
	generalConfig.getServer.send(message, function(err, message) { 
		if(err)
			res.send({'Error' : err});	
		
		if(req.body.txn_type == 'recurring_payment_profile_created') {
			
			var subscription 	= db.Subscription;
			var subsObj = {
				'profileStatus' : req.body.profile_status
			};

			subscription.findOne({ 
				where : { profileID : req.body.profile_status },
			}).then(function(piece){
		        if (piece) {
					piece.updateAttributes(subsObj).then(function(){
						res.send({'message' : 'Hello Here'});
					}).catch(function(err){
			        	res.send({status:err});
			    	});
				}
			});
		}
	});

};



/**** Function for paypal recurring call 
	**   and response saved to subscription table 
***/

exports.paypalPayment =function (req , res) {

	var CurrentDate = new Date();
	var selectedPlan_id = req.body.plan_id;

	if (selectedPlan_id == 1) {
		var end_date = CurrentDate.setMonth(CurrentDate.getMonth() + 6);
	} else {
		var end_date = CurrentDate.setMonth(CurrentDate.getMonth() + 12);
	}
	
	var dateTime = new Date(end_date);
	var end_dateTime = dateTime.toISOString(); 
	
	var reccuring_obj = {

		creditcardtype 		: req.body.creditcardtype,
		acct 				: req.body.acct,
		expdate 			: req.body.expdate,
		firstname 			: req.body.firstname,
   		lastname 			: req.body.lastname,
   		BILLINGPERIOD 		: req.body.BILLINGPERIOD,
   		BILLINGFREQUENCY 	: req.body.BILLINGFREQUENCY,
   		PROFILESTARTDATE 	: req.body.PROFILESTARTDATE,
   		AMT 				: req.body.AMT,
   		INITAMT 			: req.body.AMT,
   		DESC 				: req.body.DESC,
   		L_BILLINGAGREEMENTDESCRIPTION0 : req.body.L_BILLINGAGREEMENTDESCRIPTION0,
		L_BILLINGTYPE0 		: "RecurringPayments",
		CVV2 				: req.body.CVV2
	};

	
	//var selectedPlan_name = req.body.plan_name;
	var selectedPlan_description = req.body.plan_description;
	var selectedPlan_periodicity = req.body.plan_periodicity;
	var selectedPlan_name = '';
	
	if(selectedPlan_id == 1) {
		selectedPlan_name = '6 Month ';
	}else {
		selectedPlan_name = '1 Year ';
	}
	
	var UserEmail_Id 	= req.session.user.email;
	var emailContainer 	= generalConfig.emailTemplate;
	
	var	dataString = "<p>Hello "+req.body.firstname+",</p>";
		dataString += "<p>Thank you for your "+selectedPlan_name+" subscription to Om ($"+req.body.AMT+").</p>";
		dataString += "<p>We hope that you enjoy using our product. Please tell a friend!</p>";

	var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;

	var message = {
	   	from 	: generalConfig.impconfig.noRplyEmail,  //Like : Om music, LLC <no-reply@accompanymusic.com>
	   	to 		: UserEmail_Id,
	   	cc 		: "AK<ajay.khunti@gmail1.com.com>",
	   	subject : emailContainer.subscriptionEmailSubject,
	   	attachment : [
	      	{ data : emailContainerString, alternative : true },
	   	]
	};

	generalConfig.getServer.send(message, function(err, message) { 
		if(err){
			//res.json({status:'fail'});
		}
	});
	
	
	generalConfig.client.createRecurringPaymentsProfile(reccuring_obj).on('success', function(result) {
		
		if(result.ack == 'Success') {
		
			var subscriptionData = {
				'userID'		: 	req.session.user.id,
				'profileID'	 	:   result.profileid,
				'planID'		: 	req.body.plan_id,
				'profileStatus' : 	result.profilestatus,
				'startAt'		: 	req.body.PROFILESTARTDATE,
				'endAt'		    : 	end_dateTime	
			};	
			
			var subscriptionLogData = {
				'userID'		 : 	req.session.user.id,
				'correlationID'	 :  result.correlationid,
				'transactionID'	 :  result.transactionid,
				'ack'			 : 	result.ack,
				'price'			 : 	req.body.AMT,	
			};

			//Update after user buy a plan
			var userObj = {
				'isPaid' 		 : 1 
			};

			var subscription 	= db.Subscription;
			var subscriptionLog = db.SubscriptionLogs;
			
			subscription.findOrCreate({
		        where : { userID  : req.session.user.id }
		    }).then(function(data){

		        var subscriptionObj = data[0];
		        if(subscriptionObj) {
		            
		            subscriptionObj.updateAttributes(subscriptionData).then(function(){
	            		
	            		var subscriptionLogs = subscriptionLog.build(subscriptionLogData);
		            	subscriptionLogs.save().then(function(){	  

				 			db.User.update(userObj, { 
				                where : { id : req.session.user.id }
				            }).then(function(){
		        				res.json({status:'Success'});
				            });

				    	}).catch(function(err){
				        	res.json({status:err});
				    	});
		            
		            }).catch(function(err){
	    				res.json({status:err});
	    			});
		        }
		    
		    }).catch(function(err){
	    		res.json({status:err});
	    	});
	    
	    } else {
			res.json(result);	    	
	    }

	}).on('failure', function(result){
		res.json(result.errors[0]);
	});
};


/***  Get Plans details  ***/ 
exports.getPlandetails =function (req , res) {

	db.Plans.findAll({
		attribute:['id','name','price','description','periodicity']
	}).then(function(list){
        if (!list) 
            return next(new Error('Failed to load plans list '));
        
        res.json(list);
    }).catch(function(err){
    	res.json({status:"fail"});
    });

};

/*** Find Plan By ID ***/ 
exports.getPlandetailsById =function (req , res) {

	var id = req.body.planid;

    db.Plans.find({where : { id: id }}).then(function(plans){
    	if (!plans) 
            return next(new Error('Failed to load User ' + id));
      
      res.json(plans);
    }).catch(function(err){
    	res.json({status:err});
    });

};


/*** Get Subscription Log ***/ 
exports.getSubLog =function (req , res) {

	var userID = decrypt(req.body.user_id);
	//req.body.id = decrypt(req.body.userId);
	var decryptedUserID = parseInt(userID);
	
    db.SubscriptionLogs.findAll({
    	attributes : ['id','userID','correlationID','transactionID','price','ack'],
    	where : { userID: decryptedUserID }
    }).then(function(result){

    	if (!result) 
            return next(new Error('Failed to load User ' + id));

    	db.Subscription.find({
	    	attributes : ['id','userID','profileID','startAt','endAt'],
	        include: [
	            { model : db.Plans, attributes : ['id','name','periodicity']},
	            { model : db.User, attributes : ['id','isPaid']},
	        ],
	    	where : { userID: decryptedUserID }
	    }).then(function(planStatus){
	    	res.json({'planStatus' : planStatus, 'subscriptionStatus' : result});
    	}).catch(function(err){
	    	res.json({status:err});
	    });
    }).catch(function(err){
    	res.json({status:err});
    });

};


/*** Cancel Subscription as per user ProfileId and Transaction Id ***/ 
exports.cancelSubscription =function (req , res) {

	var profileID = req.body.profileID;
	var transactionID = req.body.transactionID;
	var action = req.body.action;

	generalConfig.client.manageRecurringPaymentsProfileStatus({
          //startdate:'2010-09-05T08:15:30-05:00',
          transactionid : 	transactionID,
          profileid 	: 	profileID,
          action 		: 	action
          //transactionclass:'All'
        }).on('success', function(result){

		console.log("------Get a Transaction detail -----");
		console.log(result);
		console.log("------Get a Transaction detail -----");
		//res.json(result);

  	}).on('failure', function(result){

  		console.log("------Failed a Transaction detail -----");
		console.log(result);
		console.log("------Failed a Transaction detail -----");

	})

};




/*
	Module : Encryption function
	Author : Mayank [SOFTWEB]
	Inputs : text
	Output : Encrypt text
	Date   : 2015-12-03
*/
function encrypt(text){
  	var cipher = generalConfig.cryptoAuthentication.crypto.createCipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  	var crypted = cipher.update(text,'utf8','hex');
  	crypted += cipher.final('hex');
  	return crypted;
}

/*
	Module : Decryption function
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted text
	Output : Simple text
	Date   : 2015-12-03
*/ 
function decrypt(text){
  	var decipher = generalConfig.cryptoAuthentication.crypto.createDecipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  	var dec = decipher.update(text,'hex','utf8');
  	dec += decipher.final('utf8');
  	return dec;
}