'use strict';


var db = require('../../../../config/sequelize');

/*
	Module : MusicLibrary
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : List of Instruments
	Date   : 2015-10-28
*/
exports.getInstruments = function(req, res) {
    db.Instruments.findAll().then(function(instruments){

    	//console.log("----get instruments----");
    	//console.log(instruments);
        if(instruments)	{
        	res.json({status:"succ", data : instruments, msg : "Data loaded successfully"});
        
        } else {
        	res.json({status:"fail", data : null, msg : "Fail to load data"});	
        }	
    }).catch(function(err){
    	res.json({status:"fail", data : null, msg : err});		
    });
};


/*
	Module : MusicLibrary
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : List of Libraries
	Date   : 2015-10-28
*/
exports.getLibraries = function(req, res) {
    db.Libraries.findAll().then(function(libraries){

    	//console.log("----get libraries----");
    	//console.log(libraries);

        if(libraries)	
        {
        	res.json({status:"succ", data : libraries, msg : "Data loaded successfully"});
        }
        else
        {
        	res.json({status:"fail", data : null, err : "Fail to load data"});	
        }	
    }).catch(function(err){
    	res.json({status:"fail", data : null, err : err});		
    });
};


/*
	Module : MusicLibrary
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : List of Music Libraries (Pieces)
	Date   : 2015-10-28
*/
exports.getMuscilibrary = function(req, res) {

	
	db.Pieces.findAll({include: [{ model: db.Composer },{ model: db.PianoTypes },{ model: db.Libraries }], order: 'id DESC'}).then(function(pieces){
		

		if(pieces) {
        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});

        } else {
        	res.json({status:"fail", data : null, err : "Fail to load data"});	
        
        }	
    }).catch(function(err){
    	res.json({status:"fail", data : null, err : err.message});		
    });
};
/*
	Module : MusicLibrary
	Author : Mayank [SOFTWEB]
	Inputs : 
	Output : List of Music Libraries (Pieces)
	Date   : 2015-10-28
*/
exports.getFilteredMuscilibrary = function(req, res) {

	if(req.body.q != "" || req.body.instruments != "" || req.body.libraries != "" )
	{
		//var whereParams = {};
		/*if(req.body.q != "")
		{
			var obj = {
				title	: 
			};
		}	*/

		console.log(req.body);

		/*var search_keyword = "";
		var search_instrumentID = "";
		var search_librariesID = "";

		if(typeof req.body.q == 'undefined' || req.body.q == "")
		{
			search_keyword = '';
		}
		else
		{
			search_keyword = req.body.q;
		}	


		if(typeof req.body.libraries  == 'undefined' || req.body.libraries == null)
		{
			search_librariesID = '';
		}
		else
		{
			search_librariesID = req.body.libraries ;
		}

		if(typeof req.body.instruments  == 'undefined' || req.body.instruments == null)
		{
			search_instrumentID = '';
		}
		else
		{
			search_instrumentID = req.body.instruments ;
		}


		if(search_keyword != "" && search_librariesID != "" && search_instrumentID != "" )
		{
			console.log("All avail");//All avail

		}	
		else if(search_keyword != "" && search_librariesID == "" && search_instrumentID == "" )
		{
			console.log("1. Only Keyword");//1. Only Keyword

			db.Pieces.findAll({
				include: [ { model: db.Libraries }],
				where: {
							title : { $like: '%'+req.body.q+'%' }
				   		},
			    order: 'id DESC'
			}).then(function(pieces){

				if(pieces)	
		        {
		        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
		        }
		        else
		        {
		        	res.json({status:"fail", data : null, err : "Fail to load data"});	
		        }	
		    }).catch(function(err){
		    	res.json({status:"fail", data : null, err : err.message});		
		    });
		}
		else if(search_keyword == "" && search_librariesID != "" && search_instrumentID == "" )
		{	
			console.log("2. Only Libraries");//2. Only Libraries

			db.Pieces.findAll({
				include: [ 
						{ model: db.Libraries , "where" : {"id" :  req.body.libraries }  } ], 
			    order: 'id DESC'
			}).then(function(pieces){

				if(pieces)	
		        {
		        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
		        }
		        else
		        {
		        	res.json({status:"fail", data : null, err : "Fail to load data"});	
		        }	
		    }).catch(function(err){
		    	res.json({status:"fail", data : null, err : err.message});		
		    });
		}
		else if(search_keyword == "" && search_librariesID == "" && search_instrumentID != "" )
		{
			console.log("3. Only Instruments");//3. Only Instruments
		}
		else if(search_keyword != "" && search_librariesID != "" && search_instrumentID == "" )
		{
			console.log("4. Keyword + Library");//4. Keyword + Library
			db.Pieces.findAll({
				include: [ { model: db.Libraries , "where" : {"id" :  req.body.libraries } }],
				where: {
							title : { $like: '%'+req.body.q+'%' }
				   		},
			    order: 'id DESC'
			}).then(function(pieces){

				if(pieces)	
		        {
		        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
		        }
		        else
		        {
		        	res.json({status:"fail", data : null, err : "Fail to load data"});	
		        }	
		    }).catch(function(err){
		    	res.json({status:"fail", data : null, err : err.message});		
		    });
		}
		else if(search_keyword != "" && search_librariesID == "" && search_instrumentID != "" )
		{
			console.log("5. Keyword + instrument");//5. Keyword + instrument
		}
		else if(search_keyword == "" && search_librariesID != "" && search_instrumentID != "" )
		{
			console.log("6. Keyword + instrument");//6. Keyword + instrument	
		}	
*/


		/*if(req.body.q != "")
		{
			whereParams = "where: {
						$or: [
							{
								title : { $like: '%'"+req.body.q+"'%' }
							}
						]
				   }, ";
		}	
		else
		{
			whereParams =;
		}	*/

		/*db.Pieces.findAll({
			include: [ { model: db.Composer},{ model: db.Libraries, "where" : {"id" :  req.body.libraries }  }],
			where: {
						title : { $like: '%'+req.body.q+'%' }
			   		},
		    order: 'id DESC'
		}).then(function(pieces){

			console.log("----No of records");
			console.log(pieces.length);

			if(pieces)	
	        {
	        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
	        }
	        else
	        {
	        	res.json({status:"fail", data : null, err : "Fail to load data"});	
	        }	
	    }).catch(function(err){
	    	res.json({status:"fail", data : null, err : err.message});		
	    });*/

		console.log("Hello Here => "+ req.body.libraries);
		
		/*var temp = '';
		if(typeof req.body.libraries  != 'undefined' || req.body.instruments != null) {
			temp = ',{ model: db.Libraries, where : {id : req.body.libraries }}';
		}*/

		db.Pieces.findAll({
			include: [ 
				{ model: db.Composer },
				{ model: db.Libraries, where : req.body.libraries ? { id : req.body.libraries } : null }
			],
			where: {
				title : { $like: '%'+req.body.q+'%' }
			},
		    order: 'id DESC'
		}).then(function(pieces){

			console.log("----No of records");
			console.log(pieces.length);

			if(pieces)	
	        {
	        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
	        }
	        else
	        {
	        	res.json({status:"fail", data : null, err : "Fail to load data"});	
	        }	
	    }).catch(function(err){
	    	res.json({status:"fail", data : null, err : err.message});		
	    });

		

		
		
	}	
	else
	{
		res.json({status:"fail", data : null, err : "Select any serach option"});	


		/*db.Pieces.findAll({
			include: [ { model: db.Composer },{ model: db.PianoTypes } ], 
		    order: 'id DESC'
		}).then(function(pieces){
			if(pieces)	
	        {
	        	res.json({status:"succ", data : pieces, msg : "Data loaded successfully"});
	        }
	        else
	        {
	        	res.json({status:"fail", data : null, err : "Fail to load data"});	
	        }	
	    }).catch(function(err){
	    	res.json({status:"fail", data : null, err : err.message});		
	    });*/
	}	
};

/*SELECT `Pieces`.`id`, `Pieces`.`title`, `Pieces`.`style`, `Pieces`.`composerId`, `Pieces`.`libraryId`,
 `Pieces`.`isActive`, `Pieces`.`instrumentId`, `Pieces`.`pianoTypeId`, `Pieces`.`keyId`, 
`Pieces`.`tuningId`, `Pieces`.`videourl`, `Pieces`.`tempo`, `Pieces`.`sheetMusic`, 
`Pieces`.`professionalPerformance`, `Pieces`.`createdAt`, `Pieces`.`updatedAt`, `Pieces`.`PianoTypeId`,
 `Pieces`.`ComposerId`, `Composer`.`id` AS `Composer.id`, `Composer`.`firstName` AS `Composer.firstName`,
  `Composer`.`lastName` AS `Composer.lastName`, `Composer`.`createdAt` AS `Composer.createdAt`,
   `Composer`.`updatedAt` AS `Composer.updatedAt`, `PianoType`.`id` AS `PianoType.id`,
    `PianoType`.`title` AS `PianoType.title`, `PianoType`.`createdAt` AS `PianoType.createdAt`, 
    `PianoType`.`updatedAt` AS `PianoType.updatedAt`, `Libraries`.`id` AS `Libraries.id`,
     `Libraries`.`title` AS `Libraries.title`, `Libraries`.`createdAt` AS `Libraries.createdAt`,
      `Libraries`.`updatedAt` AS `Libraries.updatedAt`, `Libraries.LibrariesPieces`.`libraryID` 
      AS `Libraries.LibrariesPieces.libraryID`, `Libraries.LibrariesPieces`.`pieceID` AS 
      `Libraries.LibrariesPieces.pieceID`, `Libraries.LibrariesPieces`.`createdAt` AS 
      `Libraries.LibrariesPieces.createdAt`, `Libraries.LibrariesPieces`.`updatedAt` AS 
      `Libraries.LibrariesPieces.updatedAt`, `Libraries.LibrariesPieces`.`LibraryId` AS 
      `Libraries.LibrariesPieces.LibraryId`, `Libraries.LibrariesPieces`.`PieceId` AS 
      `Libraries.LibrariesPieces.PieceId` FROM `pieces` AS `Pieces` LEFT OUTER JOIN `composers` AS 
      `Composer` ON `Pieces`.`ComposerId` = `Composer`.`id` LEFT OUTER JOIN `pianotypes` AS `PianoType` 
      ON `Pieces`.`PianoTypeId` = `PianoType`.`id` INNER JOIN (`libraries_pieces` AS 
      `Libraries.LibrariesPieces` INNER JOIN `libraries` AS `Libraries` ON `Libraries`.`id` = 
      `Libraries.LibrariesPieces`.`LibraryId`) ON `Pieces`.`id` = `Libraries.LibrariesPieces`.`PieceId` 
      AND `Libraries`.`id` = 2 ORDER BY id DESC*/