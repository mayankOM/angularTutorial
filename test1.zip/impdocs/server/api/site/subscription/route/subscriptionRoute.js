'use strict';

var subscription = require('../controller/subscriptionController');

module.exports = function(app) {
	app.post('/api/site/getPlandetails', subscription.getPlandetails);
	app.post('/api/site/getPlan', subscription.getPlandetailsById);
	app.post('/api/site/payment', subscription.paypalPayment);
	app.post('/api/site/getSubLog', subscription.getSubLog);
	app.post('/api/site/cancelSubscription', subscription.cancelSubscription);
	
	/* DO Not Delete */ 
	app.post('/paypalIpncallBack', subscription.paypalIpncallBack);
};