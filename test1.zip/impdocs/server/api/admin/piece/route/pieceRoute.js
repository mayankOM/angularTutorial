'use strict';

var adminPiece = require('../controller/pieceController');

var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
	
	app.post('/api/admin/addPiece', adminPiece.create);
	app.get('/api/admin/listPieces', adminPiece.list);
	app.post('/api/admin/syncAudioList', adminPiece.syncAudioList);
	app.post('/api/admin/getAudioList', adminPiece.getAudioList);
	app.post('/api/admin/getPiece', adminPiece.getById);
	app.post('/api/admin/updatePiece', adminPiece.update);
	app.post('/api/admin/deletePiece', adminPiece.delete);


	app.post('/api/admin/importPiecesByXlsx', multipartMiddleware, adminPiece.importPiecesByXlsx);

};