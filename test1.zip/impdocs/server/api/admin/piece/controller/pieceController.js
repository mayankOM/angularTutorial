'use strict';

var db 				= require('../../../../config/sequelize');
var fs 				= require('fs');
var Finder 			= require('fs-finder');
var path 			= require('path');



//S3Bucket Configuration
var generalConfig 		= require('../../../../config/generalConfig');
var AWS 				= require('aws-sdk');

//var awsConfiguration 	= generalConfig.AWS.development;
var awsConfiguration 	= generalConfig.AWS.production;

AWS.config.update({
	accessKeyId: awsConfiguration.accessKeyId, 
	secretAccessKey: awsConfiguration.secretAccessKey
});

AWS.config.region 	= 'us-east-1';

var s3 				= new AWS.S3();
var bucketName 		= awsConfiguration.s3BucketName;
var folderNmae 		= awsConfiguration.innerFolder;
//End -- 



exports.list = function(req, res, next) {
    db.Pieces.findAll( { 
    	attributes : ['id','title','sheetMusic'], 
    	include: [
            { model : db.Composer, attributes : ['firstName','lastName']},
        ],
    	order: 'id DESC' 
    } ).then(function(piece){
        if (!piece) 
            return next(new Error('Failed to load Pieces'));
        //req.profile = piece;
        res.json(piece);
    }).catch(function(err){
    	res.json({status:"fail"});
    });
};



exports.s3OperationCreateFolder = function(pieceID,req,res){
	
	var params = {
	    Bucket: bucketName,         	//required 
	    Key: folderNmae+pieceID+'/',  	//required 
	    ACL: 'private',
	};

	s3.putObject(params, function(err, data) {
	    if (err) 
	        res.json({status:"success",msg:" Piece created but there is some issue in folder creation " + pieceID });     //successful response 	//an error occurred
	    else
	        res.json({status:"success",msg:" Piece and folder on s3 bucket clreated successfully " + pieceID });     //successful response
	});
};



exports.s3OperationListPieceContent = function(pieceID,req,res) {
	
	var params = {
	    Bucket: bucketName,                     
	    Prefix: folderNmae+pieceID+'/',
	};
	
	
	function processAudioFiles(index, filesArray, totalElement, finalTempoArray) {
		
		
		var element 	= filesArray[index].Key;
		var splitArray 	= element.split("/");
		var fileName 	= splitArray[splitArray.length-1];
		var tempo 		= fileName.split(".")[0];
		var audioFiles 	= db.AudioFiles;
		
		audioFiles.findOrCreate({
	        where : { 
	            $and: {
	                pieceID : pieceID,
	                tempo  : tempo
	            }
	        }
	    }).then(function(data){

	        finalTempoArray.push(tempo);
	        var audioFiles = data[0];
	        if(audioFiles) {
			            
	            var listArray = {
		    		'file'		: fileName,
		    		'pieceID'	: pieceID,
		    		'tempo'		: tempo
		    	};
	            
	            audioFiles.updateAttributes(listArray).then(function(){
            		index++;
	            	
	            	if(index == totalElement) {
	            		db.AudioFiles.destroy({ 
	            			where: { 
	            				$and: {
                  					tempo : { $notIn :finalTempoArray },
                  					pieceID : pieceID
                				} 
                			}
	            		}).then(function(){
	            			res.json({status :'success'});
	            		});
	            	
	            	} else
	            		processAudioFiles(index, filesArray, totalElement,finalTempoArray);	
	            });
	        }
	    });
    }

	s3.listObjects(params, function(err, data) {
	    
	    if (err) {
	        //console.log(err, err.stack); 		//an error occurred
	        res.json({status:'fail', msg:err});
	    } else {
	        
	        
	        //successful response
	        var filesArray 		= data.Contents;
	        var totalElement 	= data.Contents.length;
	        var index 			= 1;
	        var finalTempoArray = [];
	        
	        if(totalElement > 1) 
	        	processAudioFiles(index, filesArray, totalElement, finalTempoArray);	
	        else {
	        	
	        	db.AudioFiles.destroy({ 
        			where: { pieceID : pieceID } 
        		}).then(function(){
        			res.json({status :'fail',msg: 'No audio file found'});
        		});
	        	
	        }
	    }
	});
};


//new code
exports.create = function(req, res) {
    
	if(req.body != "") {
		
		req.checkBody('title', 'Title required').notEmpty();
		req.checkBody('composerID', 'composer Id required').notEmpty();
		req.checkBody('tempo', 'Tempo required').notEmpty();
		req.checkBody('isActive', 'Piece status required').notEmpty();

		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		
		var message 		= null;
		var piece 			= db.Pieces;
		var instruments 	= req.body.instrumentId;
	    var libraries   	= req.body.libraryId;
	    
	    var pieceObj = {
			'title' 					: req.body.title,
			'sheetMusic' 				: req.body.sheetMusic,
			'composerID' 				: req.body.composerID,
			'tempo' 				    : req.body.tempo,
			'isActive' 				    : req.body.isActive
		};

	    piece.create(pieceObj).then(function(newObj){

	        var associationPromises = [];
	    	//LibrariesPieces table
	    	//Piece covers under such library 
	    	for (var key in libraries) {
			  	if (libraries.hasOwnProperty(key)) {
			    	if(libraries[key] === true) {
			    		
			    		associationPromises.push(db.LibrariesPieces.create({
		        			LibraryId 	: key,
		        			pieceID 	: newObj.id
		      			}))
			    	
			    	}
			  	}
			}

			//InstrumentsPieces table
			//peace belongs to instuments
			for (var key in instruments) {
			  	if (instruments.hasOwnProperty(key)) {
			    	if(instruments[key] === true) {
			    		associationPromises.push(db.InstrumentsPieces.create({
		        			InstrumentId 	: key,
		        			pieceID 		: newObj.id
		      			
		      			}))
			    	}
			  	}
			}
	        
	        res.json({status:"success", msg:"" }); 
	        //need to remove comment when going live 
	        //exports.s3OperationCreateFolder(newObj.id.toString(),req, res);
	    
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	

	} else {
		res.json({status:mappedErrors});	
	}

};

/**
    * Update Piece
*/
exports.update = function(req, res) {
	
	console.log(req.body);

	if(req.body != "") {
		
		req.checkBody('title', 'Title required').notEmpty();
		req.checkBody('composerID', 'composer Id required').notEmpty();
		req.checkBody('tempo', 'Tempo required').notEmpty();
		req.checkBody('isActive', 'Piece status required').notEmpty();		

		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		
		var pieceTable 			= db.Pieces;
		var librariyTable 		= db.Libraries;
		var instrumentTable 	= db.Instruments;

		var instruments 		= req.body.instrumentId;
	    var libraries   		= req.body.libraryId;


	    var pieceObj = {
			
			'title' 					: req.body.title,
			'sheetMusic' 				: req.body.sheetMusic,
			'composerID' 				: req.body.composerID,
			'tempo' 				    : req.body.tempo,
			'isActive' 				    : req.body.isActive
		
		};

		pieceTable.findOne({ 
			where : { id : req.body.id },
			include: [
				{ model : librariyTable },
				{ model : instrumentTable }
			],
		}).then(function(piece){
			
	        if (piece) {
	        	
				Promise.all([
					
					piece.updateAttributes(pieceObj),
				    piece.Libraries.map(function (libPieceObj) {

				        if (!libraries.hasOwnProperty(libPieceObj.id)) {
				        		
				        	libPieceObj.LibrariesPieces.destroy();
				        
				        } else if(libraries.hasOwnProperty(libPieceObj.id)) {
				        	
				        	if(libraries[libPieceObj.id] === false) {
				        		
				        		libPieceObj.LibrariesPieces.destroy();
				        		var prop = libPieceObj.id;
								delete libraries[prop];

				        	} else if(libraries[libPieceObj.id] === true){

				        		var prop = libPieceObj.id;
								delete libraries[prop];
				        	}
				        }

				    }),
				    piece.Instruments.map(function (insObj) {
				        
				        if (!instruments.hasOwnProperty(insObj.id)) {
				        	
				        	insObj.InstrumentsPieces.destroy();
				        
				        } else if(instruments.hasOwnProperty(insObj.id)) {
				        	
				        	if(instruments[insObj.id] === false) {
				        		
				        		insObj.InstrumentsPieces.destroy();
				        		var prop = insObj.id;
								delete instruments[prop];

				        	} else if(instruments[insObj.id] === true) {
				        		var prop = insObj.id;
								delete instruments[prop];
				        	}
				        
				        }
				    })

				]).then(function () {
					
					var associationPromises = [];
	    	    	//LibrariesPieces table
			    	//Piece covers under such library 
			    	for (var key in libraries) {
					  	if (libraries.hasOwnProperty(key)) {
					    	if(libraries[key] === true) {
					    		
					    		associationPromises.push(db.LibrariesPieces.create({
				        			LibraryId 	: key,
				        			pieceID 	: piece.id
				      			}))
					    	
					    	}
					  	}
					}

					//InstrumentsPieces table
					//peace belongs to instuments
					for (var key in instruments) {
					  	if (instruments.hasOwnProperty(key)) {
					    	if(instruments[key] === true) {
					    		associationPromises.push(db.InstrumentsPieces.create({
				        			InstrumentId 	: key,
				        			pieceID 		: piece.id
				      			}))
					    	}
					  	}
					}
					db.Promise.all(associationPromises);
				})
	        }
	        res.json({status:"success"});
	    }).catch(function(err){
	    	res.json({status:"fail"});
	    });
	} else {
		res.json({status:mappedErrors});	
	}   
};



/**
* Delete Piece
*/
exports.delete = function(req, res) {

	var cnt = parseInt(0);
    db.Pieces.destroy({ where : { id : req.body.id }}).then(function(){
    	cnt++;
		db.LibrariesPieces.destroy({ where : { pieceID : req.body.id }})
		.then(function(){
    		cnt++;
    		db.InstrumentsPieces.destroy({ where : { pieceID : req.body.id }}).then(function(){
	    		cnt++;
			}) // the result of readAnotherFile
		})
		res.json({status:"success"});
    }).catch(function(err){
    	console.log("--- else fail ---");
        res.json({status:"fail"});
    });
};


/**
* Find Piece by id
*/
exports.getById = function(req, res, next) {

	var pieceTable 			= db.Pieces;
	var librariyTable 		= db.Libraries;
	var instrumentTable 	= db.Instruments;

    pieceTable.find(
    	{where : { id : req.body.id },
    	attributes : ['id','title','composerID','isActive','tempo','sheetMusic'],
    	
    	include: [
			{ model : librariyTable, attributes : ['id'] },
			{ model : instrumentTable, attributes : ['id'] }
		],
    
    }).then(function(piece){
        if (!piece) 
            return next(new Error('Failed to load Piece '));
        res.json(piece);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

//Get a list of Audio files
/** Consider the below file name pattern [2015-12-19]	

	File name : 2026_1_D_40_440.m4a
	2026 = Piece ID
	1 	 = Piano type
	D 	 = Key Value
	40 	 = Tempo
	440  = Tuning
**/
exports.syncAudioList = function(req, res, next) {
	
	//res.json({status :'success'});
	//Need to remove comment when going live
	exports.s3OperationListPieceContent(req.body.pieceId,req,res);
};


/**
    * Find Piece by id
*/
exports.getAudioList = function(req, res, next) {

	var AudioFiles 	= db.AudioFiles;
	var Keys 		= db.Keys;
	var Tunings 	= db.Tunings;
	
    AudioFiles.findAll(
    	{where : { pieceID : req.body.id },
    	attributes : ['id','tempo','file'],
    	/*include: [
			{ model : Keys, attributes : ['id','title'] },
			{ model : Tunings, attributes : ['id','tuning'] }
		]*/
    }).then(function(audio){
        if (!audio) 
            return next(new Error('Failed to load Audio files '));
        res.json(audio);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};


exports.importPiecesByXlsx = function(req, res, next){

	var file = req.files.file;
	var fileName = file.name;
	var tmpPath = file.path;
    var destPath = 'public/assets/Site/pieces/'+fileName;
    var fileSystem = require('fs-extra');

    fileSystem.copy(tmpPath, destPath, { replace: false }, function (err) {
        
        if (err) {
            res.json({status:"fail", msg : err});
        } else {                
            
        	var XLSX 		= require('xlsx');
			var workBook 	= XLSX.readFile('public/assets/Site/pieces/'+fileName);
			
			var result = [];
			workBook.SheetNames.forEach(function(sheetName) {
    			var roa = XLSX.utils.sheet_to_row_object_array(workBook.Sheets[sheetName]);
    			if(roa.length > 0){
      				result[sheetName] = roa;
    			}
  			});
  			//console.log(result['MAIN SHEET']);
  			var dataSet = result['MAIN SHEET'];
  			
  			if(dataSet.length){
  				
  				
  				var pieceTable 		= db.Pieces;
  				var librariyTable 	= db.Libraries;
				var instrumentTable = db.Instruments;

				var associationPromises = [];
  				
  				
  				dataSet.forEach(function(element){
  					

  					pieceTable.findOrCreate({ 
						where : { id : element.FolderNo,},
						include: [
							{ model : librariyTable },
							{ model : instrumentTable }
						],
					}).then(function(data){

						var piece = data[0];
						if(piece) {

							associationPromises.push(piece.updateAttributes({
			        			
			        			title 		: element.Title,
			        			composerID 	: parseInt(element.ComposerId),
			        			isActive	: (element.IsActive === '1') ? true : false,
			        			tempo 		: parseInt(element.Tempo),
			        			sheetMusic 	: element.SheetMusic
			      			
			      			}))
							
							
							if(piece.hasOwnProperty('Libraries')) {
								
								piece.Libraries.map(function (libObj) {
							        
							        if(parseInt(element.Genre) != libObj.id) {
							        	
							        	libObj.LibrariesPieces.destroy();
							        	associationPromises.push(db.LibrariesPieces.create({
		        							
		        							LibraryId 	: parseInt(element.Genre),
		        							pieceID 	: piece.id
		      							
		      							}))
							        
							        }
							    })
								
							} else {
								
								associationPromises.push(db.LibrariesPieces.create({
		        					
		        					LibraryId 	: parseInt(element.Genre),
		        					pieceID 	: piece.id
		      					
		      					}))
							}


							if(piece.hasOwnProperty('Instruments')) {
								
								piece.Instruments.map(function (insObj) {
							        
							        if(parseInt(element.Instrument) != insObj.id) {
							        	insObj.InstrumentsPieces.destroy();
							        	associationPromises.push(db.InstrumentsPieces.create({
		        							
		        							InstrumentId 	: parseInt(element.Instrument),
		        							pieceID 		: piece.id
		      							
		      							}))
							        }
							    })

								
							} else {
								
								associationPromises.push(db.InstrumentsPieces.create({
		        					
		        					InstrumentId 	: parseInt(element.Instrument),
		        					pieceID 		: piece.id
		      			
		      					
		      					}))
							
							}

							db.Promise.all(associationPromises);

						}
						
					}).catch(function(err){
						console.log(err);
					});


  				
  				});


  			}
			



            res.json({status:"succ", msg : "File upload done.", filename : fileName });
        
        }
    });

};