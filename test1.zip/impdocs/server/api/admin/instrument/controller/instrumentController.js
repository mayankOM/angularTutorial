'use strict';

var db = require('../../../../config/sequelize');

/**
** create Genre/Library
**/
exports.create = function(req, res) {
   
	if(req.body != "") {
		req.checkBody('title', 'title required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		var message = null;
		
		//return false;
	    var instruments = db.Instruments.build(req.body);
	    instruments.save().then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		res.json({status:mappedErrors});	
	}   
};


/**
** List Genre/Library
**/
exports.list = function(req, res, next) {

	 db.Instruments.findAll({order: 'id DESC'}).then(function(instruments){
        if (!instruments) 
            return next(new Error('Failed to load Genre ' + id));
        
        res.json(instruments);
    }).catch(function(err){
    	console.log(err);
    	res.json({status:"fail"});
    });
};


/**
** get single Genre/Library
**/
exports.getById = function(req, res, next) {
    
    db.Instruments.find({where : { id : req.body.id }}).then(function(instruments){
        if (!instruments) 
            return next(new Error('Failed to load Composer ' + id));
        res.json(instruments);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    * Update Genre/Library
*/
exports.update = function(req, res) {
	if(req.body != "") {		
		req.checkBody('title', 'Title required').notEmpty();
		
		var mappedErrors = req.validationErrors(true);
	}	
	if(mappedErrors == false) {
		var message = null;
	    
		var obj = {
			'title'		: 	req.body.title,
		};	

	  	db.Instruments.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else {
		res.json({status:mappedErrors});	
	}   
};

/**
** delete Instruments/Library
**/
exports.delete = function(req, res) {

    db.Instruments.destroy({ where : { id : req.body.id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};