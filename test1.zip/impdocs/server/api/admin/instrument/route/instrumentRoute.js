'use strict';

var adminInstrument = require('../controller/instrumentController');

module.exports = function(app) {

	app.post('/api/admin/addInstrument', adminInstrument.create);

	app.get('/api/admin/listInstruments', adminInstrument.list);
	
	app.post('/api/admin/getInstrument', adminInstrument.getById);
	app.post('/api/admin/updateinstrument', adminInstrument.update);
	app.post('/api/admin/deleteInstrument', adminInstrument.delete);

};