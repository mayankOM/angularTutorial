'use strict';

var db = require('../../../../config/sequelize');

//new code
exports.create = function(req, res) {
    
	if(req.body != "") {
		req.checkBody('title', 'Title required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		var message = null;
	    var pianoTypes = db.PianoTypes.build(req.body);

	    //pianoTypes.provider = 'local';
	    pianoTypes.save().then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	} else {
		res.json({status:mappedErrors});	
	}   
};

//LIst of Piano types
exports.list = function(req, res, next) {
    db.PianoTypes.findAll({order: 'id DESC'}).then(function(pianoTypes){
        if (!pianoTypes) 
            return next(new Error('Failed to load Piano Type ' + id));
        req.profile = pianoTypes;
        res.json(pianoTypes);
    }).catch(function(err){
    	res.json({status:"fail"});
    });
};

/**
    * Update Piano type
*/
exports.update = function(req, res) {
	if(req.body != "")
	{
		req.checkBody('title', 'Title required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	if(mappedErrors == false)
	{
		var message = null;
			var obj = {
				'title'		: 	req.body.title
			};	
	  	db.PianoTypes.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else
	{
		res.json({status:mappedErrors});	
	}   
};



/**
    * Delete Piano type
*/
exports.delete = function(req, res) {

    db.PianoTypes.destroy({ where : { id : req.body.id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    * Find Piano type by id
*/
exports.getById = function(req, res, next) {
    
    db.PianoTypes.find({where : { id : req.body.id }}).then(function(pianoTypes){
        if (!pianoTypes) 
            return next(new Error('Failed to load Piano Type ' + id));
        res.json(pianoTypes);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};