'use strict';

var adminPianoType = require('../controller/pianoTypeController');

module.exports = function(app) {

	app.post('/api/admin/addPianoType', adminPianoType.create);
	app.get('/api/admin/listPianoType', adminPianoType.list);
	app.post('/api/admin/getPianoType', adminPianoType.getById);
	app.post('/api/admin/updatePianoType', adminPianoType.update);
	app.post('/api/admin/deletePianoType', adminPianoType.delete);
};