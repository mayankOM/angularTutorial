'use strict';

var db = require('../../../../config/sequelize');
var fs = require('fs');
var jstoxml = require('jstoxml');

exports.create = function(req, res) {
    
	if(req.body != "") {
		req.checkBody('firstName', 'Firstname required').notEmpty();
		req.checkBody('lastName', 'Lastname required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		var message = null;
	    var composer = db.Composer.build(req.body);

	    //composer.provider = 'local';
	    console.log('New Composer (local) : { firstName: ' + composer.firstName + ' lastName: ' + composer.lastName + ' }');
	    composer.save().then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		res.json({status:mappedErrors});	
	}   
};


exports.list = function(req, res, next) {
    db.Composer.findAll({order: 'id DESC'}).then(function(composer){
    	
        if (!composer) 
            return next(new Error('Failed to load Composer ' + id));
        req.profile = composer;

        res.json(composer);
    }).catch(function(err){
    	res.json({status:"fail"});
    });
};

/**
    * Update user
*/
exports.update = function(req, res) {
	if(req.body != "")
	{
		
		req.checkBody('firstName', 'Firstname required').notEmpty();
		req.checkBody('lastName', 'Lastname required').notEmpty();
		
		var mappedErrors = req.validationErrors(true);
	}	
	if(mappedErrors == false)
	{
		var message = null;
	    //var composer = db.Composer.build(req.body);

			var obj = {
				'firstName'		: 	req.body.firstName,
				'lastName'		: 	req.body.lastName,
			};	

	  	db.Composer.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else
	{
		res.json({status:mappedErrors});	
	}   
};


/**
    * Send User
*/
exports.delete = function(req, res) {

	//console.log(req.body); return false;
    db.Composer.destroy({ where : { id : req.body.id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};


/**
    * Find user by id
*/
exports.getById = function(req, res, next) {
    
    db.Composer.find({where : { id : req.body.id }}).then(function(composer){
        if (!composer) 
            return next(new Error('Failed to load Composer ' + id));
        res.json(composer);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    * Export JSON data
*/
exports.getExportJSON = function(req, res, next) {
	db.Composer.findAll().then(function(composer){
		res.json(composer);	
    }).catch(function(err){
    	res.json({status:"fail"});
    });
};

/**
    * Create and download CSV file including Composer's list
*/
exports.getExportData = function(req, res, next) {
    
    db.Composer.findAll().then(function(composer){
    	var dataArray = [];
    	for (var key in composer) {
    		
			var dataObj = {
				"composer" :
					{
						"ComposerID"	: composer[key].id,
						"FirstName"		: composer[key].firstName,
						"LastName"		: composer[key].lastName,
						"CreatedAt"		: Date(composer[key].createdAt),
						"UpdatedAt"		: Date(composer[key].updatedAt)
					}
				}
			dataArray.push(dataObj);
		}

		if(req.body.exportBy == 'JSON'){
			
			var filename = "public/assets/export/composerJSONExport.json";
			fs.writeFile(filename, JSON.stringify(composer), function(err) {
				if (err) 
					throw err;
				res.json({status:"success"});
			});
		} else {
			
			var xmlData = jstoxml.toXML({
			  _name: 'composers',
			  _content: dataArray
			}, {header: true, indent: '  '});

			var filename = "public/assets/export/composerXMLExport.xml";
			fs.writeFile(filename, xmlData, function(err) {
				if (err) throw err;
				res.json({status:"success"});
			});
		}	
    }).catch(function(err){
    	res.json({status:"fail"});
    });
};


/**
    * Generic require login routing middleware
*//*
exports.requiresLogin = function(req, res, next) {
    if (!req.isAuthenticated()) {
        return res.send(401, 'User is not authorized');
    }
    next();
};
*/
/**
    * User authorizations routing middleware
*//*
exports.hasAuthorization = function(req, res, next) {
    if (req.profile.id != req.user.id) {
      return res.send(401, 'User is not authorized');
    }
    next();
};
*/