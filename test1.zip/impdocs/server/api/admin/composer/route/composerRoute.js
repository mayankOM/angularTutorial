'use strict';

var adminComposer = require('../controller/composerController');

module.exports = function(app) {

	app.post('/api/admin/addComposer', adminComposer.create);
	app.get('/api/admin/listComposers', adminComposer.list);
	app.post('/api/admin/getExportData', adminComposer.getExportData);
	app.post('/api/admin/getComposer', adminComposer.getById);
	app.post('/api/admin/updatecomposer', adminComposer.update);
	app.post('/api/admin/deleteComposer', adminComposer.delete);
};