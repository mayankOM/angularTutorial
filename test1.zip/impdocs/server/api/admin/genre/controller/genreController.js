'use strict';

var db = require('../../../../config/sequelize');

/**
** create Genre/Library
**/
exports.create = function(req, res) {
   
	if(req.body != "") {
		req.checkBody('title', 'title required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		var message = null;
		console.log(req.body);
	    var libraries = db.Libraries.build(req.body);
	    libraries.save().then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		res.json({status:mappedErrors});	
	}   
};


/**
** List Genre/Library
**/
exports.list = function(req, res, next) {

	 db.Libraries.findAll({order: 'id DESC'}).then(function(libraries){
        if (!libraries) 
            return next(new Error('Failed to load Genre ' + id));
        
        res.json(libraries);
    }).catch(function(err){
    	console.log(err);
    	res.json({status:"fail"});
    });
};


/**
** get single Genre/Library
**/
exports.getById = function(req, res, next) {
    
    db.Libraries.find({where : { id : req.body.id }}).then(function(libraries){
        if (!libraries) 
            return next(new Error('Failed to load Composer ' + id));
        res.json(libraries);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    * Update Genre/Library
*/
exports.update = function(req, res) {
	if(req.body != "") {		
		req.checkBody('title', 'Title required').notEmpty();
		
		var mappedErrors = req.validationErrors(true);
	}	
	if(mappedErrors == false) {
		var message = null;
	    
		var obj = {
			'title'		: 	req.body.title,
		};	

	  	db.Libraries.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else {
		res.json({status:mappedErrors});	
	}   
};

/**
** delete Genre/Library
**/
exports.delete = function(req, res) {

    db.Libraries.destroy({ where : { id : req.body.id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

