'use strict';

var adminGenre = require('../controller/genreController');

module.exports = function(app) {

	app.post('/api/admin/addGenre', adminGenre.create);

	app.get('/api/admin/listGenres', adminGenre.list);
	
	app.post('/api/admin/getGenre', adminGenre.getById);
	app.post('/api/admin/updategenre', adminGenre.update);
	app.post('/api/admin/deleteGenre', adminGenre.delete);

};