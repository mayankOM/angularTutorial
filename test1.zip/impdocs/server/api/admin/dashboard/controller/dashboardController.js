'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');

/**
    Module : Dashboard
    Author : Mayank [SOFTWEB]
    Input  : 
    Output : List of subscribed user with count
    Date   : 2016-01-16
**/
exports.subscribedUserList = function(req, res, next) {

    db.User.findAndCountAll({
    	attributes : ['id','firstname','lastname','email','isAdmin','isPaid','userStatus','createdAt'],
    	include: [
            { model : db.Subscription, attributes : ['userID','planID','profileStatus','startAt','endAt']},
        ],
        where: { isPaid : true  },
        order: 'id DESC',
    }).then(function(user){
        if (!user) 
            return next(new Error('Failed to load User ' + id));
        res.json({'userCount' : user.count, 'userList' : user.rows });
        //next();
    }).catch(function(err){
    	res.json({status:"fail"});
        //next(err);
    });
};

/**
    Module : Dashboard
    Author : Mayank [SOFTWEB]
    Input  : 
    Output : List of Free user with count
    Date   : 2016-01-16
**/
exports.freeUserList = function(req, res, next) {

    db.User.findAndCountAll({
    	attributes : ['id','firstname','lastname','email','isAdmin','isPaid','userStatus','createdAt'],
    	include: [
            { model : db.Subscription, attributes : ['userID','planID','profileStatus','startAt','endAt']},
        ],
        where: { isPaid : false  },
        order: 'id DESC',
    }).then(function(user){
        if (!user) 
            return next(new Error('Failed to load User ' + id));
        res.json({'userCount' : user.count, 'userList' : user.rows });
        //next();
    }).catch(function(err){
    	res.json({status:"fail"});
        //next(err);
    });
};


/**
    Module : Dashboard
    Author : Mayank [SOFTWEB]
    Input  : 
    Output : Get a Subscribed user's detail
    Date   : 2016-01-16
**/
exports.getSubscribedAmt = function(req, res, next) {
	db.SubscriptionLogs.findAll({
    	attributes : ['id','userID','price','createdAt'],
    	/*include: [
            { model : db.Subscription, attributes : ['userID','planID','profileStatus','startAt','endAt']},
        ],*/
        where: { ack : 'Success'  },
        order: 'id DESC',
    }).then(function(subscribedUsersLog){
        if (!subscribedUsersLog) 
            return next(new Error('Failed to load User ' + subscribedUsersLog.id));
        res.json(subscribedUsersLog);
        //next();
    }).catch(function(err){
    	res.json({status:"fail"});
        //next(err);
    });
};

/**
    Module : Dashboard
    Author : Mayank [SOFTWEB]
    Input  : 
    Output : List of subscribed (Current Year) user
    Date   : 2016-01-16
**/
exports.currentYearSubscribedUserList = function(req, res, next) {

    db.User.findAll({
    	attributes : ['id','firstname','lastname','isPaid','userStatus'],
    	include: [
            { model : db.Subscription, attributes : ['userID','planID','profileStatus','startAt','endAt']},
            { model : db.SubscriptionLogs, attributes : ['userID','ack','price','createdAt']},
        ],
        where: { isPaid : true },
        order: 'id DESC',
    }).then(function(user){
        if (!user) 
            return next(new Error('Failed to load User ' + id));
        res.json(user);
        //next();
    }).catch(function(err){
    	res.json({status:"fail"});
        //next(err);
    });
};

/**
    Module : Dashboard
    Author : Mayank [SOFTWEB]
    Input  : 
    Output : List of subscribed (Current Year) user
    Date   : 2016-01-21
**/
exports.listUsers = function(req, res, next) {
    db.User.findAll({
        attributes : ['country',[db.sequelize.fn('COUNT', db.sequelize.col('`User`.`id`')), 'countryCount']],
        group: ['country'],
        where: {country : { $ne : ''}}
    }).then(function(user){
        if (!user) 
            return next(new Error('Failed to load User ' + id));
        res.json(user);
        //next();
    }).catch(function(err){
        res.json({status:"fail"});
        //next(err);
    });
};