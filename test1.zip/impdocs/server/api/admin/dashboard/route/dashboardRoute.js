'use strict';

var adminDashboard = require('../controller/dashboardController');

module.exports = function(app) {
	app.get('/api/admin/dashboard/listSubscribedUser', adminDashboard.subscribedUserList);
	app.get('/api/admin/dashboard/listFreeUser', adminDashboard.freeUserList);
	app.get('/api/admin/dashboard/getSubscribedAmt', adminDashboard.getSubscribedAmt);
	app.get('/api/admin/dashboard/currentYearSubscribedUserList', adminDashboard.currentYearSubscribedUserList);
	app.get('/api/admin/dashboard/listUsers', adminDashboard.listUsers);
};