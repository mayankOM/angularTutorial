'use strict';

var adminUser = require('../controller/userController');

module.exports = function(app) {
	app.post('/api/admin/user/adduser', adminUser.create);
	app.post('/api/admin/user/uniqueEmail', adminUser.uniqueEmail);
	app.post('/api/admin/user/uniqueEmailEdit', adminUser.uniqueEmailEdit);
	
	app.post('/api/admin/user/listuser', adminUser.list);
	
	app.post('/api/admin/user/getuser', adminUser.getById);
	app.post('/api/admin/user/updateuser', adminUser.update);
	app.post('/api/admin/user/updateProfile', adminUser.updateProfile);
	app.post('/api/admin/user/deluser', adminUser.delete);
};