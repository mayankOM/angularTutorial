'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');
var multiparty = require('multiparty');
var fs = require('fs-extra');

/**
    * Create user
*/
exports.create = function(req, res) {
    
	if(req.body != "")
	{
		req.checkBody('email', 'Email required').notEmpty();
		req.checkBody('email', 'Valid email required').isEmail();
		req.checkBody('firstname', 'Firstname required').notEmpty();
		req.checkBody('lastname', 'Lastname required').notEmpty();
		req.checkBody('contact', 'Contact required').notEmpty();
		//req.checkBody('contact', 'Contact required').isNumeric();
		req.checkBody('isAdmin', 'User type required').notEmpty();
		req.checkBody('gender', 'Gender required').notEmpty();
		req.checkBody('birthday', 'Birthdate required').notEmpty();
		req.checkBody('answer', 'Anser required').notEmpty();
		req.checkBody('password', 'Password required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false)
	{
		var message = null;
		req.body.isPaid = 0;
	    var user = db.User.build(req.body);

	    //START Default subscription end date set (Free user)
	    var CurrentDate = new Date();
	    var curDate = new Date();
		var end_date = CurrentDate.setDate(CurrentDate.getDate() + generalConfig.defaultFreeSubscriptionPeriod);

		var dateTime = new Date(end_date);
		var end_dateTime = dateTime.toISOString(); 
	    //END Default subscription end date set (Free user)

	    var emailContainer = generalConfig.emailTemplate;

		var	dataString = "<p>Hello "+req.body.firstname+",</p>";
			dataString += "<p>Thank you for signing up with Om!</p>";
			dataString += "<p>If you’d like to log in, make changes to your profile, or just start practicing, please click here : <a href='"+generalConfig.impconfig.websiteURL+"'>Om</a></p>";
		var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;

		// EMail content
	    var message = {
		   from			: generalConfig.impconfig.noRplyEmail,  //Like : Om music, LLC <no-reply@accompanymusic.com> 
		   to 			: req.body.email,
		   subject 		: emailContainer.signUpEmailSubject,
		   attachment 	: [
		       { data:emailContainerString, alternative:true },
		   ]
		};



	    //user.provider = 'local';
	    user.salt = user.makeSalt();
	    user.hashedPassword = user.encryptPassword(req.body.password, user.salt);
	    user.save().then(function(data){

	    	//Save Free subscription for new user
	    	var subscriptionObj = {
				'userID'		 : 	data.id,
				'startAt'		 : 	curDate,
				'endAt'		     : 	end_dateTime
			};
			var subscription = db.Subscription.build(subscriptionObj);
    		subscription.save().then(function(){ });
	    
	    	// Send Email    
    	    generalConfig.getServer.send(message, function(err, message) { console.log(err || message); });

	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else
	{
		res.json({status:mappedErrors});	
	}   
};

/**
    * Update user
*/
exports.update = function(req, res) {

	console.log("here in subscription edit");

	if(req.body != "") {
		req.checkBody('email', 'Email required').notEmpty();
		req.checkBody('email', 'Valid email required').isEmail();
		req.checkBody('firstname', 'Firstname required').notEmpty();
		req.checkBody('lastname', 'Lastname required').notEmpty();
		req.checkBody('contact', 'Contact required').notEmpty();
		req.checkBody('isAdmin', 'User type required').notEmpty();
		req.checkBody('gender', 'Gender required').notEmpty();
		req.checkBody('birthday', 'Birthdate required').notEmpty();
		req.checkBody('answer', 'Anser required').notEmpty();
		req.checkBody('questionId', 'Secret Question required').notEmpty();

		if(req.body.change_pw == 1) {
			req.checkBody('password', 'Password required').notEmpty();
		}	
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		
		var message = null;
	    var user = db.User.build(req.body);
	    
	    if(req.body.change_pw == 1) {
			
			var salt = user.makeSalt();
			var hashedPassword = user.encryptPassword(req.body.password, salt);

			var obj = {
				'firstname'		: 	req.body.firstname,
				'lastname'		: 	req.body.lastname,
				'email'			: 	req.body.email,
				'contact'		: 	req.body.contact,
				'isAdmin'		: 	req.body.isAdmin,
				'gender'		: 	req.body.gender,
				'birthday'		: 	req.body.birthday,
				'questionId'	: 	req.body.questionId,
				'answer'		: 	req.body.answer,
				'userStatus'	: 	req.body.userStatus,
				'hashedPassword': 	hashedPassword,
				'salt'			: 	salt
			};
		
		} else {
			
			var obj = {
				'firstname'		: 	req.body.firstname,
				'lastname'		: 	req.body.lastname,
				'email'			: 	req.body.email,
				'contact'		: 	req.body.contact,
				'isAdmin'		: 	req.body.isAdmin,
				'gender'		: 	req.body.gender,
				'birthday'		: 	req.body.birthday,
				'questionId'	: 	req.body.questionId,
				'answer'		: 	req.body.answer,
				'userStatus'	: 	req.body.userStatus
			};	
		}	

	  	db.User.update(obj,{ where : { id : req.body.id }}).then(function(){
	        
	  		if(obj.isAdmin === false){
	  			
	  			var subsObj = {
	  				'startAt' : req.body.startAt,
	  				'endAt' : req.body.endAt
	  			};
	  			db.Subscription.update(subsObj, { where : { userID : req.body.id }}).then(function(){
	  				res.json({status:"success"});
	  			}).catch(function(err){
	        		res.json({status:"fail"});
	    		});
	  			
	  		} else {
	        	res.json({status:"success"});
	  		}

	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		res.json({status:mappedErrors});	
	}   
};

/**
    * Update user
*/
exports.updateProfile = function(req, res) {

	console.log("--Hello update---");

	if(req.body != "")
	{
		req.checkBody('email', 'Email required').notEmpty();
		req.checkBody('email', 'Valid email required').isEmail();
		req.checkBody('firstname', 'Firstname required').notEmpty();
		req.checkBody('lastname', 'Lastname required').notEmpty();
		req.checkBody('contact', 'Contact required').notEmpty();
		req.checkBody('gender', 'Gender required').notEmpty();
		req.checkBody('birthday', 'Birthdate required').notEmpty();
		req.checkBody('answer', 'Anser required').notEmpty();
		req.checkBody('questionId', 'Secret Question required').notEmpty();
		if(req.body.change_pw == 1)
		{
			req.checkBody('password', 'Password required').notEmpty();
		}	
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false)
	{
		var message = null;
	    var user = db.User.build(req.body);
	    if(req.body.change_pw == 1)
		{
			var salt = user.makeSalt();
			var hashedPassword = user.encryptPassword(req.body.password, salt);

			var obj = {
				'firstname'		: 	req.body.firstname,
				'lastname'		: 	req.body.lastname,
				'email'			: 	req.body.email,
				'contact'		: 	req.body.contact,
				'gender'		: 	req.body.gender,
				'birthday'		: 	req.body.birthday,
				'questionId'	: 	req.body.questionId,
				'answer'		: 	req.body.answer,
				'hashedPassword': 	hashedPassword,
				'salt'			: 	salt
			};
		}	
		else
		{
			var obj = {
				'firstname'		: 	req.body.firstname,
				'lastname'		: 	req.body.lastname,
				'email'			: 	req.body.email,
				'contact'		: 	req.body.contact,
				'gender'		: 	req.body.gender,
				'birthday'		: 	req.body.birthday,
				'questionId'	: 	req.body.questionId,
				'answer'		: 	req.body.answer
			};	
		}	

	  	db.User.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else
	{
		res.json({status:mappedErrors});	
	}   
};



/**
    * Send User
*/
exports.delete = function(req, res) {
    db.User.destroy({ where : { id : req.body.user_id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    * Send User
*/
exports.me = function(req, res) {
    res.jsonp(req.user || null);
};


/**
    * Find all user
*/
exports.list = function(req, res, next) {
    
    db.User.findAll({
    	
    	attributes : ['id','firstname','lastname','email','isAdmin','isPaid','userStatus','createdAt'],
    	include: [
            { model : db.Subscription, attributes : ['userID','planID','profileStatus','startAt','endAt']},
        ],
        
        where: { isAdmin : req.body.curPath == 'admin' ? true : false  },
        order: 'id DESC',
    
    }).then(function(user){
        
        if (!user) 
            return next(new Error('Failed to load User ' + id));
        
        req.profile = user;
        res.json(user);
    
    }).catch(function(err){
    	res.json({status:"fail"});
    });

};

/**
    * Find user by id
*/
exports.getById = function(req, res, next) {

	console.log("here Here here here here")
	var id = req.body.user_id;
    db.User.find({
		
		attributes : ['id','email','firstname','lastname','birthday','contact','gender','profilePicture','isAdmin','userStatus','questionId','answer','isPaid'],
    	include: [
            { model : db.Subscription, attributes : ['userID','planID','profileStatus','startAt','endAt']},
        ],
    	where : { id: id }
    
    }).then(function(user){
    	
    	if (!user) 
            return next(new Error('Failed to load User ' + id));
        req.profile = user;
        res.json(user);
        
    }).catch(function(err){
    	res.json({status:err});
    });
};

/**
    * Generic require login routing middleware
*/
exports.requiresLogin = function(req, res, next) {
    if (!req.isAuthenticated()) {
        return res.send(401, 'User is not authorized');
    }
    next();
};

/**
    * User authorizations routing middleware
*/
exports.hasAuthorization = function(req, res, next) {
    if (req.profile.id != req.user.id) {
      return res.send(401, 'User is not authorized');
    }
    next();
};

exports.uniqueEmail = function (req, res, next) {

	console.log(req.body.email);	

	db.User.find({where : { email: req.body.email }}).then(function(user){
		if(!user)
		{
			res.json({exists:"false"});
		}	
		else
		{
			res.json({exists:"true"});
		}	
        //next();
    }).catch(function(err){
    	res.json({exists:err});
        //next(err);
    });
};

exports.uniqueEmailEdit = function (req, res, next) {
	
	var current_user_id = req.body.user_id;
	
	db.User.find({
		where : { 
			email: req.body.email, id: { $ne: current_user_id },
			isAdmin: req.body.isAdmin
		}
	}).then(function(user){
		
		if(!user) {
			res.json({exists:"false"});
		} else {
			res.json({exists:"true"});
		}	
    
    }).catch(function(err){
    	res.json({exists:err});
    });
};

