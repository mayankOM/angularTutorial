'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');

//new Plan
exports.create = function(req, res) {

	if(req.body != "") {
		req.checkBody('name', 'Title required').notEmpty();
		req.checkBody('price', 'Price required').notEmpty();
		req.checkBody('price', 'Invalid Price').isFloat();
		req.checkBody('description', 'English description required').notEmpty();
		req.checkBody('descriptionFR', 'French description required').notEmpty();
		req.checkBody('descriptionES', 'Spanish description required').notEmpty();
		req.checkBody('descriptionTW', 'Taiwan description required').notEmpty();
		req.checkBody('descriptionCH', 'Chinese description required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		
	    var plan = db.Plans.build(req.body);
	    plan.save().then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		res.json({status:mappedErrors});	
	}   
};

exports.list = function(req, res, next) {

	db.Plans.findAll({order: 'id DESC'}).then(function(plan){
        if (!plan) 
            return next(new Error('Failed to load plan ' + id));
        res.json(plan);
    }).catch(function(err){
    	console.log(err);
    	res.json({status:"fail"});
    });
};

exports.getById = function(req, res, next) {
    
    db.Plans.find({where : { id : req.body.id }}).then(function(plan){
        if (!plan) 
            return next(new Error('Failed to load Composer ' + id));
        res.json(plan);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
* Update Subscription Plan
*/
exports.update = function(req, res) {

	console.log(req.body);

	if(req.body != "")
	{
		req.checkBody('name', 'Title required').notEmpty();
		req.checkBody('price', 'Price required').notEmpty();
		req.checkBody('description', 'English description required').notEmpty();
		req.checkBody('descriptionFR', 'French description required').notEmpty();
		req.checkBody('descriptionES', 'Spanish description required').notEmpty();
		req.checkBody('descriptionTW', 'Taiwan description required').notEmpty();
		req.checkBody('descriptionCH', 'Chinese description required').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	if(mappedErrors == false)
	{
		var obj = {
			'name'	: 	req.body.name,
			'price'	: 	req.body.price,
			'description'	: 	req.body.description,
			'descriptionFR'	: 	req.body.descriptionFR,
			'descriptionES'	: 	req.body.descriptionES,
			'descriptionTW'	: 	req.body.descriptionTW,
			'descriptionCH'	: 	req.body.descriptionCH,
		};
		db.Plans.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else
	{
		res.json({status:mappedErrors});	
	}   
};

/**
* Send Plan
*/
exports.delete = function(req, res) {

    db.Plans.destroy({ where : { id : req.body.id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    Module : Subscription Reminder
    Author : Mayank [SOFTWEB]
    Input  : 
    Output : Alert email send to user
    Date   : 2016-01-22
**/
/*exports.subscriptionReminder = function(req, res, next) {

	var d = new Date();
	var next = d.setDate(d.getDate() + generalConfig.subscriptionReminderBeforeDays)
	
    db.Subscription.findAll({
        attributes : ['id','userID', 'profileStatus', 'startAt', 'endAt', 'planID'],
        where: {
        	profileStatus : { $eq : 'ActiveProfile'},
        	endAt: {
				$lt: new Date(next)
			}
        },
        include: [
            { model : db.User, attributes : ['id','firstname','lastname','email','isPaid','userStatus']},
            { model : db.Plans, attributes : ['id','name','price']},
        ]
    }).then(function(data){
        if (!data) 
            return next(new Error('Failed to load User ' + data));

		for(var i = 0; i < data.length;i++){

			var subId = data[i].dataValues.id;
			var userName = data[i].dataValues.User.dataValues.firstname;
			var userEmail = data[i].dataValues.User.dataValues.email;
			var planName = data[i].dataValues.Plan.dataValues.name;
			var planRate = data[i].dataValues.Plan.dataValues.price;
			var planDuration = (data[i].dataValues.planID == 1) ? '6 month' : '12 month';
			var planExpDate = data[i].dataValues.endAt;

			var expDateMonth = planExpDate.getMonth()+1; 
			expDateMonth = (expDateMonth < 10) ? '0'+expDateMonth : expDateMonth; 
			
			var expDateDay = (planExpDate.getDate() < 10) ? '0'+planExpDate.getDate() : planExpDate.getDate(); 
			var expDateYear = planExpDate.getFullYear(); 
			
			var planExpDate = expDateYear+'-'+expDateMonth +'-'+expDateDay;
			var emailContainer = generalConfig.emailTemplate;

			


			var	dataString = "<p>Dear "+userName+",</p>";
				dataString += "<p>Your current "+planDuration+" subscription to Om is set to auto-renew on "+planExpDate+". If you would like to continue using Om, no action is needed on your part; we’ll take care of it for you automatically.</p>";
				dataString += "<p>If for any reason you need to cancel your subscription, please log in and click here to update your settings: <a href='"+generalConfig.impconfig.websiteURL+"subscriptionsLog'>Om</a></p>";
				dataString += "<p>Thank you again for using Om and we hope you’ll continue to enjoy it in the future. We are constantly working on new repertoire and features. Stay tuned!</p>";

			var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;

			var message = {
			   from:    generalConfig.impconfig.organizationName+" "+generalConfig.impconfig.noRplyEmail,  //Like : Om music, LLC <no-reply@accompanymusic.com>
			   to:      userEmail,
			   cc:      "Mk <ajay.khunti@gmail1.com.com>",
			   subject: emailContainer.subscriptionReminderEmailSubject,
			   attachment: 
			   [
			      {data:emailContainerString, alternative:true},
			   ]
			};

			setTimeout(function () {
		        generalConfig.getServer.send(message, function(err, message) { console.log(err || message); });
		    }, 1000);

		}
        res.json(data);



        //next();
    }).catch(function(err){
        res.json({status:"fail"});
        //next(err);
    });
};*/