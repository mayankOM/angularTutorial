'use strict';

var adminSubscriptionPlan = require('../controller/subscriptionPlanController');

module.exports = function(app) {

	app.post('/api/admin/addSubscriptionPlan', adminSubscriptionPlan.create);
	app.get('/api/admin/listSubscriptionPlan', adminSubscriptionPlan.list);
	app.post('/api/admin/getSubscriptionPlan', adminSubscriptionPlan.getById);
	app.post('/api/admin/updatesubscriptionplan', adminSubscriptionPlan.update);
	app.post('/api/admin/deletesubscriptionplan', adminSubscriptionPlan.delete);
	//app.post('/api/admin/subscriptionReminder', adminSubscriptionPlan.subscriptionReminder);
	
};