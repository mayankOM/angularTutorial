'use strict';

var adminArticle = require('../controller/articleController');

module.exports = function(app) {

	app.post('/api/admin/addArticle', adminArticle.create);

	app.get('/api/admin/listArticles', adminArticle.list);
	
	app.post('/api/admin/getArticle', adminArticle.getById);
	app.post('/api/admin/updatearticle', adminArticle.update);
	app.post('/api/admin/deleteArticle', adminArticle.delete);
	


	

};