'use strict';

var db = require('../../../../config/sequelize');


//new code

exports.create = function(req, res) {
    
	if(req.body != "") {
		req.checkBody('titleEN', 'Title required for English language').notEmpty();
		req.checkBody('titleFR', 'Title required for French language').notEmpty();
		req.checkBody('titleES', 'Title required for Spanish language').notEmpty();
		req.checkBody('titleTW', 'Title required for Taiwan language').notEmpty();
		req.checkBody('titleCH', 'Title required for Chinese language').notEmpty();
		req.checkBody('contentEN', 'Content required for English language').notEmpty();
		req.checkBody('contentFR', 'Content required for French language').notEmpty();
		req.checkBody('contentES', 'Content required for Spanish language').notEmpty();
		req.checkBody('contentTW', 'Content required for Taiwan language').notEmpty();
		req.checkBody('contentCH', 'Content required for Chinese language').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	
	if(mappedErrors == false) {
		var message = null;
		console.log(req.body);
	    var article = db.Article.build(req.body);
	    article.save().then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	
	} else {
		res.json({status:mappedErrors});	
	}   
};


exports.list = function(req, res, next) {

	 db.Article.findAll({order: 'id DESC'}).then(function(article){
        if (!article) 
            return next(new Error('Failed to load article ' + id));
        
        res.json(article);
    }).catch(function(err){
    	console.log(err);
    	res.json({status:"fail"});
    });
};


exports.getById = function(req, res, next) {
    
    db.Article.find({where : { id : req.body.id }}).then(function(article){
        if (!article) 
            return next(new Error('Failed to load Composer ' + id));
        res.json(article);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};



/**
    * Update user
*/
exports.update = function(req, res) {

	console.log(req.body);

	if(req.body != "")
	{
		req.checkBody('titleEN', 'Title required for English language').notEmpty();
		req.checkBody('titleFR', 'Title required for French language').notEmpty();
		req.checkBody('titleES', 'Title required for Spanish language').notEmpty();
		req.checkBody('titleTW', 'Title required for Taiwan language').notEmpty();
		req.checkBody('titleCH', 'Title required for Chinese language').notEmpty();
		req.checkBody('contentEN', 'Content required for English language').notEmpty();
		req.checkBody('contentFR', 'Content required for French language').notEmpty();
		req.checkBody('contentES', 'Content required for Spanish language').notEmpty();
		req.checkBody('contentTW', 'Content required for Taiwan language').notEmpty();
		req.checkBody('contentCH', 'Content required for Chinese language').notEmpty();
		var mappedErrors = req.validationErrors(true);
	}	
	if(mappedErrors == false)
	{
		var message = null;

			var obj = {
				'titleEN'	: 	req.body.titleEN,
				'contentEN'	: 	req.body.contentEN,
				'titleFR'	: 	req.body.titleFR,
				'contentFR'	: 	req.body.contentFR,
				'titleES'	: 	req.body.titleES,
				'contentES'	: 	req.body.contentES,
				'titleTW'	: 	req.body.titleTW,
				'contentTW'	: 	req.body.contentTW,
				'titleCH'	: 	req.body.titleCH,
				'contentCH'	: 	req.body.contentCH,
			};	

	  	db.Article.update(obj,{ where : { id : req.body.id }}).then(function(){
	        res.json({status:"success"});
	    }).catch(function(err){
	        res.json({status:"fail"});
	    });
	}
	else
	{
		res.json({status:mappedErrors});	
	}   
};



/**
    * Send User
*/
exports.delete = function(req, res) {

	//console.log(req.body); return false;
    db.Article.destroy({ where : { id : req.body.id }}).then(function(){
        res.json({status:"success"});
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

