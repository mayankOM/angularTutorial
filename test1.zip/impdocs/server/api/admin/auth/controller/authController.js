'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');
var passport = require('passport');
var jwt = require('jsonwebtoken');

/**
    * Find user by id
*/
/*exports.getToken = function(req, res, next) {

	console.log('Welcome here');
	
	var token = jwt.sign({ foo: 'bar' }, 'shhhhh');
	console.log("----Get a token----");
	console.log(token);
	console.log("----Get a token end----");
	if(token)
	{
		res.json({status:'success','token':token});
	}
	else
	{
		res.json({status:'fail','token':null});
	}	
	
};


exports.checkToken = function(req, res, next) {

	//console.log('Welcome check token here');
	if(req.body.token)
	{
		var token = req.body.token;
		
		jwt.verify(token, 'shhhhh', function(err, decoded) {
			if(err)
			{
				console.log(err.message);
				res.json({status:'fail','data':null, 'message':err.message});
			}
			else
		  	{
		  		res.json({status:'success','data':decoded, 'message':'Token matched'});
		  	}	
		});
	}
	else{
		res.json({status:'fail','data':null, 'message':'Token not found'});
	}	
};*/


exports.signin = function(req, res, next) {

	//console.log(req.body);
	passport.authenticate('local', function(err, user, info) {
		if(!user) {
			
			if(err) {
				
				console.log("----Out and failed to session----"+err);
				res.json({status:err});	
			
			} else {
				
				console.log("----Out and failed to session ----"+info);
				res.json({status:'fail'});	
			}	
		} else {
			
			console.log("============== In success and set session =================");
			var curUserID = user.id;
            var curUserID = encrypt(curUserID.toString());
			req.session.admin = user;


			res.json({id : curUserID});	
		
		}	
	})(req, res, next);
};

exports.signout = function (req, res) {
	console.log("---------- Session Destroy admin -----------");
	delete req.session.admin;
	res.json({status:"success"});
	/*req.session.destroy(function(err) {
		console.log("---------- Session Destroy admin -----------");
		res.json({status:"success"});
	})*/
};
	
exports.getSession = function(req, res){
	console.log("---------- Get Session data-----------");
	if(req.session.admin) {
		//console.log(req.session.user);
		res.json(req.session.admin);
	} else {
		console.log("No User Found");
		res.json({status:'fail'});
	}
};

/**
    * Find user by id
*/
exports.getById = function(req, res, next) {

	console.log('Welcome here');
	console.log(req.body);

	var decryptedUserID = decrypt(req.body.user_id);
	var id = parseInt(decryptedUserID);

    db.User.find({
    	attributes : ['id','email','firstname','lastname','birthday','contact','gender','profilePicture','isAdmin','userStatus','questionId','answer'],
    	where : { id: id }
    }).then(function(user){
    	if (!user) 
            return next(new Error('Failed to load User ' + id));
        req.profile = user;
        res.json(user);
        //next();
    }).catch(function(err){
    	res.json({status:err});
        //next(err);
    });
};

/*
	Module : Login Cookie Encryption
	Author : Mayank [SOFTWEB]
	Inputs : PLain format of Email, Password
	Output : Encrypt inputed Email and Password
	Date   : 2015-12-10
*/
exports.encryptCookies = function(req, res){
	var encryptedPassword = encrypt(req.body.rememberPass);
	var encryptedEmail = encrypt(req.body.rememberEmail);
	res.json({encEmail : encryptedEmail , encPass : encryptedPassword});
};

/*
	Module : Login Cookie Decryption
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted format of Email, Password
	Output : Decrypt posted Email and Password
	Date   : 2015-12-10
*/
exports.decryptCookies = function(req, res){

	console.log(req.body);

	var decryptedEmail = decrypt(req.body.cookieEmailAdmin);
	var decryptedPassword = decrypt(req.body.cookiePasswordAdmin);
	res.json({decEmail : decryptedEmail , decPass : decryptedPassword});
};


/*
	Module : Encryption function
	Author : Mayank [SOFTWEB]
	Inputs : text
	Output : Encrypt text
	Date   : 2015-12-03
*/
function encrypt(text){
  	var cipher = generalConfig.cryptoAuthentication.crypto.createCipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  	var crypted = cipher.update(text,'utf8','hex');
  	crypted += cipher.final('hex');
  	return crypted;
}

/*
	Module : Decryption function
	Author : Mayank [SOFTWEB]
	Inputs : Encrypted text
	Output : Simple text
	Date   : 2015-12-03
*/ 
function decrypt(text){
  	var decipher = generalConfig.cryptoAuthentication.crypto.createDecipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  	var dec = decipher.update(text,'hex','utf8');
  	dec += decipher.final('utf8');
  	return dec;
}
/*
Subject : Declining a job offer:

Dear Mam, 

Thank you very much for offering me the Sr. Software Engineer designation. 
After careful consideration, I regret that i must decline your offer. 

I have accepted opportunity that is more in line with my skills and career goals with same organization offered.

I enjoyed meeting you and the rest of your team. You have been most kind and gracious throughout the interview process.

Best wishes for your continued success.

Regards,
Mayank Patel
*/