'use strict';

var adminAuth = require('../controller/authController');
//var generalConfig = require('../../../../config/interceptor');


module.exports = function(app) {
	
	app.post('/api/admin/auth/signin', adminAuth.signin);
	/*app.post('/api/admin/auth/getToken', adminAuth.getToken);
	app.post('/api/admin/auth/checkToken', adminAuth.checkToken);*/
    app.get('/api/admin/auth/signout', adminAuth.signout);
    app.get('/api/admin/auth/getSession', adminAuth.getSession);
    app.post('/api/admin/auth/getuser', adminAuth.getById);
    app.post('/api/admin/auth/enc', adminAuth.encryptCookies);
	app.post('/api/admin/auth/dec', adminAuth.decryptCookies);
	//app.post("/api/v1/client", someFucntion, Client.create);
	/*app.post('/api/admin/auth/getToken', generalConfig.someFucntion, adminAuth.getToken);
	app.post('/api/admin/auth/checkToken', generalConfig.someFucntion, adminAuth.checkToken);*/
};