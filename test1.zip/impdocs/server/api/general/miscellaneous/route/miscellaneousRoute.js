'use strict';

var allInOne = require('../controller/miscellaneousController');
var multipart = require('connect-multiparty');
var multipartMiddleware = multipart();

module.exports = function(app) {
	
	app.get('/api/general/getComposerList', allInOne.getComposerList);
	
	app.post('/api/general/getInstrumentList', allInOne.getInstrumentList);
	app.post('/api/general/getLibraryList', allInOne.getLibraryList);
	
	app.get('/api/general/getPianoTypeList', allInOne.getPianoTypeList);
	app.get('/api/general/getTempoList', allInOne.getTempoList);
	app.get('/api/general/getKeyList', allInOne.getKeyList);
	app.get('/api/general/getTuningList', allInOne.getTuningList);
	app.get('/api/general/listsecretquestions', allInOne.getSecretQuestions);
	app.post('/api/general/imageUpload', multipartMiddleware, allInOne.imageUpload);


	app.get('/api/general/abc', allInOne.abc);

};