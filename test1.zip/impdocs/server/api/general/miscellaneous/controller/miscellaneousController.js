'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');
var multiparty = require('multiparty');
var fs = require('fs-extra');

/*
	* Composer List for Drop Down
	*
*/
exports.getComposerList = function(req, res, next) {
    
    db.Composer.findAll( { attributes : ['id','firstName','lastName'], order: '`lastName`' } ).then(function(composers){
        if (!composers) 
            return next(new Error('Failed to load Composers'));
        res.json(composers);
    }).catch(function(err){
    	res.json({status:"fail"});
    });

};


/*
	* Instrument List for Check Boxes
	*
*/
exports.getInstrumentList = function(req, res, next) {

    db.Instruments.findAll( { attributes : ['id','title'], order: '`title`' } ).then(function(instruments){
        if (!instruments) 
            return next(new Error('Failed to load Instruments'));
        res.json(instruments);
    }).catch(function(err){
    	res.json({status:"fail"});
    });

};



/*
    * Library List for Check Boxes
    *
*/
exports.getLibraryList = function(req, res, next) {
    db.Libraries.findAll( { attributes : ['id','title'], order: '`title`' } ).then(function(libraries){
        if (!libraries) 
            return next(new Error('Failed to load Libraries'));
        res.json(libraries);
    }).catch(function(err){
        res.json({status:"fail"});
    });

};

/*
    * PianoTypes List for Check Boxes
    *
*/
exports.getPianoTypeList = function(req, res, next) {
    db.PianoTypes.findAll( { attributes : ['id','title'] } ).then(function(PianoTypes){
        if (!PianoTypes) 
            return next(new Error('Failed to load PianoTypes'));
        res.json(PianoTypes);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};


/*
    * Tempo List for Check Boxes
    *
*/
exports.getTempoList = function(req, res, next) {

    var tempoArray = [];

    tempoArray = [
        {'id'    : 0, 'tempo'  : 40},
        {'id'    : 1, 'tempo'  : 42},
        {'id'    : 2, 'tempo'  : 44},
        {'id'    : 3, 'tempo'  : 46},
        {'id'    : 4, 'tempo'  : 48},
        {'id'    : 5, 'tempo'  : 50},
        {'id'    : 6, 'tempo'  : 52},
        {'id'    : 7, 'tempo'  : 54},
        {'id'    : 8, 'tempo'  : 56},
        {'id'    : 9, 'tempo'  : 58},
        {'id'    : 10, 'tempo' : 60},
        {'id'    : 11, 'tempo' : 63},
        {'id'    : 12, 'tempo' : 66},
        {'id'    : 13, 'tempo' : 69},
        {'id'    : 14, 'tempo' : 72},
        {'id'    : 15, 'tempo' : 76},
        {'id'    : 16, 'tempo' : 80},
        {'id'    : 17, 'tempo' : 84},
        {'id'    : 18, 'tempo' : 88},
        {'id'    : 19, 'tempo' : 92},
        {'id'    : 20, 'tempo' : 96},
        {'id'    : 21, 'tempo' : 100},
        {'id'    : 22, 'tempo' : 104},
        {'id'    : 23, 'tempo' : 108},
        {'id'    : 24, 'tempo' : 112},
        {'id'    : 25, 'tempo' : 116},
        {'id'    : 26, 'tempo' : 120},
        {'id'    : 27, 'tempo' : 126},
        {'id'    : 28, 'tempo' : 132},
        {'id'    : 29, 'tempo' : 138},
        {'id'    : 30, 'tempo' : 144},
        {'id'    : 31, 'tempo' : 152},
        {'id'    : 32, 'tempo' : 160},
        {'id'    : 32, 'tempo' : 168},
        {'id'    : 33, 'tempo' : 176},
        {'id'    : 34, 'tempo' : 184},
        {'id'    : 35, 'tempo' : 192},
        {'id'    : 36, 'tempo' : 200},
        {'id'    : 37, 'tempo' : 208}    
    ];
    res.json(tempoArray);
};

/*
    * Key List for Check Boxes
    *
*/
exports.getKeyList = function(req, res, next) {
    db.Keys.findAll( { attributes : ['id','title'] } ).then(function(keys){
        if (!keys) 
            return next(new Error('Failed to load Keys'));
        res.json(keys);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/*
    * Tuning List for Check Boxes
    *
*/
exports.getTuningList = function(req, res, next) {
    db.Tunings.findAll( { attributes : ['id','tuning'] } ).then(function(Tunings){
        if (!Tunings) 
            return next(new Error('Failed to load Tunings'));
        res.json(Tunings);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};



/**
    * Get a list of secret Questions all user
*/
exports.getSecretQuestions = function(req, res, next) {

    db.SecretQuestion.findAll().then(function(list){
        if (!list) 
            return next(new Error('Failed to load Question list '));
        
        res.json(list);
    }).catch(function(err){
        res.json({status:"fail"});
    });
};

/**
    * Upload Profile Image
*/
exports.imageUpload = function(req, res) {

    var tstamp = Date.now();

    if(req.body.idType == 'normal') {
        var user_id = req.body.user_id;            
    } else {
        var decryptedUserID = decrypt(req.body.user_id);
        var user_id = parseInt(decryptedUserID);
    } 

    var file    = req.files.file;
    var tmpPath = file.path;
    
    //var extIndex = tmpPath.lastIndexOf('.');
    //var extension = (extIndex < 0) ? '' : tmpPath.substr(extIndex);
    
    var fileName = tstamp+'_'+file.name;
    var destPath = 'public/assets/Site/userprofile/'+fileName;

    if(user_id != "" && file.name != "") {
        
        var obj = {
            'profilePicture'    :   fileName
        };  

        var userData = "";

        //var id = req.body.user_id;
        var id = user_id;
        db.User.find({
            attributes : ['id','profilePicture'],
            where : { id: id }
        }).then(function(user) {
            
            if(user) {   
                db.User.update(obj,{ where : { id : user_id }}).then(function(){
                    

                    fs.copy(tmpPath, destPath, { replace: false }, function (err) {

                        if (err) {
                            res.json({status:"fail", msg : err});
                        } else {                
                            
                            if(user.profilePicture != "") {
                                fs.remove('public/assets/Site/userprofile/'+user.profilePicture);
                            }   
                            res.json({status:"succ", msg : "File upload done.", filename : fileName });
                        }
                    });
                }).catch(function(err){
                    res.json({status:"fail", msg : err });
                });
            
            } else {
                res.json({status:"fail", msg : "User not found" });
            }   
        }).catch(function(err){
            //next(err);
            res.json({status:"fail", msg : err });
        });
    }   
    else
    {
        res.json({status:"fail", msg : "Username or file name missing." });
    }   
};




exports.abc = function(req, res) {
    res.json({status:"sucess"});
};



/*
    Module : Encryption function
    Author : Mayank [SOFTWEB]
    Inputs : text
    Output : Encrypt text
    Date   : 2015-12-03
*/
function encrypt(text){
  var cipher = generalConfig.cryptoAuthentication.crypto.createCipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  var crypted = cipher.update(text,'utf8','hex');
  crypted += cipher.final('hex');
  return crypted;
}

/*
    Module : Decryption function
    Author : Mayank [SOFTWEB]
    Inputs : Encrypted text
    Output : Simple text
    Date   : 2015-12-03
*/ 
function decrypt(text){
  var decipher = generalConfig.cryptoAuthentication.crypto.createDecipher( generalConfig.cryptoAuthentication.algorithm, generalConfig.cryptoAuthentication.password);
  var dec = decipher.update(text,'hex','utf8');
  dec += decipher.final('utf8');
  return dec;
}