'use strict';

var db = require('../../../../config/sequelize');
var generalConfig = require('../../../../config/generalConfig');


//Cron Url to invite Old PianoAmigo user to new Om
//http://localhost:3003/cronTab/inviteOldUser

/*
	* Cron to invite user
	*
*/
exports.inviteOldUser = function(req, res, next) {
    
    
    db.User.findAll({ 
        attributes : ['id','firstname','lastname', 'email'],
        where  : { $and:{ isPassUpdateStatus : { $eq : false}, }},

    }).then(function(users){
        
        if (!users) 
            res.send({status:"There is some problem!!"});
        

        var length = users.length;
        var printNumber = 0;
        
        for (var index = 0; index < length; index++) {
            
            var user = users[index].dataValues;
            
            if(user.hasOwnProperty('email')) {

                var firstName   = user.firstname;
                var lastName    = user.lastname;
                //var toUser     = user.email;
                var toUser     = 'ajay.khunti@gmail1.com.com';

                var emailContainer = generalConfig.emailTemplate;
                
                var dataString = "<p>Dear "+firstName+",</p>";
                    dataString += "<p>Some time ago, you signed up for a subscription to PianoAmigo.com, which is now <a href='"+generalConfig.impconfig.websiteURL+"'>Ommusic.com</a>.</p>";
                    dataString += "<p>I have completely redone the app from scratch with new coding, a new interface, superior quality sound files and expanded repertoire.</p>";

                    dataString += "<p>I’d like to welcome you back – all you have to do is use your old PianoAmigo user name & password and your subscription will be extended accordingly.</p>";
                    dataString += "<p>(You will be asked to create a new password and then you’ll be all set.)</p>";
                    dataString += "<p>Thanks for your patience and support during our transition – the new app works much better, and unlike PA, it works on mobile devices too!</p>";
                    
                var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;


                var message = {
            
                    from        : generalConfig.impconfig.noRplyEmail, 
                    to          : toUser,
                    cc          : generalConfig.impconfig.tempAdminEmail,
                    subject     : emailContainer.invitationEmailSubject,
                    attachment  : [
                        { data  : emailContainerString,alternative:true },
                    ]
                
                }; 
                generalConfig.getServer.send(message, function(err, message) { 
                    if(err) {
                        console.log(parseInt(++printNumber)+") Failure => Id = "+user.id+", First Name = "+user.firstname+", Last Name = "+user.lastname);
                    } else {
                        console.log(parseInt(++printNumber)+") Success => Id = "+user.id+", First Name = "+user.firstname+", Last Name = "+user.lastname);
                    }
                });

            } else {
                console.log(parseInt(++printNumber)+") Failure => Id = "+user.id+", First Name = "+user.firstname+", Last Name = "+user.lastname);
            }
        }

        res.send({status:"Success"});

    }).catch(function(err){
        res.send({status:"fail"});
    });

};



//Cron Url to send subscription renewal reminder
//http://localhost:3003/cronTab/subscriptionReminder

/**
    Module : Subscription Reminder
    Author : Mayank [SOFTWEB]
    Input  : 
    Output : Alert email send to user
    Date   : 2016-01-22
**/
exports.subscriptionReminder = function(req, res, next) {

    var d = new Date();
    var next = d.setDate(d.getDate() + generalConfig.subscriptionReminderBeforeDays)
    
    db.Subscription.findAll({
        attributes : ['id','userID', 'profileStatus', 'startAt', 'endAt', 'planID'],
        where: {
            profileStatus : { $eq : 'ActiveProfile'},
            endAt: {
                $lt: new Date(next)
            }
        },
        include: [
            { model : db.User, attributes : ['id','firstname','lastname','email','isPaid','userStatus']},
            { model : db.Plans, attributes : ['id','name','price']},
        ]
    
    }).then(function(data){
        
        if (!data) 
            res.send({status:"There is no any user!!"});

        for(var i = 0; i < data.length;i++){

            var subId           = data[i].dataValues.id;
            var userName        = data[i].dataValues.User.dataValues.firstname;
            var userEmail       = data[i].dataValues.User.dataValues.email;
            var planName        = data[i].dataValues.Plan.dataValues.name;
            var planRate        = data[i].dataValues.Plan.dataValues.price;
            var planDuration    = (data[i].dataValues.planID == 1) ? '6 month' : '12 month';
            var planExpDate     = data[i].dataValues.endAt;

            var expDateMonth    = planExpDate.getMonth()+1; 
            expDateMonth        = (expDateMonth < 10) ? '0'+expDateMonth : expDateMonth; 
            
            var expDateDay      = (planExpDate.getDate() < 10) ? '0'+planExpDate.getDate() : planExpDate.getDate(); 
            var expDateYear     = planExpDate.getFullYear(); 
            
            var planExpDate     = expDateYear+'-'+expDateMonth +'-'+expDateDay;
            var emailContainer  = generalConfig.emailTemplate;

            


            var dataString = "<p>Dear "+userName+",</p>";
                dataString += "<p>Your current "+planDuration+" subscription to Om is set to auto-renew on "+planExpDate+". If you would like to continue using Om, no action is needed on your part; we’ll take care of it for you automatically.</p>";
                dataString += "<p>If for any reason you need to cancel your subscription, please log in and click here to update your settings: <a href='"+generalConfig.impconfig.websiteURL+"subscriptionsLog'>Om</a></p>";
                dataString += "<p>Thank you again for using Om and we hope you’ll continue to enjoy it in the future. We are constantly working on new repertoire and features. Stay tuned!</p>";

            var emailContainerString = emailContainer.emailContainerHeaderString+dataString+emailContainer.emailContainerFooterString;

            var message = {
                from         :    generalConfig.impconfig.noRplyEmail,          //Like : Om music, LLC <no-reply@accompanymusic.com>
                //to         :    userEmail,
                to           :    "ajay.khunti@gmail1.com.com",
                cc           :    "Mk <ajay.khunti@gmail1.com.com>",
                subject      :    emailContainer.subscriptionReminderEmailSubject,
                attachment   :    
                [
                    { data : emailContainerString, alternative : true },
                ]
            };

            generalConfig.getServer.send(message, function(err, message) { console.log(err || message); });

        }
        res.send({status:"Success"});



        //next();
    }).catch(function(err){
        res.send({status:"fail"});
        //next(err);
    });
};