'use strict';

var jwt = require('jsonwebtoken');
console.log("----get interceptor-----");

exports.someFucntion = function(req, res, next) {

    // Put the preprocessing here.
	console.log("----Hello some unique function-----");
  	if(req.body.token)
    {
        var token = req.body.token;
        console.log('----send token----');
        console.log(token); 
        jwt.verify(token, 'shhhhh', function(err, decoded) {
            if(err)
            {
                console.log(err.message);
                res.json({status:'fail','data':null, 'message':err.message});
            }
            else
            {
                next();
            }   
        });
    }
    else{
        console.log("---Token not found---");
        res.json({status:'fail','data':null, 'message':'Token not found'});
    }
};