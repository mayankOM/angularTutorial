module.exports = {
    //This is your MYSQL Database configuration
    db: {
        
        /*name: "pianoamigo_live_822016",
        password: "password",
        username: "other",
        host:"192.168.3.29",
        port:3306*/

        name: "pianoamigodev",
        password: "password",
        username: "other",
        host:"192.168.3.29",
        port:3306
    
    },
    modelsDir : {
    	path : __dirname + '/../models'
    }
};
