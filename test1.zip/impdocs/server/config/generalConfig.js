/*Crypto use for Encryption and Decryption of string */
var crypto = require('crypto');

/* Emailjs use for Email send email */
var email   = require("emailjs");
var server  = email.server.connect({
    host:    "111_mail.softwebopensource.com", 
    user:    "111_test@softwebopensource.com", 
    password:"111_DMr3vvGJ2Plfi5kUIv", 
    port:    25,
});

/* Following credentials for the Paypal payment gateway */
var payflow = require('paynode').use('payflowpro');
var sys = require('sys');
var client = payflow.createClient({level:payflow.levels.sandbox
	  ,user:'vasant.prajapati_api1.gmail1.com.com' 
	  ,password:'R7ZE96VRTFY6A2DJ' 
	  ,signature:'AaXRgm.egN2q7f-FLjHKcIzLWRm6A8k5.joyPS8Qx08BdElikNkvG2R4'
});

var siteUrl = 'http://localhost:3003/';



var isoCountries = {
    'AF' : 'Afghanistan',
    'AX' : 'Aland Islands',
    'AL' : 'Albania',
    'DZ' : 'Algeria',
    'AS' : 'American Samoa',
    'AD' : 'Andorra',
    'AO' : 'Angola',
    'AI' : 'Anguilla',
    'AQ' : 'Antarctica',
    'AG' : 'Antigua And Barbuda',
    'AR' : 'Argentina',
    'AM' : 'Armenia',
    'AW' : 'Aruba',
    'AU' : 'Australia',
    'AT' : 'Austria',
    'AZ' : 'Azerbaijan',
    'BS' : 'Bahamas',
    'BH' : 'Bahrain',
    'BD' : 'Bangladesh',
    'BB' : 'Barbados',
    'BY' : 'Belarus',
    'BE' : 'Belgium',
    'BZ' : 'Belize',
    'BJ' : 'Benin',
    'BM' : 'Bermuda',
    'BT' : 'Bhutan',
    'BO' : 'Bolivia',
    'BA' : 'Bosnia And Herzegovina',
    'BW' : 'Botswana',
    'BV' : 'Bouvet Island',
    'BR' : 'Brazil',
    'IO' : 'British Indian Ocean Territory',
    'BN' : 'Brunei Darussalam',
    'BG' : 'Bulgaria',
    'BF' : 'Burkina Faso',
    'BI' : 'Burundi',
    'KH' : 'Cambodia',
    'CM' : 'Cameroon',
    'CA' : 'Canada',
    'CV' : 'Cape Verde',
    'KY' : 'Cayman Islands',
    'CF' : 'Central African Republic',
    'TD' : 'Chad',
    'CL' : 'Chile',
    'CN' : 'China',
    'CX' : 'Christmas Island',
    'CC' : 'Cocos (Keeling) Islands',
    'CO' : 'Colombia',
    'KM' : 'Comoros',
    'CG' : 'Congo',
    'CD' : 'Congo, Democratic Republic',
    'CK' : 'Cook Islands',
    'CR' : 'Costa Rica',
    'CI' : 'Cote D\'Ivoire',
    'HR' : 'Croatia',
    'CU' : 'Cuba',
    'CY' : 'Cyprus',
    'CZ' : 'Czech Republic',
    'DK' : 'Denmark',
    'DJ' : 'Djibouti',
    'DM' : 'Dominica',
    'DO' : 'Dominican Republic',
    'EC' : 'Ecuador',
    'EG' : 'Egypt',
    'SV' : 'El Salvador',
    'GQ' : 'Equatorial Guinea',
    'ER' : 'Eritrea',
    'EE' : 'Estonia',
    'ET' : 'Ethiopia',
    'FK' : 'Falkland Islands (Malvinas)',
    'FO' : 'Faroe Islands',
    'FJ' : 'Fiji',
    'FI' : 'Finland',
    'FR' : 'France',
    'GF' : 'French Guiana',
    'PF' : 'French Polynesia',
    'TF' : 'French Southern Territories',
    'GA' : 'Gabon',
    'GM' : 'Gambia',
    'GE' : 'Georgia',
    'DE' : 'Germany',
    'GH' : 'Ghana',
    'GI' : 'Gibraltar',
    'GR' : 'Greece',
    'GL' : 'Greenland',
    'GD' : 'Grenada',
    'GP' : 'Guadeloupe',
    'GU' : 'Guam',
    'GT' : 'Guatemala',
    'GG' : 'Guernsey',
    'GN' : 'Guinea',
    'GW' : 'Guinea-Bissau',
    'GY' : 'Guyana',
    'HT' : 'Haiti',
    'HM' : 'Heard Island & Mcdonald Islands',
    'VA' : 'Holy See (Vatican City State)',
    'HN' : 'Honduras',
    'HK' : 'Hong Kong',
    'HU' : 'Hungary',
    'IS' : 'Iceland',
    'IN' : 'India',
    'ID' : 'Indonesia',
    'IR' : 'Iran, Islamic Republic Of',
    'IQ' : 'Iraq',
    'IE' : 'Ireland',
    'IM' : 'Isle Of Man',
    'IL' : 'Israel',
    'IT' : 'Italy',
    'JM' : 'Jamaica',
    'JP' : 'Japan',
    'JE' : 'Jersey',
    'JO' : 'Jordan',
    'KZ' : 'Kazakhstan',
    'KE' : 'Kenya',
    'KI' : 'Kiribati',
    'KR' : 'Korea',
    'KW' : 'Kuwait',
    'KG' : 'Kyrgyzstan',
    'LA' : 'Lao People\'s Democratic Republic',
    'LV' : 'Latvia',
    'LB' : 'Lebanon',
    'LS' : 'Lesotho',
    'LR' : 'Liberia',
    'LY' : 'Libyan Arab Jamahiriya',
    'LI' : 'Liechtenstein',
    'LT' : 'Lithuania',
    'LU' : 'Luxembourg',
    'MO' : 'Macao',
    'MK' : 'Macedonia',
    'MG' : 'Madagascar',
    'MW' : 'Malawi',
    'MY' : 'Malaysia',
    'MV' : 'Maldives',
    'ML' : 'Mali',
    'MT' : 'Malta',
    'MH' : 'Marshall Islands',
    'MQ' : 'Martinique',
    'MR' : 'Mauritania',
    'MU' : 'Mauritius',
    'YT' : 'Mayotte',
    'MX' : 'Mexico',
    'FM' : 'Micronesia, Federated States Of',
    'MD' : 'Moldova',
    'MC' : 'Monaco',
    'MN' : 'Mongolia',
    'ME' : 'Montenegro',
    'MS' : 'Montserrat',
    'MA' : 'Morocco',
    'MZ' : 'Mozambique',
    'MM' : 'Myanmar',
    'NA' : 'Namibia',
    'NR' : 'Nauru',
    'NP' : 'Nepal',
    'NL' : 'Netherlands',
    'AN' : 'Netherlands Antilles',
    'NC' : 'New Caledonia',
    'NZ' : 'New Zealand',
    'NI' : 'Nicaragua',
    'NE' : 'Niger',
    'NG' : 'Nigeria',
    'NU' : 'Niue',
    'NF' : 'Norfolk Island',
    'MP' : 'Northern Mariana Islands',
    'NO' : 'Norway',
    'OM' : 'Oman',
    'PK' : 'Pakistan',
    'PW' : 'Palau',
    'PS' : 'Palestinian Territory, Occupied',
    'PA' : 'Panama',
    'PG' : 'Papua New Guinea',
    'PY' : 'Paraguay',
    'PE' : 'Peru',
    'PH' : 'Philippines',
    'PN' : 'Pitcairn',
    'PL' : 'Poland',
    'PT' : 'Portugal',
    'PR' : 'Puerto Rico',
    'QA' : 'Qatar',
    'RE' : 'Reunion',
    'RO' : 'Romania',
    'RU' : 'Russian Federation',
    'RW' : 'Rwanda',
    'BL' : 'Saint Barthelemy',
    'SH' : 'Saint Helena',
    'KN' : 'Saint Kitts And Nevis',
    'LC' : 'Saint Lucia',
    'MF' : 'Saint Martin',
    'PM' : 'Saint Pierre And Miquelon',
    'VC' : 'Saint Vincent And Grenadines',
    'WS' : 'Samoa',
    'SM' : 'San Marino',
    'ST' : 'Sao Tome And Principe',
    'SA' : 'Saudi Arabia',
    'SN' : 'Senegal',
    'RS' : 'Serbia',
    'SC' : 'Seychelles',
    'SL' : 'Sierra Leone',
    'SG' : 'Singapore',
    'SK' : 'Slovakia',
    'SI' : 'Slovenia',
    'SB' : 'Solomon Islands',
    'SO' : 'Somalia',
    'ZA' : 'South Africa',
    'GS' : 'South Georgia And Sandwich Isl.',
    'ES' : 'Spain',
    'LK' : 'Sri Lanka',
    'SD' : 'Sudan',
    'SR' : 'Suriname',
    'SJ' : 'Svalbard And Jan Mayen',
    'SZ' : 'Swaziland',
    'SE' : 'Sweden',
    'CH' : 'Switzerland',
    'SY' : 'Syrian Arab Republic',
    'TW' : 'Taiwan',
    'TJ' : 'Tajikistan',
    'TZ' : 'Tanzania',
    'TH' : 'Thailand',
    'TL' : 'Timor-Leste',
    'TG' : 'Togo',
    'TK' : 'Tokelau',
    'TO' : 'Tonga',
    'TT' : 'Trinidad And Tobago',
    'TN' : 'Tunisia',
    'TR' : 'Turkey',
    'TM' : 'Turkmenistan',
    'TC' : 'Turks And Caicos Islands',
    'TV' : 'Tuvalu',
    'UG' : 'Uganda',
    'UA' : 'Ukraine',
    'AE' : 'United Arab Emirates',
    'GB' : 'United Kingdom',
    'US' : 'United States',
    'UM' : 'United States Outlying Islands',
    'UY' : 'Uruguay',
    'UZ' : 'Uzbekistan',
    'VU' : 'Vanuatu',
    'VE' : 'Venezuela',
    'VN' : 'Viet Nam',
    'VG' : 'Virgin Islands, British',
    'VI' : 'Virgin Islands, U.S.',
    'WF' : 'Wallis And Futuna',
    'EH' : 'Western Sahara',
    'YE' : 'Yemen',
    'ZM' : 'Zambia',
    'ZW' : 'Zimbabwe'
};


var emailContainerHeaderString = '<!DOCTYPE html>';
    emailContainerHeaderString += '<html lang="en-US">';
        emailContainerHeaderString += '<head>';
            emailContainerHeaderString += '<meta charset="utf-8">';
        emailContainerHeaderString += '</head>';
        emailContainerHeaderString += '<body>';
            emailContainerHeaderString += '<header></header>';
            emailContainerHeaderString += '<div>';

            var emailContainerFooterString = '</div>';
            
            emailContainerFooterString += '<div>';
                emailContainerFooterString += '<p>all best,</p>';
                emailContainerFooterString += '<BR/>';
                emailContainerFooterString += '<div>Steve</div>';
                emailContainerFooterString += '<div>Ommusic.com</div>';
                emailContainerFooterString += '<div><a href="https://www.facebook.com/OmMusic/">https://www.facebook.com/OmMusic/</a></div>';
                emailContainerFooterString += '<p><div><img alt="" src="'+siteUrl+'assets/Site/images/emailLogoAI.png"></div></p>';
            emailContainerFooterString += '</div>';

        emailContainerFooterString += '</body>';
    emailContainerFooterString += '</html>';

//Email Template End


module.exports = {

    getServer: server,
    cryptoAuthentication : {
        crypto : crypto,
        algorithm : 'aes-256-ctr',
        password : 'd6F3Efeq'
    },
    
    client : client,
    defaultFreeSubscriptionPeriod : 15,          //Here defined that Free subscription period "15 Days"
    sys : sys,
    
    AWS: {
        
        development: {
            s3BucketName:'softwebpianostage',
            innerFolder: 'tempos/',
            accessKeyId: 'AKIAIN4LALZJLSAV26LA',
            secretAccessKey: '111_FAbZAz8J98Lx6JhwyMLJk10w67OOwBYPpq47yvaJ'    
        },
        production: {
            s3BucketName:'accompany-production',
            innerFolder: '',
            accessKeyId: 'AKIAIN4LALZJLSAV26LA',
            secretAccessKey: '111_FAbZAz8J98Lx6JhwyMLJk10w67OOwBYPpq47yvaJ' 
        }
    },
    
    cloudFront: {
        
        development: {
            
            webDistribution : {
                domainName: 'https://d3nw1txdbe9o7s.cloudfront.net/',
                innerFolder: 'tempos/',
                keypairId: '111_APKAJJCX3JFRFNKDMVVQ',
                privateKeyPath: 'server/config/keyFiles/cloudFront/pk-APKAJJCX3JFRFNKDMVVQ.pem'    
            },
            
            RTMPDistribution : {
                domainName: 's249djpwcfkeug.cloudfront.net',
                innerFolder: 'tempos/',
                keypairId: '111_APKAJJCX3JFRFNKDMVVQ',
                privateKeyPath: 'server/config/keyFiles/cloudFront/pk-APKAJJCX3JFRFNKDMVVQ.pem'  
            }
        
        },
        production: {
            
            webDistribution : {
                domainName: 'https://d5dr1biitdh99.cloudfront.net/',
                innerFolder: '',
                keypairId: '111_APKAJJCX3JFRFNKDMVVQ',
                privateKeyPath: 'server/config/keyFiles/cloudFront/pk-APKAJJCX3JFRFNKDMVVQ.pem'
            },
            
            RTMPDistribution : {
                domainName: '',
                innerFolder: '',
                keypairId: '',
                privateKeyPath: ''
            }

        }
    },

    impconfig : {
        organizationName : "OM LLC",
        websiteURL       : siteUrl,
        //adminEmail       : "accompanymusicapp@gmail.com",
        adminEmail       : "mayank.patel@gmail1.com.com",
        tempAdminEmail   : "mayank.patel@gmail1.com.com",
        noRplyEmail      : "Om <no-reply@accompanymusicapp.com>",
        currentYear      : new Date().getFullYear(),
    },

    emailTemplate : {
        
        contactUsEmailSubject : 'You’ve received a message from an Om Music user.',
        signUpEmailSubject : 'Welcome to Om Music!',
        subscriptionEmailSubject : 'Thank you for your subscription to Om Music!',
        subscriptionReminderEmailSubject : 'A subscription reminder from Om Music :)',
        forgetPasswordEmailSubject : 'Om Music Password Reset',
        invitationEmailSubject : 'Welcome to Om!',
        thanksEmailSubject : ' Thanks for accepting our invitation to join Om.',
        emailContainerHeaderString : emailContainerHeaderString,
        emailContainerFooterString : emailContainerFooterString
    
    },
    subscriptionReminderBeforeDays : 10, //Here, User can get Reminder email before defined time for Renewal of subscription
    isoCountries : isoCountries, 


};