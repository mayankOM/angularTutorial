var bcrypt = require('bcrypt-nodejs');
var passport = require('passport');
var _ = require('lodash');

//These are different types of authentication strategies that can be used with Passport. 
var LocalStrategy = require('passport-local').Strategy;
var config = require('./config');
var db = require('./sequelize');

//console.log("---In Passport Authentication----");

//Serialize sessions
passport.serializeUser(function(user, done) {
    done(null, user.id);
});

passport.deserializeUser(function(id, done) {
    
    db.User.find({where: {id: id}}).then(function(user){
        
        console.log('Session: { id: ' + user.id + ', Firstname: ' + user.firstname + ' }');
        done(null, user);
    
    }).catch(function(err){
    
        done(err, null);
    
    });

});

//Use local strategy
passport.use(new LocalStrategy({
    
    usernameField: 'email',
    passwordField: 'password',
    passReqToCallback : true // allows us to pass back the entire request to the callback

},function(req, email, password, done) {

    console.log("---OM : Gte user data 001----");
    
    db.User.find({ 
        attributes : ['id','firstname', 'lastname', 'email', 'hashedPassword', 'salt', 'isPassUpdateStatus'],
        where: { 
            userStatus : true,
            email: email,
            isAdmin: req.body.loginBy == "admin" ? true : false
        }
    
    }).then(function(user) {

        if(req.body.loginBy == "admin") {
            
            if (!user) {
                done(null, false, { message: 'Unknown user' });
                console.log('----Un known user---');
            } else if (!user.authenticate(password)) {
                done(null, false, { message: 'Invalid password'});
                console.log('----In valid Password---');
            } else {
                console.log('Login (local) : { id: ' + user.id + ', firstname: ' + user.firstname + ' }');
                done(null, user);
            } 

        }else {
            
            console.log("---OM : Gte user data----");
            console.log(user);
            
            if (!user) {
                done(null, false, { message: 'Unknown user' });
                
                console.log('----Un known user---');
            } else if (!user.authenticate(password)) {
                done(null, false, { message: 'Invalid password'});
                
                console.log('----In valid Password---');
            } else if(user.isPassUpdateStatus == 0) {
                
                console.log('User re-set password process');
                
                var oldUser = {
                    'resetPassword' : '1',
                    'id' : user.id
                };
                done(null, oldUser);
            } else {
                console.log('Login (local) : { id: ' + user.id + ', firstname: ' + user.firstname + ' }');
                done(null, user);
            } 


            /*if(user.isPassUpdateStatus == 0) {
                
                console.log('User re-set password process');
                var oldUser = {
                    'resetPassword' : '1',
                    'id' : user.id
                };
                done(null, oldUser);
            
            } else {
                
                if (!user) {
                    done(null, false, { message: 'Unknown user' });
                    console.log('----Un known user---');
                } else if (!user.authenticate(password)) {
                    done(null, false, { message: 'Invalid password'});
                    console.log('----In valid Password---');
                } else {
                    console.log('Login (local) : { id: ' + user.id + ', firstname: ' + user.firstname + ' }');
                    done(null, user);
                }    
            }*/ 
        



        } 

    }).catch(function(err){
        console.log('----Query error---');
        done(err);
    });
}));

module.exports = passport;