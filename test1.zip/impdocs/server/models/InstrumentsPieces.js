/*
	* User Model
*/

module.exports = function(sequelize, DataTypes) {

	var InstrumentsPieces = sequelize.define('InstrumentsPieces', 
		{
			pieceID: DataTypes.INTEGER,
			instrumentID: DataTypes.INTEGER
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'instruments_pieces',

			associate: function(models) {
				InstrumentsPieces.belongsTo(models.Pieces);
				InstrumentsPieces.belongsTo(models.Instruments);
			}
		}
	);

	return InstrumentsPieces;
};
