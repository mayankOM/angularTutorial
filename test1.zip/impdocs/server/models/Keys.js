/*
	* Keys Model
*/

module.exports = function(sequelize, DataTypes) {

	var Keys = sequelize.define('Keys', {
			/*composerID: {
    			type: DataTypes.INTEGER,
    			primaryKey: true,
    			autoIncrement: true // Automatically gets converted to SERIAL for postgres
  			},*/
			title: DataTypes.STRING,
		}, {
		
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'keys',
		}
	);
	return Keys;
};
