/*
	* User Model
*/

module.exports = function(sequelize, DataTypes) {

	var UsersPieces = sequelize.define('UsersPieces', 
		{
			userID: DataTypes.INTEGER,
			pieceID: DataTypes.INTEGER,
			isFavourite: DataTypes.BOOLEAN,
			keyID: DataTypes.INTEGER,
			pianoTypeID: DataTypes.INTEGER,
			tuningID: DataTypes.INTEGER,
			tempo: DataTypes.INTEGER,
			loop1: DataTypes.INTEGER,

			endLoop: DataTypes.STRING,
			startLoop: DataTypes.STRING,
			index2: DataTypes.STRING,
			currentKey: DataTypes.STRING,
			currentTuning: DataTypes.STRING,
			currentPianoType: DataTypes.STRING,
			
			loopPiece: DataTypes.BOOLEAN,
			currentIndex: DataTypes.TIME,
			lastPlayed: DataTypes.NOW,
			
			loopDelay: DataTypes.INTEGER,
			volume: DataTypes.STRING,
			currentTempo: DataTypes.STRING,

			loopStart: DataTypes.INTEGER,
			loopEnd: DataTypes.INTEGER

		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'user_pieces',

			associate: function(models) {
				UsersPieces.belongsTo(models.User);
				UsersPieces.belongsTo(models.Pieces);
			}
		}
	);

	return UsersPieces;
};
