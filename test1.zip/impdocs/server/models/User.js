/*
	* User Model
*/

var crypto = require('crypto');

module.exports = function(sequelize, DataTypes) {

	var User = sequelize.define('User', 
		{
			firstname: DataTypes.STRING,
			lastname: DataTypes.STRING,
			email: DataTypes.STRING,
			hashedPassword: DataTypes.STRING,
			salt: DataTypes.STRING, 
			birthday: DataTypes.DATE,
			contact: DataTypes.STRING,
			gender: DataTypes.STRING,
			country: DataTypes.STRING,
			profilePicture: DataTypes.STRING,
			questionId: DataTypes.INTEGER,
			answer: DataTypes.STRING,
			isAdmin: DataTypes.BOOLEAN,
			userStatus: DataTypes.BOOLEAN,
			isPaid: DataTypes.BOOLEAN,
			isPassUpdateStatus: DataTypes.BOOLEAN
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'user',

			instanceMethods: {
				makeSalt: function() {
					return crypto.randomBytes(16).toString('base64'); 
				},
				authenticate: function(plainText){
					return this.encryptPassword(plainText, this.salt) === this.hashedPassword;
				},
				encryptPassword: function(password, salt) {
					if (!password || !salt) return '';
					salt = new Buffer(salt, 'base64');
					return crypto.pbkdf2Sync(password, salt, 10000, 64).toString('base64');
				}
			},
			associate: function(models) {
				//User.hasMany(models.Article);
				User.hasMany(models.UsersPieces);
				User.hasMany(models.Subscription);
				User.hasMany(models.SubscriptionLogs);
			}
		
		}
	);
	return User;
};
