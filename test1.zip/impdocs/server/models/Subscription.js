/*
	* User Model
*/

module.exports = function(sequelize, DataTypes) {

	var Subscription = sequelize.define('Subscription', 
		{
			userID: DataTypes.INTEGER,
			profileID: DataTypes.STRING,
			planID: DataTypes.INTEGER,
			profileStatus: DataTypes.STRING,
			startAt: DataTypes.DATE,
			endAt: DataTypes.DATE,
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'subscription',
  			associate: function(models) {
				
				Subscription.belongsTo(models.User);
				Subscription.belongsTo(models.Plans);
				
			}
		}
	);
	return Subscription;
};
