
module.exports = function(sequelize, DataTypes) {

	var AudioFiles = sequelize.define('AudioFiles', 
		{
			tempo: DataTypes.INTEGER,
			pieceID: DataTypes.INTEGER,
			file: DataTypes.STRING,
			keyID: DataTypes.INTEGER,
			tuningID: DataTypes.INTEGER,
			pianoTypeID: DataTypes.INTEGER,
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'audio_files',
			
			associate: function(models) {
				AudioFiles.belongsTo(models.Keys);
				//AudioFiles.belongsTo(models.PianoTypes);
				AudioFiles.belongsTo(models.Tunings);
			}
		}
	);

	return AudioFiles;
};
