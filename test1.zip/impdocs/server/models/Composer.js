/*
	* Composer Model
*/

module.exports = function(sequelize, DataTypes) {

	var Composer = sequelize.define('Composer', {
		
		firstName: DataTypes.STRING,
		lastName: DataTypes.STRING,
	
	}, {
		
		//disable the modification of tablenames; By default, sequelize will automatically
		//transform all passed model names (first parameter of define) into plural.
		//if you don't want that, set the following
		freezeTableName: true,
		//define the table's name
		tableName: 'composers',
		associate: function(models) {
			Composer.hasMany(models.Pieces);
		}
	
	});
	return Composer;
};
