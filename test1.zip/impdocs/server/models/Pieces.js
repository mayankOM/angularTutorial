
module.exports = function(sequelize, DataTypes) {

	var Pieces = sequelize.define('Pieces', {
			
			title		: DataTypes.STRING,
			composerID 	: DataTypes.INTEGER,
			isActive 	: DataTypes.BOOLEAN,
			tempo 		: DataTypes.INTEGER,
			sheetMusic 	: DataTypes.STRING,
		
		},{
			
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'pieces',
			
			associate: function(models) {
				
				Pieces.belongsTo(models.Composer);
				
				Pieces.belongsToMany(models.Libraries, { through: models.LibrariesPieces });
				Pieces.belongsToMany(models.Instruments, { through: models.InstrumentsPieces });
				
				Pieces.hasMany(models.AudioFiles);
				Pieces.hasMany(models.UsersPieces);

				//Pieces.hasMany(models.LibrariesPieces);
				
			}
		}
	);

	return Pieces;
};
