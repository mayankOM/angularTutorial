/*
	* User Model
*/

module.exports = function(sequelize, DataTypes) {

	var SecretQuestion = sequelize.define('SecretQuestion', 
		{
			question: DataTypes.STRING,
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'questions'
/*
			instanceMethods: {
				makeSalt: function() {
					return crypto.randomBytes(16).toString('base64'); 
				},
				authenticate: function(plainText){
					return this.encryptPassword(plainText, this.salt) === this.hashedPassword;
				},
				encryptPassword: function(password, salt) {
					if (!password || !salt) return '';
					salt = new Buffer(salt, 'base64');
					return crypto.pbkdf2Sync(password, salt, 10000, 64).toString('base64');
				}
			},*/
			/*associate: function(models) {
				SecretQuestion.hasMany(models.Article);
			}*/
		}
	);

	return SecretQuestion;
};
