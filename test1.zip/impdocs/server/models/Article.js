/*
	* Article Model
*/

module.exports = function(sequelize, DataTypes) {

	var Article = sequelize.define('Article', 
		{
			titleEN: DataTypes.STRING,
			contentEN:DataTypes.STRING,
			titleFR: DataTypes.STRING,
			contentFR:DataTypes.STRING,
			titleES: DataTypes.STRING,
			contentES:DataTypes.STRING,
			titleTW: DataTypes.STRING,
			contentTW:DataTypes.STRING,
			titleCH: DataTypes.STRING,
			contentCH:DataTypes.STRING,
		},
		{
			//disable the modification of tablenames; By default, sequelize will automatically
  			//transform all passed model names (first parameter of define) into plural.
  			//if you don't want that, set the following
  			freezeTableName: true,
  			//define the table's name
  			tableName: 'articles'

		}
	);

	return Article;
};
