'use strict';

//Define App module
var siteMusicLibrary = angular.module("siteMusicLibrary");
	
siteMusicLibrary.controller('siteMusicLibraryController', ["$rootScope","$scope","$timeout", "$route", "$location", "$http", "siteAuth", "$routeParams", "$filter",
	function($rootScope, $scope, $timeout, $route, $location, $http, siteAuth, $routeParams, $filter) {
		
		$scope.indexNo = '';
		$scope.userAuthentication = "";
		$scope.MuscilibraryList = "";
		
		//New Customisation by Ajay
		$scope.playerType 				= 'simple';
		$scope.simplePlayerObj 			= '';
		$scope.customPlayerObj 			= '';
		
		//$scope.s3BucketURL 			= 'https://d5dr1biitdh99.cloudfront.net/uploads/';
		$scope.s3BucketURL 				= 'https://s3-us-west-2.amazonaws.com/pianoamigo-cloudfront/uploads/';
		//$scope.s3BucketURL 			= 'https://s3.amazonaws.com/softwebpianostage/';
		
		$scope.defaultAudioFile 		= '';
		$scope.defaultAudioFileIndex 	= 0;
		$scope.selectedTempo 			= 0;
		$scope.currentTempoIndex 		= 0;
		$scope.payerStatus 				= 'paused';
		$scope.selectedPieceID 			= 0;

	    $scope.loopStartPercentage 		= 0;
	    $scope.loopEndPercentage 		= 20;
	    $scope.currentPlayerPosition 	= 0;
	    
	    //$scope.replayFlag 				= 1;
	    $scope.pauseTime 				= 2000;
	    $scope.favoritePiece 			= false;
	    $scope.defaultTempoIndex 		= 0;
	    $scope.defaultTempo 			= false;

	    $scope.reverse 					= false;
		$scope.predicate 				= 'title';

		if(siteAuth.getCurrentUser()) {
			$scope.userAuthentication = $rootScope.userAuthenticated;
		}	

		$scope.tempoArray = '';
		$scope.pauseflag = 0;
		
		//$scope.instrumentsText = 'Select';
		//$scope.librariesText = 'Select';

		$scope.libraries = '';
		$scope.instruments = '';

		

		/*$scope.searchText = "";
		$scope.friends = [{
	        name: 'John',
	        phone: '555-1276'
	    }, {
	        name: 'Mary',
	        phone: '800-BIG-MARY'
	    }, {
	        name: 'Mike',
	        phone: '555-4321'
	    }, {
	        name: 'Adam',
	        phone: '555-5678'
	    }, {
	        name: 'Julie',
	        phone: '555-8765'
	    }];*/

		
		$('.fancy-select').click(function() {
            
            if($(this).children('.trigger,.options').hasClass('open')) {
                $(this).children('.trigger,.options').removeClass('open');    
            } else {
                $('div.fancy-select .trigger, div.fancy-select .options ').removeClass('open');
                $(this).children('.trigger,.options').addClass('open');
            }
        });


		$scope.setReplayStatus = function() {
			
			if($scope.playerType == 'simple'){
				
				$("#slider").addClass("meter red");
				var startPoint = 0;
				var objectName = $scope.simplePlayerObj;
		    
		    } else {
		    	
		    	$("#customSlider").addClass("meter red");
				var objectName = $scope.customPlayerObj;
				var startPoint = $scope.loopStartPercentage;
				
			}
			objectName.jPlayer("pause");
			
			setTimeout(function() {
				$scope.payerStatus = 'playing';
				objectName.jPlayer("playHead", startPoint);
			},100);
		};

		$scope.setVal = function(key,val,text) {
			
			if(key == 'libraries') {
				$scope.libraries = val;
				$scope.librariesText = text;
			} else if (key == 'instruments') {
				$scope.instruments = val;
				$scope.instrumentsText = text;
			}
			$scope.searchData();
		};

		$scope.disableEnablePlay = function(palyer,flag){

			if(palyer === 'custom') {
				
				if(flag === 'disable') {
					$("#customSlider").slider('disable');
					$("#extraCustom").show();
					$("#existingCustom").hide();	
					$("#customSlider").addClass("meter red");
				} else {
					$("#customSlider").slider('enable');
					$("#extraCustom").hide();
					$("#existingCustom").show();	
					$("#customSlider").removeClass("meter red");
				}

			} else {

				if(flag === 'disable') {
					$("#slider").slider('disable');
					$("#extraSimple").show();
					$("#existingSimple").hide();	
					$("#slider").addClass("meter red");
				} else {
					$("#slider").slider('enable');
					$("#extraSimple").hide();
					$("#existingSimple").show();	
					$("#slider").removeClass("meter red");
				}
			}
		};

		/*
			Module : MusicLibrary
			Author : Mayank [SOFTWEB]
			Inputs : 
			Output : List of Basic data [Library List, Instrument List]
			Date   : 2015-10-28
		*/
		$scope.getMuscilibrary = function() {

			$scope.MuscilibraryList = "";
			$http.post('/api/general/getInstrumentList','').success(function(response) {
				
				$scope.instrumentsText 	= response[0].title;
				$scope.instruments 		= response[0].id;
				$scope.instrumentsList 	= response;	
			
				$http.post('/api/general/getLibraryList','').success(function(response) {
					
					$scope.librariesText 	= response[0].title;
					$scope.libraries 		= response[0].id;
					$scope.librariesList 	= response;
					
					$scope.searchData();	

				}).error(function(response) {
					$scope.error = response.message;
				});

			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		/*
			Module : MusicLibrary
			Author : Mayank Patel [SOFTWEB]
			Inputs : Search Keyword, InstrumentID or LibraryID
			Output : List of searched Pieces (Musci Library)
			Date   : 2015-10-28
		*/
		$scope.searchData = function() {

			$scope.MuscilibraryList = "";
			
			if($routeParams.favtxt == 'favorite'){
				var postedValue = {
					q			: 	($scope.q) ? $scope.q : '',
					libraries 	: 	($scope.libraries) ? $scope.libraries : '',
					instruments : 	($scope.instruments) ? $scope.instruments : '',
					userID      : 	siteAuth.getCurrentUser().id,
					favorite    : 	"YES"
				};
				$scope.musicLibTitle = "FAV";
			}
			else{
				var postedValue = {
					q			: 	($scope.q) ? $scope.q : '',
					libraries 	: 	($scope.libraries) ? $scope.libraries : '',
					instruments : 	($scope.instruments) ? $scope.instruments : '',
					userID      : 	siteAuth.getCurrentUser().id,
					favorite    : 	"NO"
				};
				$scope.musicLibTitle = "LIB";
			}	

			console.log(postedValue);

			$http.post('/api/site/listFilteredMuscilibrary',postedValue).success(function(response) {
				
				if(response.status == 'succ') {
					
					$scope.indexNo = 0;
					$scope.currentPage = 1;
	  				$scope.pageSize = 10;
					$scope.MuscilibraryList = response.data;
				
				} else {
					$scope.error = response.err;
				}	
			}).error(function(response) {
					$scope.error = response.message;
			});

		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : MisucLibraryId (PieceID)
		    Output : Get Detail of selected Piece
		    Date   : 2015-11-04
		*/
		$scope.getMusicDetail = function(pieceID) {
			
			var pieceRowID = '#musicLibIcon_'+pieceID;
			var selector = '.simpleTrack li.musicitem div a';
			
			$(selector).removeClass('active');
		    $(pieceRowID).addClass('active');
		    
		    var playHead = 0;

		    if($scope.playerType == 'simple'){
				$scope.disableEnablePlay('simple','disable');
				var objectName = $scope.simplePlayerObj;
		    } else {
		    	$scope.disableEnablePlay('custom','disable');
				var objectName = $scope.customPlayerObj;
			}
		    objectName.jPlayer("pause");

			$scope.MusicDetail = "";
			var pieceID = pieceID;
			var musicObj = {
				pieceID		: pieceID,
				userID      : siteAuth.getCurrentUser().id
			}

			if(musicObj) {
				
				
				//Get Music Detail for the selected Music ID (Piece ID)
				$http.post('/api/site/musicDetail',musicObj).success(function(response) {
					
					if(response.status == 'succ') {
						
						$scope.MusicDetail 			= response.data[0];       			//Piece Detail
						$scope.selectedTempo 		= $scope.MusicDetail.tempo;         //Default Tempo
						
						var musicDetailArray 		= ($scope.MusicDetail.UsersPieces[0]) ? $scope.MusicDetail.UsersPieces[0] : []; 
						$scope.favoritePiece    	= (musicDetailArray.isFavourite) ? musicDetailArray.isFavourite : false;
						$scope.selectedPieceID 		= musicObj.pieceID;
						
						$scope.loopStartPercentage 	= parseFloat((musicDetailArray.startLoop && musicDetailArray.startLoop != '') ? Number(parseFloat(musicDetailArray.startLoop)).toFixed(2) : 0); 
						$scope.loopEndPercentage  	= parseFloat((musicDetailArray.endLoop && musicDetailArray.endLoop != '') ? Number(parseFloat(musicDetailArray.endLoop)).toFixed(2) : 20); 
						
						$("#startPoint").val($scope.loopStartPercentage);
						$("#endPoint").val($scope.loopEndPercentage);

						$("#customSlider").slider("option", "values", [$scope.loopStartPercentage,$scope.loopEndPercentage]);
						$("#slider").slider("option", "value",0);

						playHead = ($scope.playerType == 'simple') ? 0 : $scope.loopStartPercentage;
						$scope.currentPlayerPosition = ($scope.playerType == 'simple') ? 0 : $scope.loopStartPercentage;
						
						
						$("#palyer").show();

						var tempoArray = [];
						//console.log("Ajay Here :: " + $scope.MusicDetail.AudioFiles.length + " => " +$scope.selectedTempo)
						
						for(var i = 0; i < $scope.MusicDetail.AudioFiles.length; i++) {
							
							if(parseInt($scope.MusicDetail.AudioFiles[i].tempo) === $scope.selectedTempo) {
								
								$scope.defaultAudioFileIndex 	= i;
								$scope.currentTempoIndex 		= i;
								$scope.defaultTempoIndex 		= i;
	    						$scope.defaultTempo 			= true;
	    						$scope.defaultAudioFile 		= $scope.MusicDetail.AudioFiles[i].file
								
								$scope.setPlayer(objectName,playHead);
								
							}
							
							var obj = {
								index 	: i,
								id 		: $scope.MusicDetail.AudioFiles[i].id,
								tempo 	: $scope.MusicDetail.AudioFiles[i].tempo,
								file 	: $scope.MusicDetail.AudioFiles[i].file,
							}
							tempoArray.push(obj);
						}
						
						$scope.tempoArray = tempoArray;
						
					} else {
						$scope.error = response.err;
					}	
				
				}).error(function(response) {
					$scope.error = response.message;
				});	
			}
		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : Index Of selected Tempo
		    Output : Get detail of NEXT tempo 
		    Date   : 2015-11-19
		*/
		$scope.getTempoDetailPrev = function(index) {

			index = parseInt(index) + 1;
			
			if(index >= 0 && index < $scope.tempoArray.length) {
				
				
				var currentPlayerPosition 			= $scope.currentPlayerPosition;
				//$scope.currentPlayerPositionOne 	= currentPlayerPosition;

				$scope.defaultTempo 			= ($scope.defaultTempoIndex == index) ? true : false;
				$scope.defaultAudioFile 		= $scope.tempoArray[index].file;
				$scope.defaultAudioFileIndex 	= $scope.tempoArray[index].index;
				$scope.selectedTempo 			= $scope.tempoArray[index].tempo;
				$scope.currentTempoIndex 		= $scope.defaultAudioFileIndex;

				var currentPayerStatus 			= $scope.payerStatus;
				
				if($scope.playerType == 'simple') {
					$scope.disableEnablePlay('simple','disable');
					var objectName = $scope.simplePlayerObj;
				} else {
					$scope.disableEnablePlay('custom','disable');
					var objectName = $scope.customPlayerObj;
				}
				
				$scope.setPlayer(objectName,currentPlayerPosition);

			} else {
				return false;
			}	
		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : Index Of selected Tempo
		    Output : Get detail of selected tempo -1
		    Date   : 2015-11-19
		*/
		$scope.getTempoDetailNext = function(index) {

			index = parseInt(index) - 1;
			
			if(index >= 0 && index < $scope.tempoArray.length) {
				
				var currentPlayerPosition 		= $scope.currentPlayerPosition;
				$scope.defaultTempo 			= ($scope.defaultTempoIndex == index) ? true : false;
				$scope.defaultAudioFile 		= $scope.tempoArray[index].file;
				$scope.defaultAudioFileIndex 	= $scope.tempoArray[index].index;
				$scope.selectedTempo 			= $scope.tempoArray[index].tempo;
				$scope.currentTempoIndex 		= $scope.defaultAudioFileIndex;
				var currentPayerStatus 			= $scope.payerStatus;
				
				if($scope.playerType == 'simple') {
					$scope.disableEnablePlay('simple','disable');
					var objectName = $scope.simplePlayerObj;
				} else {
					$scope.disableEnablePlay('custom','disable');
					var objectName = $scope.customPlayerObj;
				}
				
				$scope.setPlayer(objectName,currentPlayerPosition);
			
			} else {
				return false;
			}
		};


		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : Sort parameter
		    Output : Get Sort list
		    Date   : 2015-11-09
		*/
		$scope.order = function(predicate) {
			$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
			$scope.predicate = predicate;
		};

		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : pieceID, userID
		    Output : Update Favorite or UnFavorite Piece
		    Date   : 2015-11-20
		*/
		
		$scope.updateFavourite = function() {
			
			var userID 	= siteAuth.getCurrentUser().id;
			var obj = {
				userID 		: userID,
				pieceID 	: $scope.selectedPieceID,
			};						
			
			$http.post('/api/site/updateFavourite',obj).success(function(response) {
				if(response.status == 'succ') {
					$scope.favoritePiece = response.data; 
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};




		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : pieceID, userID
		    Output : Update Start and End time of loop
		    Date   : 2015-11-20
		*/
		
		$scope.updateStartEndTime = function() {
			
			var userID 	= siteAuth.getCurrentUser().id;
			var obj = {
				userID 		: userID,
				pieceID 	: $scope.selectedPieceID,
				startLoop 	: $scope.loopStartPercentage,
				endLoop 	: $scope.loopEndPercentage,
			};						
			
			$http.post('/api/site/updateStartEndTime',obj).success(function(response) {
				if(response.status == 'succ') {
					console.log("Time Updated :: ");
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};


		/*
			Module : MusicLibrary
		    Author : Mayank Patel [SOFTWEB]
		    Inputs : PieceID, UserID
		    Output : Update la