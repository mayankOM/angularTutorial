/*
* gulp for css and js 
*/
var gulp = require('gulp');
var minifycss = require('gulp-minify-css');
var minifyjs = require('gulp-uglify');
var concat = require('gulp-concat');

var paths = {
    publicCSS: 'public/css/**/*.css',
    publicJS: 'public/js/**/*.js',
    adminLTECSS: 'public/assets/Admin/dist/css/**/*.css',
    // adminLTEJS: 'public/assets/Admin/dist/js/**/*.js',
    // templates: 'public/src/templates/**/*.html',
}

var copyOthers = {
    bootstrapFonts: 'public/lib/bootstrap/dist/fonts/**/*',
    fontawesomeFonts: 'public/lib/fontawesome/fonts/**/*',
}
var dest = {
    css: 'public/build/css/',
    js: 'public/build/js/',
    templates: 'public/dist/templates',
    fonts: 'public/build/fonts',
}

var bowerCss = [
            'public/lib/fontawesome/css/font-awesome.min.css',
            'public/lib/bootstrap/dist/css/bootstrap.min.css',
            paths.publicCSS,
            paths.adminLTECSS,
            ];

var JS = [
            'public/lib/jquery/dist/jquery.min.js',
            'public/lib/angular/angular.min.js',
            'public/lib/angular-cookies/angular-cookies.min.js',
            'public/lib/angular-resource/angular-resource.min.js',
            'public/lib/angular-route/angular-route.min.js',
            'public/lib/bootstrap/dist/js/bootstrap.min.js',
            paths.publicJS,
            // paths.adminLTEJS,
            ];

var copyFolders = [
                  copyOthers.bootstrapFonts,
                  copyOthers.fontawesomeFonts,
                  ];

gulp.task('css', function() {
    return gulp.src(bowerCss)
        .pipe(minifycss())
        .pipe(concat('main.min.css'))
        .pipe(gulp.dest(dest.css));
});



gulp.task('sitejs', function() {
    return gulp.src(JS)
        // .pipe(minifyjs())
        .pipe(concat('main.min.js'))
        .pipe(gulp.dest(dest.js))
});

gulp.task('copy', function() {
    return gulp.src(copyFolders)
        .pipe(gulp.dest(dest.fonts));
});
gulp.task('watch', function() {
    gulp.watch(paths.css, ['css']);
    gulp.watch(paths.js, ['js']);
    // gulp.watch(paths.templates, ['templates']);
});

gulp.task('default', ['css', 'sitejs', 'copy', 'watch']);
