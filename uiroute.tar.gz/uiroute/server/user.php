<?php 

//DB Connect
include 'ajs_db_config.php'; 

if($_REQUEST['type'] == 'list')
{
	$result = $conn->query("SELECT * FROM user");
	$cnt =0;
	$data = array();
	while ($rs = $result->fetch_array(MYSQLI_ASSOC)) {
	    $data[$cnt]['id'] = $rs["id"];
	    $data[$cnt]['name'] = $rs["name"];
	    $data[$cnt]['email'] = $rs["email"];
	    $data[$cnt]['phone'] = $rs["phone"];
	    $cnt++;
	}
	echo json_encode($data);	
}	
else if($_REQUEST['type'] == 'get')
{
	$result = $conn->query("SELECT * FROM user where id = ".$_REQUEST['id']);
	$data = array();
	$data = $result->fetch_array(MYSQLI_ASSOC);
	echo json_encode($data);
}	
else if($_REQUEST['type'] == 'add')
{
	$postdata = file_get_contents('php://input');
    $post     = json_decode($postdata,true);
    
	$result = $conn->query("INSERT INTO user (name,email,phone) VALUES ('".$post['name']."','".$post['email']."','".$post['phone']."')");
	echo json_encode($result);
}
else if($_REQUEST['type'] == 'update')
{
	$postdata = file_get_contents('php://input');
    $post     = json_decode($postdata,true);
	$result = $conn->query("UPDATE user SET name = '".$post['name']."', email = '".$post['email']."', phone = '".$post['phone']."'  where id = ".$post['id']);
	echo json_encode($result);
}
else if($_REQUEST['type'] == 'del')
{
	$postdata = file_get_contents('php://input');
    $post     = json_decode($postdata,true);
	$result = $conn->query("DELETE from user where id = ".$_REQUEST['id']);
	echo json_encode($result);
}	

?>