<?php 

//DB Connect
include 'ajs_db_config.php'; 

$result = $conn->query("SELECT * FROM user");
$cnt =0;
$data = array();
while ($rs = $result->fetch_array(MYSQLI_ASSOC)) {
    $data[$cnt]['Name'] = $rs["name"];
    $data[$cnt]['City'] = $rs["city"];
    $data[$cnt]['Contact'] = $rs["contact"];
    $cnt++;
}

print_r($data);


echo json_encode($data);
?>