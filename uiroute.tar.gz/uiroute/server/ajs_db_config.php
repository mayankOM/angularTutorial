<?php 

/*Database Connection Configuration */
$conn = new mysqli("192.168.3.29", "other", "password", "uiroutesdemo");

?>