var routerApp = angular.module('routerApp', ['ui.router']);

routerApp.config(function($stateProvider, $urlRouterProvider) {
    
    //$urlRouterProvider.otherwise('home');
    
    $stateProvider
        
        .state('home', {
            //url: '/home',
            templateUrl: 'pages/home.html'
        })
        .state('about', {
            //url: '/about',
            templateUrl: 'pages/about.html'
        })
        .state('contact', {
            //url: '/contact',
            templateUrl: 'pages/contact.html'
        })
        .state('user', {
            //url: '/user',
            templateUrl: 'pages/userList.html'
        })
        .state('addUser', {
            //url: '/user',
            templateUrl: 'pages/addUser.html'
        })
        /*.state('user.edit', {
		    params: ['userID'],
		    templateUrl: 'pages/editUser.html'
		});*/
        .state('edit', {
            //url: '/user/',
            templateUrl: 'pages/editUser.html',
        });
        
});

routerApp.controller('userController', ['$rootScope','$scope','$http', '$location', '$timeout', '$stateParams', '$state',
	function($rootScope, $scope, $http, $location, $timeout, $stateParams, $state) {

		$scope.getUserList = function () {
			$http.get('/html/uiroute/server/user.php?type=list').success(function(response) {
				$scope.userList = response;
				$scope.predicate = 'id';
			}).error(function(response) {
				$scope.error = response.message;
			});
		};
		
		$scope.addUser = function () {

			$http.post($location.$$absUrl+'/server/user.php?type=add',$scope.user).success(function(response) {
				if(response == 'true')
				{
					$state.go('user');
					$scope.user = '';					
				}
				else
				{
					$scope.error = response;
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		$scope.editView = function (userID) {
			$state.go('edit');
			$http.get($location.$$absUrl+'/server/user.php?type=get&id='+userID).success(function(response) {
				$rootScope.user = response;
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		$scope.delUser = function (userID) {
			$http.get($location.$$absUrl+'/server/user.php?type=del&id='+userID).success(function(response) {
				if(response == 'true')
				{
					var user_id = '#list_'+userID; 
					$(user_id).remove();
				}
				else
				{
					$scope.error = response;
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};

		$scope.updateUser = function (userID) {
			$http.post($location.$$absUrl+'/server/user.php?type=update',$scope.user).success(function(response) {
				if(response == 'true')
				{
					$state.go('user');
				}
				else
				{
					$scope.error = response;
				}	
			}).error(function(response) {
				$scope.error = response.message;
			});
		};


		$scope.reverse = true;
		$scope.order = function(predicate) {
			$scope.reverse = ($scope.predicate === predicate) ? !$scope.reverse : false;
			$scope.predicate = predicate;
		};
	}
]);