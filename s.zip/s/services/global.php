<?php
define('_JEXEC', 1);
define('JPATH_BASE', dirname(dirname(__FILE__)));
define('DS', DIRECTORY_SEPARATOR);
require_once ( JPATH_BASE . DS . 'includes' . DS . 'defines.php' );
require_once ( JPATH_BASE . DS . 'includes' . DS . 'framework.php' );

$base_url = str_replace("/services/", "", JURI::root()).DS;

$joomlaDB = new JConfig;
$config_vars = get_class_vars(get_class($joomlaDB));

include "classes/mysql.class.php";

define('SITE_URL', $base_url);
define('DB_TYPE', 'mysql');
define('DB_SERVER_HOST', $config_vars['host']);
define('DB_SERVER_USERNAME', $config_vars['user']);
define('DB_SERVER_PASSWORD', $config_vars['password']);
define('DB_NAME', $config_vars['db']);

?>