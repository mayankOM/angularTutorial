<?php 
/*
	//Includes/PHP  
	
		Module:MySql.Class.php(common mysql query file)
		Name: MySql.Class.php
		Created By: AD
		Description : code for handling all database queries
		Date : 2010-03-11
*/


class sql
{

    /*****************************************************
	
		-sql class for handling database queries
		
	****************************************************/
	
	
	var $dbhost;
    var $dbuser;
    var $dbpass; 
    var $dbase;
	 var $sql_query;
    var $mysql_link;
	
    var $sql_result;
    var $query_count;



    function sql()
    {

/*****************************************************
	
	-function for assigninig database information
	
****************************************************/


		$this->dbhost = DB_SERVER_HOST;

        $this->dbuser = DB_SERVER_USERNAME;

        $this->dbpass = DB_SERVER_PASSWORD;

        $this->dbase = DB_NAME;
		
		
        $this->mysql_link = '';
		
		
        $this->query_count = '0';

        $this->sql_result = '';

        $this->connection();

    }



	 function connection()
    {

        /*****************************************************
	
		-function for connection of eCountryLifestyle database
		
		****************************************************/
		
		$this->mysql_link = @mysql_pconnect( $this->dbhost, $this->dbuser, $this->dbpass ) or $this->error( mysql_error( $this->mysql_link ), $this->sql_query, mysql_errno( $this->mysql_link ) );
		
		
		@mysql_select_db( $this->dbase ) or $this->error( mysql_error( $this->mysql_link ), $this->sql_query, mysql_errno( $this->mysql_link ) );
		

		
    }


    function error( $error_msg, $sql_query, $error_no )
    {
		//echo "Error: $error_msg";
    }



    function close()
    {

        /*****************************************************
	
		-function to close connection of database
		
		****************************************************/
		mysql_close( $this->mysql_link );

    }

	


    function sql_query( $sql_query )
    {

       
		/*****************************************************
	
		-function to handle database queries
		
		****************************************************/
		
		
		
		$this->sql_query = $sql_query; 
        
        $this->sql_result = mysql_query( $sql_query, $this->mysql_link );
		
        if (!$this->sql_result)

        {

            $this->error( mysql_error( $this->mysql_link ), $this->sql_query, mysql_errno( $this->mysql_link ) );

        }

    
            $count = $this->query_count;

            $count = ($count + 1);

            $this->query_count = $count;
			
			return $this->sql_result;

    }



    function num_rows()
    {

        /*****************************************************
	
		-function for retriving number of rows from the result
		
		****************************************************/
		
		
		$mysql_rows = mysql_num_rows($this->sql_result);

        return $mysql_rows;

    }



    function affected_rows()
    {

        /*****************************************************
	
		-function for retriving number of affected rows from the query
		
		****************************************************/
		
		
		$mysql_affected_rows = mysql_affected_rows( $this->mysql_link );

        return $mysql_affected_rows;

    }        


    function fetch_object()
    {	
		/*****************************************************
	
		-function to retrive result as a object
		
		****************************************************/
		$mysql_object = mysql_fetch_object( $this->sql_result );
		
		return $mysql_object;

    }




    function fetch_array($result='')
    {

        /*****************************************************
	
		-function to retrive result as an array 
		
		****************************************************/
		if($result)
			$sql_result = $result;
		else
			$sql_result = $this->sql_result;

            $mysql_array = mysql_fetch_assoc( $sql_result );

            if (!is_array( $mysql_array ))
            {
                return FALSE;
            }
    
            return $mysql_array;
    }


    function fetch_rows()
    {
        
		/*****************************************************
	
		-function to retrive result as a row
		
		****************************************************/
		
		if ( $this->num_rows() > 0 )

        {

            $mysql_array = mysql_fetch_row( $this->sql_result );

            if (!is_array( $mysql_array ))
            {
                return FALSE;
            }
        
            return $mysql_array;
        }
     }

	function mysql_fetch_all() {
		if($this->num_rows() > 0 )
        {
			$all = array();
			while($row = mysql_fetch_assoc($this->sql_result)) { $all[] = $row['clip_art_id']; }
			return $all;
		}
	}

    function query_count()
    {

        return $this->query_count;

    }
	function fetch_array_multiple()
    {

        if ( $this->num_rows() > 0 )
        {

            while($mysql_array = mysql_fetch_assoc( $this->sql_result )){
	            $returned_array[] = $mysql_array;
	            if (!is_array( $mysql_array ))
	            {
	                return FALSE;
	            }
			}
    
            return $returned_array;
        } 
    }
    function generateRandomPassword() {
		   $length = 9;
		   $chars = '0123456789';
    	   return substr( str_shuffle( $chars ), 0, $length );
	}
	
}
?>
