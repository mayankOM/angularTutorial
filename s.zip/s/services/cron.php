<?php   
    include('global.php');
    ini_set("display_errors", "off");   

    global $obj_service;
    $obj_service = new sql();
    $date = date("Y-m-d H:i:s");
    $suggestion_id = $_GET['suggestion_id'];

    if(isset($suggestion_id) && $suggestion_id != ""){
        //get username
        $usernamesql = "SELECT u.UserId,u.UserName FROM users AS u LEFT JOIN suggestions AS s ON s.posted_by = u.UserId WHERE s.id = ".$suggestion_id;
        $resultusername     = $obj_service->sql_query($usernamesql);
        $usernamedata       = $obj_service->fetch_array_multiple($resultusername);
        $username = $usernamedata[0]['UserName'];
        $user_id = $usernamedata[0]['UserId'];

        $type = $_GET['type'];
        if($type == "Normal"){
            $message = 'New suggestion from '.$username;
        }else{
            $message = 'New '.$_GET['type'].' suggestion from '.$username;
        }
        
        if($user_id != ""){
            $sql = "SELECT u.token FROM suggestions_map AS sm LEFT JOIN users AS u ON u.UserId = sm.posted_to WHERE sm.suggestion_id = '".$suggestion_id."' AND u.token != ''";
            $result = $obj_service->sql_query($sql);
            $data   = $obj_service->fetch_array_multiple($result);
            if(isset($data) && count($data)>0){
                foreach ($data as $user_key => $user_value) {
                    $token = $user_value['token'];
                    if(isset($token) && trim($token) !=""){
                        sendPushnotification($type,$token,$message,$user_id,$suggestion_id);
                    }
                }
            }
        }
    }

    function sendPushnotification($type,$token,$message,$postedby,$suggerstionid)
    {
        $apiKey = "AIzaSyB6jk6RsZ71C3v5w1ETzqd-_t5fJSO1TMc";
        $registrationIDs = array($token);
        // Replace with real client registration IDs
        
        // Message to be sent
        $alert['Alert']['postedby'] = $postedby;
        $alert['Alert']['message'] = $message;
        $alert['Alert']['isFriendRequest'] = 'false';

        if($type == 'Instant') {
            $alert['Alert']['isNormalSuggestion'] = 'false';
        }
        if($type == 'Normal') {
            $alert['Alert']['suggestionid'] = $suggerstionid;
            $alert['Alert']['isNormalSuggestion'] = 'true';
        }
        $message = $alert['Alert'];
        $output = json_encode($message);

        // Set POST variables
        $url = 'https://android.googleapis.com/gcm/send';
        $fields = array(
            'registration_ids' => $registrationIDs,
            'data' => array( "message" => $output ),
        );
        $headers = array(
            'Authorization: key=' . $apiKey,
            'Content-Type: application/json'
        );

        // Open connection
        $ch = curl_init();
        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url );
        curl_setopt($ch, CURLOPT_POST, true );
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode( $fields ));
        // Execute post
        $result = curl_exec($ch);
        // Close connection
        curl_close($ch);
        return;
    }
    /* custmization end - ashwin */
?>