<?php   





 header('Content-type: application/json');
    include('global.php');
//    include("classes/class.phpmailer.php");
   
  //  date_default_timezone_set("Asia/Calcutta");
    ini_set("display_errors", "off");   
    
    global $obj_service;   
    $obj_service = new sql();    
    $date    = date("Y-m-d H:i:s");         //Current date and time.


    // START PUSH FOR NORMAL ...................
    $normalsuggestion = 'SELECT * FROM `pushnotification` WHERE `type` = "Normal" AND `status` = "0" ';
    $resultnormal     = $obj_service->sql_query($normalsuggestion);
    $normaldata       = $obj_service->fetch_array_multiple($resultnormal); 
    // echo "Normal";
    // echo "<pre>";
    if(count($normaldata) > 0) {
        for ($normal=0; $normal < count($normaldata); $normal++) { 
           // print_r($normaldata[$normal]);
            $alllto = $normaldata[$normal]['to'];
            $to = explode(",", $alllto);
            $postedby = $normaldata[$normal]['from'];

            for ($cntt=0; $cntt < count($to); $cntt++) { 
                if($to[$cntt] != $postedby)
                {
                    $alluserss    = 'SELECT `token` FROM `users` WHERE `UserId` = '.$to[$cntt]; // select all userid
                    $usersinf  = $obj_service->sql_query($alluserss);
                    $usertoken    = $obj_service->fetch_array_multiple($usersinf); 
                    $usestokens = $usertoken[0]['token'];
                    $typess = '';
                    $message = 'New Suggestion';
                    $typeaa = 'Normal';
                    if($usestokens != '') {



                        sendPushnotification($typess,$usestokens,$message,$typeaa);


                          /*****************************************************/
                          // $content  = $to[$cntt].'---';
                          //           $filename = 'resp111.txt';
                          //           $somecontent =   $content;
                          //           // Let's make sure the file exists and is writable first.
                          //           if (is_writable($filename)) {
                          //               // In our example we're opening $filename in append mode.
                          //               // The file pointer is at the bottom of the file hence
                          //               // that's where $somecontent will go when we fwrite() it.
                          //               if (!$handle = fopen($filename, 'a')) {
                          //               }
                          //               // Write $somecontent to our opened file.
                          //               if (fwrite($handle, $somecontent) === FALSE) {
                          //               }
                          //               fclose($handle);
                          //           } else {     }

            /**************************************************************/



                    }
                }
            }
         // UPDATE ALL NEW PUSHED 
            //$updatpush     = 'UPDATE `pushnotification` SET `status` = "1"   WHERE   `type` = "Normal"  AND  `from` =  "'.$postedby.'"  AND `status` = "0" ';
            $updatpush     = 'DELETE FROM  `pushnotification`   WHERE   `type` = "Normal"  AND  `from` =  "'.$postedby.'"  AND `status` = "0" ';
            $updatepushfornormal = $obj_service->sql_query($updatpush);

        }
    }
    // END  PUSH FOR NORMAL ...................








//send notification
function sendPushnotification($type,$token,$message,$type)
{
      
            //$token = 'APA91bHshBQ-6F_2P6pT59wpzZ1jia9cP4-DoPX6iulP8opyxBo-STXd-VEgsjGUvqHcj89SJJA2Iv5nmhlQ7ouz4bksQ0KWhMMQgjk8RMvfUb_fJpMhTqUZ_wjNgPLayGVb5kKfW1Pl';
            // for android
            //https://code.google.com/apis/console/#project:884537514719:services
            // Replace with real server API key from Google APIs  
        //    $apiKey = "AIzaSyCST4YwzgAitxLuElsjcM4Nvowf86G3o9Y";    

            $apiKey = "AIzaSyB6jk6RsZ71C3v5w1ETzqd-_t5fJSO1TMc";    
 


            $registrationIDs = array($token);
            // Replace with real client registration IDs
            //$registrationIDs = array("APA91bFZe7Azlnn6hRBwOpNBxhxzRSJxffGxzetMeJOIqR9bRDNTCeM-eksG5Ue_0qItP5-tpObsl6T8qbC_0HQyYcBIdu56VAfGUzJVfmGCOLugj_fBa9ze-nS1TgNU7vR14qomj2Bh");
                
             // Message to be sent
            if($type == 'Instant') {
                $alert['Alert']['message'] = $message;
                $alert['Alert']['isNormalSuggestion'] = 'false';
            }
            if($type == 'Normal') {
                $alert['Alert']['message'] = $message;
                $alert['Alert']['isNormalSuggestion'] = 'true';
            }

            $message = $alert['Alert'];
            $output = json_encode($message);


            // print_r($output);  
            // exit;

            // Set POST variables
            $url = 'https://android.googleapis.com/gcm/send';

            $fields = array(
           'registration_ids' => $registrationIDs,
             'data' => array( "message" => $output ),
            );
            $headers = array(
              'Authorization: key=' . $apiKey,
             'Content-Type: application/json'
              );

             // Open connection
            $ch = curl_init();
            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url );
            curl_setopt($ch, CURLOPT_POST, true );
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode( $fields ));
            // Execute post
            $result = curl_exec($ch);
            // Close connection

          


            /*****************************************************/
                                    // $filename = 'resp.txt';
                                    // $somecontent =  $result;
                                    // // Let's make sure the file exists and is writable first.
                                    // if (is_writable($filename)) {
                                    //     // In our example we're opening $filename in append mode.
                                    //     // The file pointer is at the bottom of the file hence
                                    //     // that's where $somecontent will go when we fwrite() it.
                                    //     if (!$handle = fopen($filename, 'a')) {
                                    //     }
                                    //     // Write $somecontent to our opened file.
                                    //     if (fwrite($handle, $somecontent) === FALSE) {
                                    //     }
                                    //     fclose($handle);
                                    // } else {     }

            /**************************************************************/




            curl_close($ch);
        return;
}



?>
