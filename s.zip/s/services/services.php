<?php   
header('Content-type: application/json');
//date_default_timezone_set('UTC');
include('global.php');
include("classes/class.phpmailer.php");
include('functions.php');
include('../db_replicant.php');
ini_set("display_errors", "off");


global $dataMigrate;   
$dataMigrate = new dataMigrate(); 

global $obj_service;   
$obj_service = new sql();    
$siteUrl = $_SERVER['HTTP_HOST'];       //site url
$currentdate    = date("Y-m-d H:i:s");         //Current date and time.
//$script_tz = date_default_timezone_get();

$action  = isset($_REQUEST['action']) ? strtolower(trim($_REQUEST['action'])) : '';

$appurl = SITE_URL;

switch($action) 
{   
    
    case 'getscantimer' :
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        
        if($company_id > 0)
        {        
            $query  = 'SELECT * from `ppe_company_info` as c
                       LEFT JOIN `ppe_app_versions` as av on c.id = av.company_id
                       WHERE c.`id` = "'.$company_id.'" AND av.test_mode = 0';                   
            $result = $obj_service->sql_query($query);
            $companyData   = $obj_service->fetch_array($result);
            
            if($companyData['id'] > 0) {                
                $arrResultDetails['timer'] = 5;                
                $arrResultDetails['version'] = $companyData['app_version'];
                $arrResultDetails['update_link'] = $companyData['update_link'];
		$arrResultDetails['disclaimer_title'] = 'Custom Disclaimer';
                $arrResultDetails['disclaimer'] = 'If I do not return this equipment to Tyson Fresh Meats, Inc. I agree Tyson Fresh meats, Inc. may deduct its value from my paycheck.';
                $arrResultDetails['success'] =  1;              
            } else {
                $arrResultDetails['message'] = 'Version not found';
                $arrResultDetails['success'] =  0;              
            }
        } 
        else
        {
            $arrResultDetails['message'] = 'Please enter parameters with proper value.';
            $arrResultDetails['success'] =  0;        
        }

    break;

    case 'getregisteredjobzones' :
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        
        if($company_id)
        {        
            $query  = 'SELECT j.id, j.job_title FROM `ppe_jobrole` as j 
                       JOIN `ppe_company_jobrole_map` as cjm ON cjm.`jobrole_id` = j.`id` AND cjm.`status` = 1
                       WHERE cjm.`company_id` = "'.$company_id.'"';                   
            $result = $obj_service->sql_query($query);
            $jobroles   = $obj_service->fetch_array_multiple($result);

            if (count($jobroles)) 
            {                
                /*$jobzones = array();
                foreach($jobroles as $jobrole) {
                    $jobzones[$jobrole['id']] = $jobrole['job_title'];
                } */   
                $arrResultDetails['jobzones'] = $jobroles;        
                $arrResultDetails['TotalCount'] = count($jobroles);        
                $arrResultDetails['success'] = 1;                

            } else {
                $arrResultDetails['message'] = 'No Jobzone Found';
                $arrResultDetails['success'] = 0;
            }
        } 
        else
        {
            $arrResultDetails['message'] = 'Please enter parameters with proper value.';
            $arrResultDetails['success'] =  0;        
        }

    break;


    case 'employeeregistration' :

        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $user_id = isset($post['app_user_id']) ? trim($post['app_user_id']) : '';
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $employee_id = isset($post['employee_id']) ? trim($post['employee_id']) : '';
        $password = isset($post['password']) ? trim($post['password']) : '';
        $confirm_password = isset($post['confirm_password']) ? trim($post['confirm_password']) : '';
        $firstname = isset($post['firstname']) ? trim($post['firstname']) : '';
        $lastname = isset($post['lastname']) ? trim($post['lastname']) : '';                
        $barcode = isset($post['barcode']) ? trim($post['barcode']) : '';
        $locker_no = isset($post['locker_no']) ? trim($post['locker_no']) : '';
        $date_of_hire = isset($post['date_of_hire']) ? trim($post['date_of_hire']) : '';
        $image = isset($post['image']) ? trim($post['image']) : '';                
        $jobzone_id = isset($post['jobzone_id']) ? trim($post['jobzone_id']) : '';                
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $employee_id != "" && $firstname != "" && $lastname != "" && $jobzone_id > 0)
        {
            $query  = 'SELECT j.id FROM `ppe_jobrole` as j 
                       JOIN `ppe_company_jobrole_map` as cjm ON cjm.`jobrole_id` = j.`id` AND cjm.`status` = 1
                       WHERE cjm.`company_id` = "'.$company_id.'"';                   
            $result =  $obj_service->sql_query($query);
            $jobroles = $obj_service->fetch_array_multiple($result);
            
            $jobzones = array();
            foreach($jobroles as $jobrole) {
                $jobzones[] = $jobrole['id'];
            }

            if(in_array($jobzone_id, $jobzones)) 
            {
                $condition = '';
                if($user_id > 0) {
                    $condition .= " AND `app_user_id` != '".$user_id."' ";
                }
                
                if($barcode != "") {
                    $barcondition = " OR `barcode` = '".$barcode."' ";   
                } 
                
                $query  = 'SELECT count(*) as total FROM `ppe_app_users`
                           WHERE `is_deleted` = 0 AND `company_id` = "'.$company_id.'" AND ( `employee_id` = "'.strtolower(mysql_real_escape_string($employee_id)).'" '.$barcondition.' ) '.$condition;                  
                
                $result = $obj_service->sql_query($query);
                $employees  = $obj_service->fetch_array_multiple($result);

                if(!$employees[0]['total'] && $password === $confirm_password) 
                {                                                            
                    $password = md5($password);
                                         
                    if($user_id > 0) 
                    {                        
                        if($confirm_password != '') {
                            $password = " `password` = '".$password."', ";
                        } else {
                            $password = "";
                        }
                        
			/*Create array for sending a curl call*/
                        $dataArray = array(
                            'password'      => $password,
                            'firstname'     => mysql_real_escape_string($firstname),
                            'lastname'      => mysql_real_escape_string($lastname),
                            'jobzone_id'    => mysql_real_escape_string($jobzone_id),
                            'barcode'       => mysql_real_escape_string($barcode),
                            'locker_no'     => mysql_real_escape_string($locker_no),
                            'image'    => $company_id."_".mysql_real_escape_string($employee_id).".jpg",
                            'date_of_hire'  => $date_of_hire,
                            'app_user_id'   => $user_id,
                            'combination_no'=> isset($post['combination_no']) ? trim($post['combination_no']) : '',
                            'department_no'=> isset($post['department_no']) ? trim($post['department_no']) : '',
                            'tableName'     => 'app_users',
                        );

                        //$dataRep = dbReplicant::updateAppUser( $appurl, $dataArray);

                        $dataRep = dataMigrate::updateAppUser($dataArray);
                        
                        /*Create array for sending a curl call */

                        /*$query = "UPDATE `ppe_app_users` SET $password `firstname` = '".mysql_real_escape_string($firstname)."',
                                 `lastname` = '".mysql_real_escape_string($lastname)."',
                                 `jobzone_id` = '".$jobzone_id."', `barcode` = '".$barcode."',
                                 `locker_no` = '".mysql_real_escape_string($locker_no)."',
                                 `image` = '".$company_id."_".mysql_real_escape_string($employee_id).".jpg', `date_of_hire` = '".$date_of_hire."'
                                 WHERE `app_user_id` = '".$user_id."'";
                        $userRegistration = $obj_service->sql_query($query) or die($query.": UPDATE Failed REASON: ".mysql_error());*/

                        $inserted_id = $user_id;
                    } 
                    else
                    {
			            
                        /*Create array for sending a curl call*/
                        $dataArray = array(
                            'password'      => $password,
                            'firstname'     => mysql_real_escape_string($firstname),
                            'lastname'      => mysql_real_escape_string($lastname),
                            'jobzone_id'    => mysql_real_escape_string($jobzone_id),
                            'company_id'    => mysql_real_escape_string($company_id),
                            'employee_id'    => mysql_real_escape_string($employee_id),
                            'barcode'       => mysql_real_escape_string($barcode),
                            'locker_no'     => mysql_real_escape_string($locker_no),
                            'image'    => $company_id."_".mysql_real_escape_string($employee_id).".jpg",
                            'date_of_hire'  => $date_of_hire,
                            'app_user_id'   => $user_id,
                            'tableName'     => 'app_users',
                        );

                        //$dataRep = dbReplicant::updateAppUser( $appurl, $dataArray);
                        $inserted_id = dataMigrate::updateAppUser($dataArray);			

                        /*$query = "INSERT INTO `ppe_app_users` (`app_user_id`, `employee_id`, `password`, `firstname`, `lastname`, `jobzone_id`,`company_id`, `barcode`, `locker_no`, `date_of_hire`, `image`, `registered_at`) VALUES 
                                            ('','".mysql_real_escape_string($employee_id)."','".$password."','".mysql_real_escape_string($firstname)."','".mysql_real_escape_string($lastname)."',
                                                '".$jobzone_id."','".$company_id."','".$barcode."','".mysql_real_escape_string($locker_no)."','".$date_of_hire."','".$company_id."_".mysql_real_escape_string($employee_id).".jpg', '".$datetime."')";
                        $userRegistration = $obj_service->sql_query($query) or die($query.": INSERT Failed REASON: ".mysql_error());
                        $inserted_id = mysql_insert_id();*/
                    }

                    if($inserted_id)
                    {                        
                        if($image != '') 
                        {
                            $image = str_replace(' ', '+', $image);    
                            $image = base64_decode($image);
                            $file = dirname(dirname(__FILE__)).'/images/app_users/'. $company_id.'_'.mysql_real_escape_string($employee_id) . '.jpg';
                            $success = file_put_contents($file, $image);
                        }
                                               
                        if($user_id > 0) {
                            $arrResultDetails['message'] = 'Employee details successfully updated';
                        } else {
                            $arrResultDetails['message'] = 'Employee details successfully saved';
                        }
                        $arrResultDetails['user'] = general::getemployeeinfo($company_id, $inserted_id);
                        $arrResultDetails['registered_id'] = $inserted_id;
                        $arrResultDetails['success'] = 1;        
                    }
                    else
                    {
                        $arrResultDetails['message'] = 'Registration Failed. Please try again.';
                        $arrResultDetails['success'] = 0;                        
                    }
                }
                else if ($password !== $confirm_password)
                {
                    $arrResultDetails['message']  = 'Password/Confirm Password should be same';
                    $arrResultDetails['success']  = 0;   
                } 
                else 
                {
                    if($barcode != "") {
                        $arrResultDetails['message']  = 'EmployeeId/Barcode already registered.';
                    } else {
                        $arrResultDetails['message']  = 'EmployeeId already registered.';
                    }
                    $arrResultDetails['success']  = 0;
                }
            }
            else
            {
                $arrResultDetails['message'] = 'Invalid jobzone.';
                $arrResultDetails['success'] = 0;
            }
        }
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    case 'searchregisteredemployee' :
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $search = isset($post['search']) ? trim($post['search']) : '';        

        if($company_id > 0 && $search != "")
        {                    
            $search = mysql_real_escape_string($search);
            $query  = ' SELECT u.*, j.job_title,  
                       IF(u.image != "", CONCAT("'.$appurl.'images/app_users/",u.image), "") as image, barcode as barcode 
                       FROM `ppe_app_users` as u
                       JOIN `ppe_jobrole` as j ON u.jobzone_id = j.id 
                       WHERE `company_id` = "'.$company_id.'"
                       AND u.block = 0 AND u.is_deleted = 0
                       AND ( `firstname` LIKE "%'.$search.'%"
                       OR `lastname` LIKE "%'.$search.'%"
                       OR `employee_id` LIKE "%'.$search.'%"
                       OR `locker_no` LIKE "%'.$search.'%"
                       OR CONCAT(firstname," ",lastname," ",employee_id) LIKE "%'.$search.'%"
                       OR CONCAT(lastname," ",firstname," ",employee_id) LIKE "%'.$search.'%") ';                   
            
            $result = $obj_service->sql_query($query) or die($query.": INSERT Failed REASON: ".mysql_error());
            $employee_list = $obj_service->fetch_array_multiple($result);

            if (count($employee_list)) 
            {                                
                $arrResultDetails['employees'] = $employee_list;        
                $arrResultDetails['TotalCount'] = count($employee_list);        
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['message'] = 'No Record Found';
                $arrResultDetails['success'] = 0;
            }
        } 
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    
    case 'getregisteredemployee' :
        
        //{"company_id":102, "user_id":3,"employee_id":"RJ1000","firstname":"rahuljain","lastname":"jainrahul","jobzone_id":14}
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        
        if($company_id > 0 && $user_id > 0)
        {                    
            $query  = 'SELECT *, IF(image != "", CONCAT("'.$appurl.'images/app_users/",image), "") as image, barcode as barcode 
                       FROM `ppe_app_users` 
                       WHERE `company_id` = "'.$company_id.'"
                       AND block = 0 AND is_deleted = 0 
                       AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array_multiple($result);

            if (count($employee)) 
            {                                
                $arrResultDetails['employee'] = $employee[0];                        
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['message'] = 'Invalid User';
                $arrResultDetails['success'] = 0;
            }
        } 
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;
    

    case 'loginauth' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $employee_id = isset($post['employee_id']) ? trim($post['employee_id']) : '';                
        $password = isset($post['password']) ? trim($post['password']) : '';
        $barcode = isset($post['barcode']) ? trim($post['barcode']) : '';        
        $password = md5($password);

        if( $company_id > 0 && ( ($employee_id != "" && $password != "") || $barcode != "") )
        {                    
            
            $query  = ' SELECT * from `ppe_company_info` where id = "'.$company_id.'"';                               
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $companyData = $obj_service->fetch_array($result);
            
            if($barcode != '' && $companyData['appaccessmethod'] > 0) {
                $condition = ' AND `barcode` = "'.$barcode.'" ';
            } else if($employee_id != "" && $companyData['appaccessmethod'] > 0) {
                $condition = ' AND `employee_id` = "'.mysql_real_escape_string($employee_id).'" ';
            } else {
                $condition = ' AND `employee_id` = "'.mysql_real_escape_string($employee_id).'" AND `password` = "'.$password.'" ';             
            }                       
            
            $query  = ' SELECT au.*, IF(image != "", CONCAT("'.$appurl.'images/app_users/",image), "") as image, image as imagename, j.job_title
                       FROM `ppe_app_users` as au
                       JOIN `ppe_jobrole` as j ON j.id = au.jobzone_id
                       WHERE is_deleted = 0 AND `company_id` = "'.$company_id.'" '.$condition;                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $user = $obj_service->fetch_array_multiple($result);

            if (count($user) && $user[0]['block'] == 0) 
            {                                                
                $query  = 'SELECT count(*) as total
                       FROM `ppe_app_orders`
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `user_id` = "'.$user[0]['app_user_id'].'" AND issue_flag = 1 AND return_flag = 0';                   
                        
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
                $issuedata = $obj_service->fetch_array_multiple($result);
                
                //Show Return button
                $arrResultDetails['showreturn'] = 0;    
                if ($issuedata[0]['total'] > 0) {                                                                                       
                    $arrResultDetails['showreturn'] = 1;
                }

                //Check image exist or not
                $arrResultDetails['is_image'] = 0;                        
                if( file_exists(dirname(dirname(__FILE__)).'/images/app_users/'.$user[0]['imagename']) ) {
                    $arrResultDetails['is_image'] = 1;                        
                }                               

                $arrResultDetails['message'] = 'Authenticated Successfully.';
                $arrResultDetails['user'] = $user[0];                        
                $arrResultDetails['success'] = 1;

            } else if ($user[0]['block'] == 1) {
                $arrResultDetails['message'] = 'Authentication Blocked. Please contact service manager.';
                $arrResultDetails['success'] = 0;
            } else {
                $arrResultDetails['message'] = 'Invalid User. Authentication Failed.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    case 'assignimagetoemployee' :
    
        $postdata = file_get_contents('php://input');
        $post  = json_decode($postdata,true);                
        $post['tableName'] = 'app_users';        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $employee_id = isset($post['employee_id']) ? trim($post['employee_id']) : '';        
        $image = isset($post['image']) ? trim($post['image']) : '';
        $emp_sign = isset($post['emp_sign']) ? trim($post['emp_sign']) : '';

        if($company_id > 0 && $user_id > 0 && $image != '')
        {                     

            dataMigrate::updateAppUserImage($post);          

            /*$set = "";
            if ($image != '') {
                $image = str_replace(' ', '+', $image);
                $image = base64_decode($image);
                $file = dirname(dirname(__FILE__)) . '/images/app_users/' . $company_id . '_' . $employee_id . '.jpg';
                unlink($file);
                $success = file_put_contents($file, $image);
            }

            if ($emp_sign != '') {
                $emp_sign = str_replace(' ', '+', $emp_sign);
                $emp_sign = base64_decode($emp_sign);
                $emp_sign_file = dirname(dirname(__FILE__)) . '/images/app_users_signature/' . $company_id . '_' . $employee_id . '.jpg';
                $emp_signsuccess = file_put_contents($emp_sign_file, $emp_sign);
                $set = ", `signature` = '" . $company_id . '_' . mysql_real_escape_string($employee_id) . ".jpg' "; 
            }

            $query = "UPDATE `ppe_app_users` SET `image` = '" . $company_id . '_' . mysql_real_escape_string($employee_id) . ".jpg' "
                       .$set. 
                      "WHERE `app_user_id` = '".$user_id."' AND `company_id` = '".$company_id."' ";
            $updateImage = $obj_service->sql_query($query) or die($query.": UPDATE Failed REASON: ".mysql_error());*/    
            // Update Webuser function
            //$post['image'] = $company_id.'_'.mysql_real_escape_string($employee_id) . '.jpg';
            
            //general::updateApptoWebuser($post);

            $file = dirname(dirname(__FILE__)) . '/images/app_users/' . $company_id . '_' . $employee_id . '.jpg';

            if(file_exists($file)) { 
                $arrResultDetails['message'] = 'Employee updated successfully';
                $arrResultDetails['success'] = 1;
            } else {
                $arrResultDetails['message'] = 'Failed to update image.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    //Update Locker#
    case 'updatelockerno' :

        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $locker_no = isset($post['locker_no']) ? trim($post['locker_no']) : '';
        $department_no = isset($post['department_no']) ? trim($post['department_no']) : '';
        $combination_no = isset($post['combination_no']) ? trim($post['combination_no']) : '';
        
        if($company_id > 0 && $user_id > 0)
        {                                                        
            /*Create array for sending a curl call*/
    		$dataArray = array(		    
    		    'locker_no'     => mysql_real_escape_string($locker_no),
    		    'department_no' => mysql_real_escape_string($department_no), 
    		    'combination_no'=> mysql_real_escape_string($combination_no),		    
    		    'app_user_id'   => $user_id,
    		    'tableName'     => 'app_users',
    		);

            $inserted_id = dataMigrate::updateAppUser($dataArray);			

    	    /*$query = "UPDATE `ppe_app_users` SET `locker_no` = '".mysql_real_escape_string($locker_no)."', 
                      `department_no` = '".mysql_real_escape_string($department_no)."', 
                      `combination_no` = '".mysql_real_escape_string($combination_no)."'
                      WHERE `app_user_id` = '".$user_id."' AND `company_id` = '".$company_id."' ";
            $updateLocker = $obj_service->sql_query($query) or die($query.": UPDATE Failed REASON: ".mysql_error());*/
            
            $query  = 'SELECT locker_no, department_no, combination_no FROM `ppe_app_users` 
                       WHERE is_deleted = 0 AND `company_id` = "'.$company_id.'" AND `app_user_id` = "'.$user_id.'" ';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $user = $obj_service->fetch_array($result);

            if($user['locker_no'] == $locker_no && $user['department_no'] == $department_no && $user['combination_no'] == $combination_no) {                                                        
                $arrResultDetails['profile'] = $user;
                $arrResultDetails['message'] = 'Profile updated successfully.';
                $arrResultDetails['success'] = 1;
            } else {
                $arrResultDetails['message'] = 'Error in update Locker#.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    case 'checkhomeforavailablezones': 
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        
        if($company_id > 0 && $user_id > 0)
        {            
            $query  = 'SELECT * FROM `ppe_app_users` 
                       WHERE is_deleted = 0 AND `company_id` = "'.$company_id.'" AND `app_user_id` = "'.$user_id.'" ';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $user = $obj_service->fetch_array($result);

            if($user['jobzone_id'] > 0)
            {                
                $appurl = general::appurl().'components/com_jshopping/files/img_categories/';
                $shieldArray = range(13,17);
                $shieldString = implode(",",$shieldArray);
                $query  = 'SELECT category_id, category_image as image, `name_en-GB` as name
                       FROM `ppe_jshopping_categories` 
                       WHERE category_publish = 1 AND category_parent_id = 0 
                       AND category_id NOT IN ('.$shieldString.')
                       ORDER BY category_id ASC';                   
                
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
                $categoryData = $obj_service->fetch_array_multiple($result);

                //(START) Check Products in Each Zone
                $homezones = array();                
                $homezones[0]['category_id'] = 1;
                $homezones[0]['name'] = 'PPE Zone';
                if(file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_categories/ppeshield.png')) {
                    $homezones[0]['image'] = $appurl.'ppeshield.png';
                } else {
                    $homezones[0]['image'] = '';
                }                
                $homezones[0]['available'] = 0;
                foreach(range(13,17) as $bodypart) 
                {                    
                    if($homezones['shield']['available'] == 1) continue;                     
                    if( general::countproductlist($bodypart, $user['jobzone_id'], $company_id) ) {
                        $homezones[0]['available'] = 1;
                    }            
                }

                foreach($categoryData as $key => $data) 
                {                    
                    if($data['image'] != '' && file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_categories/'.$data['image'])) {
                        $data['image'] = $appurl.$data['image'];
                    } else {
                        $data['image'] = '';
                    }
                    
                    if( general::countproductlist($data['category_id'], $user['jobzone_id'], $company_id) ) {
                        $data['available'] = 1;
                    } else {
                        $data['available'] = 0;
                    }
                    $homezones[] = $data;
                }               
                /*if( count(general::getproductlist(50, $user['jobzone_id'], $company_id) )) {
                    $arrResultDetails['showToolzone'] = 1;
                }
                if( count(general::getproductlist(100, $user['jobzone_id'], $company_id) )) {
                    $arrResultDetails['showEquipmentzone'] = 1;
                }
                if( count(general::getproductlist(150, $user['jobzone_id'], $company_id) )) {
                    $arrResultDetails['showTechnologyzone'] = 1;
                }*/

                $query  = 'SELECT count(*) as total
                       FROM `ppe_app_orders`
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `user_id` = "'.$user_id.'" AND issue_flag = 1 AND return_flag = 0';                   
                        
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
                $issuedata = $obj_service->fetch_array($result);
                
                //Show Return button
                $arrResultDetails['showreturn'] = 0;    
                if ($issuedata['total'] > 0) {                                                                                       
                    $arrResultDetails['showreturn'] = 1;
                }

                $arrResultDetails['homezones']  = $homezones; 
                $arrResultDetails['user'] = general::getemployeeinfo($company_id, $user_id);
                $arrResultDetails['success']  = 1; 
                //(END) Check Products in Each Zone
            }
            else
            {
                $arrResultDetails['message']  = 'Invalid User Details.';
                $arrResultDetails['success']  = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;
    
    case 'getproductlist' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $bodypart = isset($post['bodypart']) ? trim($post['bodypart']) : '';
                
        if($company_id > 0 && $user_id > 0 && $bodypart > 0)
        {                                
            $query  = ' SELECT * FROM `ppe_app_users` 
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array_multiple($result);

            $productdata = general::getproductlist($bodypart, $employee[0]['jobzone_id'], $company_id);            
            
            //Featured Product            
            /*$featured_product = array();
            $regular_product = array();
            foreach($productdata as $p_key => $product) {
                if($product['is_featured'] == 1) {
                    $featured_product[] = $product;
                } else {
                    $regular_product[] = $product;
                }
            }

            $productdata = array_merge($featured_product, $regular_product);*/

	    //Product display ordering
            $new_array = array();
            foreach($productdata as $p_key => $product) {
                $ordering = $product['display_order_no'];
                if($product['display_order_no'] == '') {
                    $ordering = '1000000';
                }
                $new_array[$ordering][$product['product_id']] = $product;
            }            
            ksort($new_array);
            
            $productdata = array();
            foreach($new_array as $sortedproducts) {                
                ksort($sortedproducts);
                $productdata = array_merge($productdata, $sortedproducts);            
            }

            if (count($productdata)) 
            {                                   
                $arrResultDetails['products'] = $productdata;                        
                $arrResultDetails['TotalCount'] = count($productdata);
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['message'] = 'No product found.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    //For employee to request products to issue
    case 'requesttoissueproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $products = is_array($post['products']) ? $post['products'] : array();
        $wishlist = isset($post['wishlist']) ? trim($post['wishlist']) : 0;
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $user_id > 0 && count($products) > 0)
        {                                                        
            //Remove from order history
            general::removeTransactionFromOrderHistory($post);
            
            //Remove old requested products to issue
            $query  = " DELETE from `ppe_app_orders` WHERE
                            company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_flag = 0";                                           
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

            //Remove old wishlist
            if($wishlist == 1) {
                $query  = " DELETE from `ppe_app_wishlist` WHERE
                            company_id = '".$company_id."' AND user_id = '".$user_id."' ";                               
                
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            }
            
            $non_returnable_counter = 0;
            foreach($products as $pk => $product) 
            {   
                $attribute_details = array();
                $product_dependent_attr_id = 0;
                foreach($product['attribute'] as $attr_key => $attr_value) 
                {
                    if(isset($attr_value['attr_title']) && isset($attr_value['value_title'])) {            
                        $attribute_details[] = $attr_value['attr_title'].":".$attr_value['value_title'];
                    }

                    if(isset($attr_value['is_dependent']) && $attr_value['is_dependent'] == true 
                         && isset($attr_value['product_attr_id']) && $attr_value['product_attr_id'] > 0) 
                    {
                        $product_dependent_attr_id = $attr_value['product_attr_id'];
                    }
                }
                
                if(count($attribute_details)) {
                    $attribute_details = implode(' <br/> ',$attribute_details);
                } else {
                    $attribute_details = '';
                }
                
                
                $attributes = '';
                if($product['attribute'] != '') {
                    $attributes = serialize($product['attribute']);
                }
                        
                //Add product to issue         
                $query  = ' SELECT * FROM `ppe_jshopping_products` 
                           WHERE `product_id` = "'.$product['product_id'].'"';                                   
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                
                $productData = $obj_service->fetch_array($result);                               
                
                if($productData['is_non_returnable'] == 1) {
                    $query  = " INSERT into `ppe_app_orders` 
                                   (issue_id, company_id, user_id, product_id, attribute_details, attributes, product_attr_id,                  issue_requested_at, issue_flag, issue_confirmed_at, return_flag, is_completed) 
                                   VALUES 
                                   ('', '".$company_id."', '".$user_id."', '".$product['product_id']."', '".mysql_real_escape_string($attribute_details)."', '".$attributes."', '".$product_dependent_attr_id."', '".$datetime."', '1', '".$datetime."', '1','1') ";                   
                    
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                      
                    $insert_id = mysql_insert_id();
                    $non_returnable_counter++;

                } else {
                    $query  = " INSERT into `ppe_app_orders` 
                               (issue_id, company_id, user_id, product_id, attribute_details, attributes, product_attr_id, issue_requested_at, issue_flag) 
                               VALUES 
                               ('', '".$company_id."', '".$user_id."', '".$product['product_id']."', '".mysql_real_escape_string($attribute_details)."', '".$attributes."', '".$product_dependent_attr_id."', '".$datetime."', '0') ";                   
                    
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                      
                    $insert_id = mysql_insert_id();
                }  
                
                //Add product to wishlist
                if($wishlist == 1)
                {
                    $query  = " INSERT into `ppe_app_wishlist` 
                           (wid, company_id, user_id, product_id, attribute_details, attributes, product_attr_id, wished_at) 
                           VALUES 
                           ('', '".$company_id."', '".$user_id."', '".$product['product_id']."', '".mysql_real_escape_string($attribute_details)."', '".$attributes."', '".$product_dependent_attr_id."', '".$datetime."') ";                   
                
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
                }

                //Update post products to Order History to input
                $post['products'][$pk]['detail'] = $productData;
                $post['products'][$pk]['attributes'] = $attributes;
                $post['products'][$pk]['attribute_details'] = $attribute_details;
                $post['products'][$pk]['app_order_id'] = $insert_id;
            }                                                                        
                                
            if(isset($insert_id) && $insert_id > 0) 
            {
                // Add transaction to company 
                $query  = " INSERT into `ppe_app_transactions` 
                       (trans_id, company_id, app_user_id, trans_date, trans_type) 
                       VALUES 
                       ('', '".$company_id."', '".$user_id."', '".$datetime."', 'IN') ";                   
            
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

                //Add this transaction into order history - RJ
                $post['non_returnable_counter'] = $non_returnable_counter;
                general::addTransactionIntoOrderHistory($post);
                
                $arrResultDetails['message'] = 'Confirmed.';
                $arrResultDetails['success'] = 1;         
            }
            else
            {
                $arrResultDetails['message'] = 'Failed to issue product. Please try again.';
                $arrResultDetails['success'] = 0;            
            }

        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;
    
    
    //For employee to request wishlist products to issue
    case 'requestwishlistproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';                
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $user_id > 0)
        {                                                                            
            $query  = 'SELECT aw.*, p.`name_en-GB` as product_title, p.image, p.unlimited, p.product_quantity, p.product_price,
                       0 as product_reserved, p.`model_no`
                       FROM `ppe_app_wishlist` aw
                       JOIN `ppe_jshopping_products`as p ON aw.product_id = p.product_id                        
                       WHERE aw.`company_id` = "'.$company_id.'" 
                       AND aw.`user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $productlist = $obj_service->fetch_array_multiple($result);
            
            $issuedata = general::includeProductStock($productlist, $product_array = array(), 1);
            /*$imageurl = $appurl.'components/com_jshopping/files/img_products/';
            foreach($issuedata as $key => $value) 
            {
                $issuedata[$key]['product_title'] = utf8_encode($value['product_title']);
                if(file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_products/thumb_'.$value['image'])) {
                    $issuedata[$key]['image'] = utf8_encode($imageurl.'thumb_'.$value['image']);
                } else {
                    $issuedata[$key]['image'] = '';
                }                
            }*/

            if(count($issuedata) > 0) {
                $arrResultDetails['products']  = $issuedata;
                $arrResultDetails['success']  = 1;   
            } else {
                $arrResultDetails['message']  = 'No product(s) found in your wishlist.';
                $arrResultDetails['success']  = 0;   
            }            
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    // For service Manager to get employee list wanted to issue products
    case 'getemployeestoissueproducts' :
                    
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
                                
        if($company_id > 0)
        {                                            
            $query  = 'SELECT au.*, ao.issue_requested_at,
                       IF(au.image != "", CONCAT("'.$appurl.'images/app_users/",au.image), "") as image, barcode as barcode 
                       FROM `ppe_app_orders` as ao 
                       JOIN `ppe_app_users`as au ON ao.user_id = au.app_user_id                        
                       WHERE ao.`company_id` = "'.$company_id.'" 
                       AND ao.issue_flag = 0 AND ao.return_flag = 0 
                       GROUP BY au.app_user_id
                       ORDER BY ao.issue_requested_at';                   
                        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employeelist = $obj_service->fetch_array_multiple($result);
                                    
            if (count($employeelist)) 
            {                                   
                $arrResultDetails['employees'] = $employeelist;                                        
                $arrResultDetails['TotalCount'] = count($employeelist);
                $arrResultDetails['success'] = 1;

            } else {                        
                $arrResultDetails['message'] = 'No employee found to issue product.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;



    //For servicemanager to list employee products requested to issue
    case 'getemployeeproductstoissue' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
                        
        if($company_id > 0 && $user_id > 0)
        {                                
            $query  = ' SELECT *, IF(image != "", CONCAT("'.$appurl.'images/app_users/",image), "") as image, barcode as barcode  
                       FROM `ppe_app_users` 
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array_multiple($result);

            $query  = 'SELECT ao.issue_id, ao.attribute_details, ao.issue_requested_at, p.product_id, p.`name_en-GB` as product_title, p.image  
                       FROM `ppe_app_orders` as ao 
                       JOIN `ppe_jshopping_products`as p ON ao.product_id = p.product_id                        
                       WHERE ao.`company_id` = "'.$company_id.'" 
                       AND ao.`user_id` = "'.$user_id.'" AND ao.issue_flag = 0 AND ao.return_flag = 0';                   
                        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $issuedata = $obj_service->fetch_array_multiple($result);

            $imageurl = $appurl.'components/com_jshopping/files/img_products/';
            foreach($issuedata as $key => $value) 
            {
                $issuedata[$key]['product_title'] = utf8_encode($value['product_title']);
                if(file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_products/thumb_'.$value['image'])) {
                    $issuedata[$key]['image'] = utf8_encode($imageurl.'thumb_'.$value['image']);
                } else {
                    $issuedata[$key]['image'] = '';
                }                
            }
            
            if (count($issuedata)) 
            {                                   
                $arrResultDetails['employee'] = $employee[0];                        
                $arrResultDetails['issueproducts'] = $issuedata;                        
                $arrResultDetails['TotalCount'] = count($issuedata);
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['employee'] = $employee[0];                        
                $arrResultDetails['message'] = 'No issue product found.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    // For service Manager to approve employee requested products to issue
    case 'approveissueproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $approved = is_array($post['approved']) ? $post['approved'] : array();
        $disapproved = is_array($post['disapproved']) ? $post['disapproved'] : array();
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $user_id > 0 && (count($approved) || count($disapproved)) )
        {                                                        
            $product_avaibility = general::checkAvailableQtyToApprove($approved);
            if(count($product_avaibility) == 0) 
            {
                $qtyalertproducts = array();
                foreach($approved as $issue_id) 
                {                   
                    $query  = " UPDATE `ppe_app_orders` SET issue_flag = 1, issue_confirmed_at = '".$datetime."' WHERE
                                company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_id = '".$issue_id."' ";                               
                    
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
                    $qtyalertproducts[] = general::changeProductQTYinStockOnReturn($issue_id, 1, "-");
                }                                    
                
                //Minimum/maximum qty alert
                //general::send_quantity_alert($qtyalertproducts);
                
                foreach($disapproved as $issue_id) 
                {                   
                    //Remove transaction from app orders
                    $query  = " DELETE from `ppe_app_orders` WHERE
                                company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_id = '".$issue_id."' ";                               
                    
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

                    //Remove transaction from order item 
                    $query  = "DELETE FROM `ppe_jshopping_order_item` WHERE 
                               is_non_returnable = 0 AND app_order_id = '".$issue_id."'";                                                       
                    $obj_service->sql_query($query);
                }            
                
                //Update transaction into order history - RJ
                general::updateTransactionIntoOrderHistory($post);
                
                $arrResultDetails['message'] = 'Details successfully saved.';
                $arrResultDetails['success'] = 1;         
            }
            else 
            {
                $arrResultDetails['message'] = implode("\n",$product_avaibility);
                $arrResultDetails['success'] = 0;         
            }
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;



    //For employee to select products to return
    case 'getproductstoreturn' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
                        
        if($company_id > 0 && $user_id > 0)
        {                                
            $query  = ' SELECT *, IF(image != "", CONCAT("'.$appurl.'images/app_users/",image), "") as image, barcode as barcode 
                       FROM `ppe_app_users` 
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array_multiple($result);

            $query  = 'SELECT ao.issue_id, ao.attribute_details, ao.issue_requested_at, p.product_id, p.`name_en-GB` as product_title, p.image  
                       FROM `ppe_app_orders` as ao 
                       JOIN `ppe_jshopping_products`as p ON ao.product_id = p.product_id                        
                       WHERE ao.`company_id` = "'.$company_id.'" 
                       AND ao.`user_id` = "'.$user_id.'" AND ao.issue_flag = 1 AND ao.return_flag = 0';                   
                        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $issuedata = $obj_service->fetch_array_multiple($result);

            $imageurl = $appurl.'components/com_jshopping/files/img_products/';
            foreach($issuedata as $key => $value) 
            {
                $issuedata[$key]['product_title'] = utf8_encode($value['product_title']);
                if(file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_products/thumb_'.$value['image'])) {
                    $issuedata[$key]['image'] = utf8_encode($imageurl.'thumb_'.$value['image']);
                } else {
                    $issuedata[$key]['image'] = '';
                }                
            }
            
            if (count($issuedata)) 
            {                                   
                $arrResultDetails['employee'] = $employee[0];                        
                $arrResultDetails['issueproducts'] = $issuedata;                        
                $arrResultDetails['TotalCount'] = count($issuedata);
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['employee'] = $employee[0];                        
                $arrResultDetails['message'] = 'No issue product found.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;



    //For Employee to request return products 
    case 'requesttoreturnproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $return = is_array($post['return']) ? $post['return'] : array();        
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $user_id > 0 && count($return) > 0)
        {                                                        
            foreach($return as $issue_id) 
            {                   
                $query  = " UPDATE `ppe_app_orders` SET return_requested_at = '".$datetime."', return_flag = 1 WHERE
                            company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_id = '".$issue_id."' ";
                
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            }

            // Add transaction to company 
            $query  = " INSERT into `ppe_app_transactions` 
                   (trans_id, company_id, app_user_id, trans_date, trans_type) 
                   VALUES 
                   ('', '".$company_id."', '".$user_id."', '".$datetime."', 'OUT') ";                   

            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                                                                     
            
            $arrResultDetails['message'] = 'Return requested successfully.';
            $arrResultDetails['success'] = 1;                     
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;



    // For service Manager to list employees wanted to return products
    case 'getemployeestoreturnproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
                                
        if($company_id > 0)
        {                                            
            $query  = 'SELECT au.*, IF(au.image != "", CONCAT("'.$appurl.'images/app_users/",au.image), "") as image, barcode as barcode , ao.return_requested_at
                       FROM `ppe_app_orders` as ao 
                       JOIN `ppe_app_users`as au ON ao.user_id = au.app_user_id
                       WHERE ao.`company_id` = "'.$company_id.'"                        
                       AND ao.issue_flag = 1 AND ao.return_flag = 1 AND ao.is_completed = 0
                       GROUP BY au.app_user_id
                       ORDER BY return_requested_at';                   
                        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employeelist = $obj_service->fetch_array_multiple($result);

            if (count($employeelist)) 
            {                                   
                $arrResultDetails['employees'] = $employeelist;                                        
                $arrResultDetails['TotalCount'] = count($employeelist);
                $arrResultDetails['success'] = 1;

            } else {                
                $arrResultDetails['message'] = 'No employee found to return products.';
                $arrResultDetails['success'] = 0;
            }            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;



    // For service manager to approve return products by employee
    case 'getemployeeproductstoreturn' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';                      
        
        if($company_id > 0 && $user_id > 0)
        {                                            
            $query  = ' SELECT *, IF(image != "", CONCAT("'.$appurl.'images/app_users/",image), "") as image, barcode as barcode 
                       FROM `ppe_app_users` 
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array_multiple($result);

            $query  = 'SELECT ao.issue_id, ao.user_id, ao.attribute_details, ao.qty,
                       ao.return_requested_at, p.product_id, p.`name_en-GB` as product_title, p.image  
                       FROM `ppe_app_orders` as ao 
                       JOIN `ppe_jshopping_products`as p ON ao.product_id = p.product_id                        
                       WHERE ao.`company_id` = "'.$company_id.'" 
                       AND ao.`user_id` = "'.$user_id.'" 
                       AND ao.issue_flag = 1 AND ao.return_flag = 1 AND ao.is_completed = 0
                       ORDER BY return_requested_at';                   
                        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $returnproducts = $obj_service->fetch_array_multiple($result);
            
            $imageurl = $appurl.'components/com_jshopping/files/img_products/';
            foreach($returnproducts as $key => $value) 
            {
                $returnproducts[$key]['product_title'] = utf8_encode($value['product_title']);
                if(file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_products/thumb_'.$value['image'])) {
                    $returnproducts[$key]['image'] = utf8_encode($imageurl.'thumb_'.$value['image']);
                } else {
                    $returnproducts[$key]['image'] = '';
                }                
            }

            if (count($returnproducts)) 
            {                                   
                $arrResultDetails['employee'] = $employee[0];                        
                $arrResultDetails['returnproducts'] = $returnproducts;                        
                $arrResultDetails['TotalCount'] = count($returnproducts);
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['employee'] = $employee[0];                        
                $arrResultDetails['message'] = 'No product found for return.';
                $arrResultDetails['success'] = 0;
            }            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;



    //For service manager to approve return products 
    case 'approvereturnproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $returned = is_array($post['returned']) ? $post['returned'] : array();        
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $user_id > 0 && count($returned) > 0 )
        {                                                        
            $qtyalertproducts = array();
            foreach($returned as $key => $value) 
            {                   
                $query  = " UPDATE `ppe_app_orders` SET return_confirmed_at = '".$datetime."', is_completed = 1, return_comments = '".mysql_real_escape_string($value['comments'])."',
                            is_defected = '".$value['is_defected']."', is_lost = '".$value['is_lost']."'
                            WHERE company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_id = '".$value['issue_id']."' ";
                
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

                if($value['is_lost'] != 1) {
                    $qtyalertproducts[] = general::changeProductQTYinStockOnReturn($value['issue_id'], 1, "+");
                }
            }                                                                    
            
            //Minimum/maximum qty alert
            //general::send_quantity_alert($qtyalertproducts);

            $arrResultDetails['message'] = 'Return Accepted Successfully.';
            $arrResultDetails['success'] = 1;         
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    //For service manager to get report of Today's out products
    case 'gettodaysoutproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $search = isset($post['search']) ? trim($post['search']) : '';        
        $date = date('Y-m-d');
        //$date = '2015-05-11';

        if($company_id > 0)
        {                                                                    

            $query  = " SELECT ao.issue_id, au.employee_id, au.firstname, au.lastname, p.`name_en-GB` as product_title, p.product_id, p.product_ean as product_code,
                        ao.attribute_details, ao.qty, ao.issue_confirmed_at as outtime, ao.return_confirmed_at as intime, ao.return_comments as comments,
                        IF(au.image != '', CONCAT('".$appurl."images/app_users/',au.image), '') as image, CONCAT('') as barcode
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id
                        JOIN `ppe_jshopping_products` as p ON p.product_id = ao.product_id
                        WHERE ao.company_id = '".$company_id."' AND ao.issue_flag = 1 
                        AND (p.`name_en-GB` LIKE '%".$search."%' OR p.`product_ean` LIKE '%".$search."%')
                        AND DATE(ao.issue_confirmed_at) = '".$date."' ";
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
            
            foreach($resultdata as $key => $value) {
                $resultdata[$key]['product_title'] = utf8_encode($value['product_title']);
            }
            
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['issuedata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No issue product found for today.';
                $arrResultDetails['success'] = 0;
            }                   
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    //For service manager get employee report    
    case 'getemployeereport' :
        //{"company_id":102, "from_date": 1420455771, "to_date":1436094171}
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $fromdate = isset($post['from_date']) ? trim($post['from_date']) : '';        
        $todate = isset($post['to_date']) ? trim($post['to_date']) : '';
        
        if($fromdate != '' && $todate != '') {
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
        } else {
            $fromdate = date('Y-m-d');
            $todate = date('Y-m-d');
        }

        if($company_id > 0)
        {                                                                    
            $query  = " SELECT ao.issue_id, au.employee_id, au.firstname, au.lastname, p.`name_en-GB` as product_title, p.product_id,
                        ao.attribute_details, ao.qty, ao.issue_confirmed_at as outtime, ao.return_confirmed_at as intime, ao.return_comments as comments, DATE(ao.issue_confirmed_at) as date,
                        IF(au.image != '', CONCAT('".$appurl."images/app_users/',au.image), '') as image, CONCAT('') as barcode
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id
                        JOIN `ppe_jshopping_products` as p ON p.product_id = ao.product_id
                        WHERE ao.company_id = '".$company_id."' AND ao.issue_flag = 1 
                        AND DATE(ao.issue_confirmed_at) BETWEEN '".$fromdate."' AND '".$todate."' ";
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
            
            foreach($resultdata as $key => $value) {
                $resultdata[$key]['product_title'] = utf8_encode($value['product_title']);
            }
            
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['employeedata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No record found.';
                $arrResultDetails['success'] = 0;
            }       
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    //For service manager get product report    
    case 'getproductreport' :
        //{"company_id":102, "from_date": 1420455771, "to_date":1436094171}
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $fromdate = isset($post['from_date']) ? trim($post['from_date']) : '';        
        $todate = isset($post['to_date']) ? trim($post['to_date']) : '';
        
        if($fromdate != '' && $todate != '') {
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));                        
        } else {
            $fromdate = date('Y-m-d');            
            $todate = date('Y-m-d');            
        }

        if($company_id > 0)
        {                                                                    
            $query  = " SELECT p.`name_en-GB` as product_title, p.product_id,
                        DATE(ao.issue_confirmed_at) as date,                        
                        SUM(ao.is_defected) as total_defected,
                        SUM(ao.is_lost) as total_lost,
                        SUM(IF(ao.is_completed = 1, ao.qty, ao.is_completed)) as total_return,                        
                        SUM(ao.qty) as total_count                        
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id
                        JOIN `ppe_jshopping_products` as p ON p.product_id = ao.product_id
                        WHERE ao.company_id = '".$company_id."' AND ao.issue_flag = 1 
                        AND DATE(ao.issue_confirmed_at) BETWEEN '".$fromdate."' AND '".$todate."' 
                        GROUP BY DATE(ao.issue_confirmed_at), p.product_id
                        ORDER BY DATE(ao.issue_confirmed_at) DESC";
            //count(*) as total_count                        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
            
            foreach($resultdata as $key => $value) {
                $resultdata[$key]['product_title'] = utf8_encode($value['product_title']);
            }
            
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['productdata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No record found.';
                $arrResultDetails['success'] = 0;
            }       
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    //For service manager get defective product report    
    case 'getdefectiveproductreport' :
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $fromdate = isset($post['from_date']) ? trim($post['from_date']) : '';        
        $todate = isset($post['to_date']) ? trim($post['to_date']) : '';
        
        if($fromdate != '' && $todate != '') {
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
        } else {
            $fromdate = date('Y-m-d');
            $todate = date('Y-m-d');
        }

        if($company_id > 0)
        {                                                                    
            $query  = " SELECT ao.issue_id, au.employee_id, au.firstname, au.lastname, p.`name_en-GB` as product_title, p.product_id,
                        ao.attribute_details, ao.qty, ao.issue_confirmed_at as outtime, ao.return_confirmed_at as intime, ao.return_comments as comments, DATE(ao.issue_confirmed_at) as date,
                        IF(au.image != '', CONCAT('".$appurl."images/app_users/',au.image), '') as image, CONCAT('') as barcode
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id
                        JOIN `ppe_jshopping_products` as p ON p.product_id = ao.product_id
                        WHERE ao.company_id = '".$company_id."' AND ao.is_defected = 1 AND ao.issue_flag = 1 
                        AND DATE(ao.issue_confirmed_at) BETWEEN '".$fromdate."' AND '".$todate."' ";
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
            
            foreach($resultdata as $key => $value) {
                $resultdata[$key]['product_title'] = utf8_encode($value['product_title']);
            }
            
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['productdata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No record found.';
                $arrResultDetails['success'] = 0;
            }       
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    //For service manager get defective product report    
    case 'getlostproductreport' :
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $fromdate = isset($post['from_date']) ? trim($post['from_date']) : '';        
        $todate = isset($post['to_date']) ? trim($post['to_date']) : '';
        
        if($fromdate != '' && $todate != '') {
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
        } else {
            $fromdate = date('Y-m-d');
            $todate = date('Y-m-d');
        }

        if($company_id > 0)
        {                                                                    
            $query  = " SELECT ao.issue_id, au.employee_id, au.firstname, au.lastname, p.`name_en-GB` as product_title, p.product_id,
                        ao.attribute_details, ao.qty, ao.issue_confirmed_at as outtime, ao.return_confirmed_at as intime, ao.return_comments as comments, DATE(ao.issue_confirmed_at) as date,
                        IF(au.image != '', CONCAT('".$appurl."images/app_users/',au.image), '') as image, CONCAT('') as barcode
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id
                        JOIN `ppe_jshopping_products` as p ON p.product_id = ao.product_id
                        WHERE ao.company_id = '".$company_id."' AND ao.is_lost = 1 AND ao.issue_flag = 1 
                        AND DATE(ao.issue_confirmed_at) BETWEEN '".$fromdate."' AND '".$todate."' ";
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
            
            foreach($resultdata as $key => $value) {
                $resultdata[$key]['product_title'] = utf8_encode($value['product_title']);
            }
            
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['productdata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No record found.';
                $arrResultDetails['success'] = 0;
            }       
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    
    //For service manager get specific equipment product report    
    case 'getequipmentreport' :
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $fromdate = isset($post['from_date']) ? trim($post['from_date']) : '';        
        $todate = isset($post['to_date']) ? trim($post['to_date']) : '';
        $zone = isset($post['zone']) ? trim($post['zone']) : '';

        if($fromdate != '' && $todate != '') {
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
        } else {
            $fromdate = date('Y-m-d');
            $todate = date('Y-m-d');
        }

        if($company_id > 0)
        {                                                                                
            $where = '';
            if($zone == 'ppe-zone') {
                $where .= " AND ao.zone_id = 1 ";
            } else if($zone == 'tool-zone') {
                $where .= " AND ao.zone_id IN (
                            SELECT category_id from `ppe_jshopping_categories` 
                            WHERE `alias_en-GB` = 'tool-zone'
                            ) ";
            } else {
                $where .= " AND ao.zone_id IN (
                            SELECT category_id from `ppe_jshopping_categories` 
                            WHERE `alias_en-GB` = 'maintenance-zone' OR `alias_en-GB` = 'equipment-zone'
                            ) ";
            }

            $query  = " SELECT ao.zone_id, ao.issue_id, au.employee_id, au.firstname, au.lastname, ao.department_no,
                        ao.qty, ao.issue_confirmed_at as outtime, ao.return_confirmed_at as intime,
                        if(oi.product_ean != '', oi.product_ean , oi.model_no) as part_no, ao.asset_no as equipment_no, ao.is_checked                        
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_jshopping_order_item` as oi ON oi.app_order_id = ao.issue_id
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id                        
                        WHERE ao.company_id = '".$company_id."' AND ao.issue_flag = 1 
                        AND DATE(ao.issue_confirmed_at) BETWEEN '".$fromdate."' AND '".$todate."' 
                        ".$where." ORDER BY ao.issue_confirmed_at DESC";
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
                                
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['equipmentdata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No record found.';
                $arrResultDetails['success'] = 0;
            }       
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;
    

    //For service manager get specific equipment product report    
    case 'getequipmentnumberreport' :
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $equipment_no = isset($post['equipment_no']) ? trim($post['equipment_no']) : '';        
        $fromdate = isset($post['from_date']) ? trim($post['from_date']) : '';        
        $todate = isset($post['to_date']) ? trim($post['to_date']) : '';
        
        if($fromdate != '' && $todate != '') {
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
        } else {
            $fromdate = date('Y-m-d');
            $todate = date('Y-m-d');
        }

        if($company_id > 0 && $equipment_no != '')
        {                                                                                
            $query  = " SELECT ao.zone_id, ao.issue_id, au.employee_id, au.firstname, au.lastname, ao.department_no,
                        ao.qty, ao.issue_confirmed_at as outtime, ao.return_confirmed_at as intime,
                        if(oi.product_ean != '', oi.product_ean , oi.model_no) as part_no, ao.asset_no as equipment_no,
                        p.`name_en-GB` as product_title, ao.qty * ao.price as price, ao.is_laborcost,
                        IF(ao.is_laborcost = 1, CONCAT('".$appurl."images/app_users/laborcost/',ao.issue_id,'.jpg'), '') as laborcost_invoice                                               
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_jshopping_order_item` as oi ON oi.app_order_id = ao.issue_id
                        JOIN `ppe_jshopping_products` as p ON p.product_id = ao.product_id
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id                        
                        WHERE ao.company_id = '".$company_id."' AND ao.issue_flag = 1 
                        AND DATE(ao.issue_confirmed_at) BETWEEN '".$fromdate."' AND '".$todate."'                         
                        AND ao.zone_id IN (
                            SELECT category_id from `ppe_jshopping_categories` 
                            WHERE `alias_en-GB` = 'equipment-zone'
                        ) 
                        AND ao.asset_no = '".mysql_real_escape_string($equipment_no)."'
                        ORDER BY ao.issue_confirmed_at ASC";
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
            

	    foreach($resultdata as $key => $value) {
                if(file_exists(dirname(dirname(__FILE__)).'/images/app_users/laborcost/'.$value['issue_id'].'.jpg')) {
                    $resultdata[$key]['laborcost_invoice'] = utf8_encode($appurl.'images/app_users/laborcost/'.$value['issue_id'].'.jpg');
                } else {
                    $resultdata[$key]['laborcost_invoice'] = '';
                }
            }
                    
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['equipmentdata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No record found.';
                $arrResultDetails['success'] = 0;
            }       
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;
    

    //Update check/uncheck status equipment zone
    case 'updateequipmentcheckstatus' :
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $checked = is_array($post['checked']) ? $post['checked'] : array();        
        $unchecked = is_array($post['unchecked']) ? $post['unchecked'] : array();        
        
        if( $company_id > 0 && (count($checked) > 0 OR count($unchecked) > 0) )
        {                                                                    
            if(count($checked)) {
                $checked_status = implode(",",$checked);
                $query  = " UPDATE `ppe_app_orders` SET is_checked = 1                           
                            WHERE company_id = '".$company_id."' 
                            AND issue_id IN (".$checked_status.")";
                
                $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                
            }                                
            
            if(count($unchecked)) {
                $unchecked_status = implode(",",$unchecked);
                $query  = " UPDATE `ppe_app_orders` SET is_checked = 0                           
                            WHERE company_id = '".$company_id."' 
                            AND issue_id IN (".$unchecked_status.")";
                
                $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                
            }

            $arrResultDetails['message'] = 'Updated successfully.';
            $arrResultDetails['success'] = 1;            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    /*
     *  MERGE APP SUPERVISOR AND EMPLOYEE WEB SERVICES - RJ
     */    
    
    //For service manager to approve return products 
    case 'requestandapprovereturnproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $returned = is_array($post['returned']) ? $post['returned'] : array();        
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $user_id > 0 && count($returned) > 0 )
        {                                                        
            $qtyalertproducts = array();
            foreach($returned as $key => $value) 
            {                   
                $query  = " UPDATE `ppe_app_orders` SET return_requested_at= '".$datetime."', return_flag = 1,
                            return_confirmed_at = '".$datetime."', is_completed = 1, return_comments = '".mysql_real_escape_string($value['comments'])."',
                            is_defected = '".$value['is_defected']."', is_lost = '".$value['is_lost']."'
                            WHERE company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_id = '".$value['issue_id']."' ";
                
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

                if($value['is_lost'] != 1) {
                    //$qtyalertproducts[] = general::changeProductQTYinStockOnReturn($value['issue_id'], 1, "+");
                }
            }                                                                    
            
	    // Add transaction to company 
            $query  = " INSERT into `ppe_app_transactions` 
                   (trans_id, company_id, app_user_id, trans_date, trans_type) 
                   VALUES 
                   ('', '".$company_id."', '".$user_id."', '".$datetime."', 'IN') ";                   
        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

            //Minimum/maximum qty alert
            //general::send_quantity_alert($qtyalertproducts);

            $arrResultDetails['message'] = 'Return Accepted Successfully.';
            $arrResultDetails['success'] = 1;         
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    //For Employee not returned products
    case 'getemployeenotreturnedproducts' :                                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';                      
        $real_return = isset($post['real_return']) ? trim($post['real_return']) : '0';                      

        if($company_id > 0 && $user_id > 0)
        {                                            
            $query  = ' SELECT *, IF(image != "", CONCAT("'.$appurl.'images/app_users/",image), "") as image, barcode as barcode 
                       FROM `ppe_app_users` 
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array($result);

            $query  = 'SELECT ao.issue_id, ao.user_id, ao.attribute_details, p.product_id, 
                       p.`name_en-GB` as product_title, p.image, ao.issue_confirmed_at, ao.qty, ao.asset_no, 
                       ao.is_equipment, if(oi.product_ean != "", oi.product_ean , oi.model_no) as model_no                       
                       FROM `ppe_app_orders` as ao 
                       JOIN `ppe_jshopping_products`as p ON ao.product_id = p.product_id                        
                       JOIN `ppe_jshopping_order_item`as oi ON oi.app_order_id = ao.issue_id                        
                       WHERE ao.`company_id` = "'.$company_id.'" 
                       AND ao.`user_id` = "'.$user_id.'" 
                       AND ao.issue_flag = 1 AND ao.is_completed = 0                                                                     
                       ORDER BY ao.issue_confirmed_at DESC';                   
                        
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $returnproducts = $obj_service->fetch_array_multiple($result);
                        
            $imageurl = $appurl.'components/com_jshopping/files/img_products/';
            foreach($returnproducts as $key => $value) 
            {
                $returnproducts[$key]['product_title'] = utf8_encode($value['product_title']);
                if(file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_products/thumb_'.$value['image'])) {
                    $returnproducts[$key]['image'] = utf8_encode($imageurl.'thumb_'.$value['image']);
                } else {
                    $returnproducts[$key]['image'] = '';
                }                
            }

            //(START) Arrange data based on configuration            
            $query  = 'SELECT app_not_return_counter FROM `ppe_company_info`
                       WHERE `id` = "'.$company_id.'"';                               
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $companyInfo = $obj_service->fetch_array($result);
            
            $check_counter = 3;
            if($companyInfo['app_not_return_counter']) 
                $check_counter = $companyInfo['app_not_return_counter'];

            $newreturnproducts = array();             
            foreach($returnproducts as $data) {
		if($real_return == 1) {                    
                        $newreturnproducts[$data['product_id']][] = $data;                                                            
                } else {                    
                    if(count($newreturnproducts[$data['product_id']]) < $check_counter) {
                        $newreturnproducts[$data['product_id']][] = $data;                                        
                    }
                }            
	    }
            
            $returnproducts = array();
            foreach($newreturnproducts as $data) {
                $returnproducts = array_merge($returnproducts, $data);
            }
            //(END) Arrange data based on configuration

            if (count($returnproducts)) 
            {                                   
                $arrResultDetails['employee'] = $employee;                        
                $arrResultDetails['returnproducts'] = $returnproducts;                        
                $arrResultDetails['TotalCount'] = count($returnproducts);
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['employee'] = $employee;                        
                $arrResultDetails['message'] = 'No product found for return.';
                $arrResultDetails['success'] = 0;
            }            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    //For employee to request products to issue
    case 'requestandissueproducts' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $dept_no = isset($post['dept_no']) ? trim($post['dept_no']) : '';
        $products = is_array($post['products']) ? $post['products'] : array();
        $wishlist = isset($post['wishlist']) ? trim($post['wishlist']) : 0;
        $datetime = date('Y-m-d H:i:s', time());

        if($company_id > 0 && $user_id > 0 && count($products) > 0)
        {                                                                                                    
            $product_avaibility = general::checkAvailableQtyToApproveProducts($products);
            
            if(count($product_avaibility) == 0) 
            {                   
                //Remove from order history
                general::removeTransactionFromOrderHistory($post);
                
                //Remove old requested products to issue
                $query  = " DELETE from `ppe_app_orders` WHERE
                                company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_flag = 0";                                           
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

                //Remove old wishlist
                if($wishlist == 1) {
                    $query  = " DELETE from `ppe_app_wishlist` WHERE
                                company_id = '".$company_id."' AND user_id = '".$user_id."' ";                               
                    
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
                }
                                
                foreach($products as $pk => $product) 
                {   
                    $upc_code = '';
                    if($product['is_equipment'] != 1) {
                        $product['user_quantity'] = 1;
                    }                   
                    $attribute_details = array();
                    $product_dependent_attr_id = 0;                    
                    $product_price = $product['product_price'];
                    
                    foreach($product['attribute'] as $attr_key => $attr_value) 
                    {
                        if(isset($attr_value['attr_title']) && isset($attr_value['value_title'])) 
                        {            
                            if($attr_value['attr_title'] == 'Quantity') {                                
                                if(is_numeric($attr_value['value_title'])) {
                                    $product['user_quantity'] = $attr_value['value_title'];                                    
                                }
                            } else {
                                $attribute_details[] = $attr_value['attr_title'].":".$attr_value['value_title'];
                            }
                        }

                        if(isset($attr_value['is_dependent']) && $attr_value['is_dependent'] == true 
                             && isset($attr_value['product_attr_id']) && $attr_value['product_attr_id'] > 0 
                             && $product['is_laborcost'] == 0) 
                        {
                            $product_dependent_attr_id = $attr_value['product_attr_id'];
                            $product_price = $attr_value['price'];
                            $upc_code = $attr_value['upc_code'];
                        }
                    }
                    
                    if(count($attribute_details)) {
                        $attribute_details = implode(' <br/> ',$attribute_details);                        
                    } else {
                        $attribute_details = '';
                    }
                    
                    
                    $attributes = '';
                    if($product['attribute'] != '') {
                        $attributes = serialize($product['attribute']);
                    }                                            
                    
                    //Add product to issue         
                    $query  = ' SELECT * FROM `ppe_jshopping_products` 
                               WHERE `product_id` = "'.$product['product_id'].'"';                                   
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                
                    $productData = $obj_service->fetch_array($result);                               
                    $productData['upc_code'] = $upc_code;

                    if($productData['is_non_returnable'] == 1) {
                        $query  = " INSERT into `ppe_app_orders` 
                                       (issue_id, company_id, user_id, product_id, qty, asset_no, price, is_chargeable,
                                        signature_comments, attribute_details, attributes, product_attr_id, department_no, zone_id, 
                                        is_equipment, is_laborcost, issue_requested_at, issue_flag, issue_confirmed_at, return_flag, is_completed) 
                                       VALUES 
                                       ('', '".$company_id."', '".$user_id."', '".$product['product_id']."',
                                        '".$product['user_quantity']."', '".mysql_real_escape_string($product['asset_no'])."', '".$product_price."', 
                                        '".$product['is_chargeable']."', '".mysql_real_escape_string($product['signature_comments'])."',
                                        '".mysql_real_escape_string($attribute_details)."', '".mysql_real_escape_string($attributes)."', '".$product_dependent_attr_id."', '".mysql_real_escape_string($dept_no)."', '".mysql_real_escape_string($product['zone_id'])."',
                                        '".$product['is_equipment']."', '".$product['is_laborcost']."', '".$datetime."', '1', '".$datetime."', '1','1') ";                   
                        
                        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                      
                        $insert_id = mysql_insert_id();                                                                    

                    } else {
                        $query  = "INSERT into `ppe_app_orders` 
                                   (issue_id, company_id, user_id, product_id, qty, asset_no, price, is_chargeable,
                                    signature_comments, attribute_details, attributes, product_attr_id, department_no, zone_id,  
                                    is_equipment, is_laborcost, issue_requested_at, issue_flag, issue_confirmed_at) 
                                   VALUES 
                                   ('', '".$company_id."', '".$user_id."', '".$product['product_id']."',
                                    '".$product['user_quantity']."', '".mysql_real_escape_string($product['asset_no'])."', '".$product_price."', 
                                    '".$product['is_chargeable']."', '".mysql_real_escape_string($product['signature_comments'])."',
                                    '".mysql_real_escape_string($attribute_details)."', '".mysql_real_escape_string($attributes)."', '".$product_dependent_attr_id."', '".mysql_real_escape_string($dept_no)."', '".mysql_real_escape_string($product['zone_id'])."',
                                    '".$product['is_equipment']."', '".$product['is_laborcost']."', '".$datetime."', '1', '".$datetime."') ";                   
                        
                        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                      
                        $insert_id = mysql_insert_id();
                    }  
                    
                    //Add Asset Tracking 
                    if($product['asset_no'] != '') {
                        $query  = " INSERT INTO `ppe_app_asset_tracking` 
                                  (`asset_track_id`, `app_user_id`, `issue_id`, `asset_no`,
                                   `company_id`, `assigned_at`, `is_equipment`, `status`) 
                                  VALUES 
                                  ('','".$user_id."','".$insert_id."','".mysql_real_escape_string($product['asset_no'])."',
                                  '".$company_id."','".$datetime."', '".$product['is_equipment']."', '1') ";                   
                        
                        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());                                              
                    }
                    
                    //Upload signature 
                    if($product['is_chargeable'] == 1 && $product['signature'] != '')
                    {
                        
                        $image = str_replace(' ', '+', $product['signature']);    
                        $image = base64_decode($image);
                        $sign_file = dirname(dirname(__FILE__)).'/images/app_users/signatures/'. $insert_id. '.jpg';
                        $sign_success = file_put_contents($sign_file, $image);
                    }
                    
                    //Upload labor cost document
                    if($product['is_laborcost'] == 1 && $product['labor_document'] != '')
                    {
                        
                        $image = str_replace(' ', '+', $product['labor_document']);    
                        $image = base64_decode($image);
                        $sign_file = dirname(dirname(__FILE__)).'/images/app_users/laborcost/'. $insert_id. '.jpg';
                        $sign_success = file_put_contents($sign_file, $image);
                    }

                    //Update product Qty in stock 
                    //$qtyalertproducts[] = general::changeProductQTYinStockOnReturn($insert_id, $product['user_quantity'], "-");

                    //Add product to wishlist
                    if($wishlist == 1)
                    {
                        $query  = " INSERT into `ppe_app_wishlist` 
                               (wid, company_id, user_id, product_id, attribute_details, attributes, product_attr_id, is_equipment, wished_at) 
                               VALUES 
                               ('', '".$company_id."', '".$user_id."', '".$product['product_id']."', '".mysql_real_escape_string($attribute_details)."', '".$attributes."', '".$product_dependent_attr_id."', '".$product['is_equipment']."', '".$datetime."') ";                   
                    
                        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
                    }

                    //Update post products to Order History to input
                    $post['products'][$pk]['detail'] = $productData;                    
                    $post['products'][$pk]['attributes'] = $attributes;
                    $post['products'][$pk]['attribute_details'] = $attribute_details;
                    $post['products'][$pk]['app_order_id'] = $insert_id;
                    $post['products'][$pk]['user_quantity'] = $product['user_quantity'];
                }                                                                        
                                    
                if(isset($insert_id) && $insert_id > 0) 
                {
                    // Add transaction to company 
                    $query  = " INSERT into `ppe_app_transactions` 
                           (trans_id, company_id, app_user_id, trans_date, trans_type) 
                           VALUES 
                           ('', '".$company_id."', '".$user_id."', '".$datetime."', 'OUT') ";                   
                
                    $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());

                    //Add this transaction into order history - RJ
                    $post['non_returnable_counter'] = 1;
                    general::addTransactionIntoOrderHistory($post);
                    //general::updateTransactionIntoOrderHistory($post);

                    //Minimum/maximum qty alert
                    general::send_quantity_alert($qtyalertproducts);
            
                    $arrResultDetails['message'] = 'Confirmed.';
                    $arrResultDetails['success'] = 1;         
                }
                else
                {
                    $arrResultDetails['message'] = 'Failed to issue product. Please try again.';
                    $arrResultDetails['success'] = 0;            
                }

            }
            else 
            {
                $arrResultDetails['message'] = implode("\n",$product_avaibility);
                $arrResultDetails['success'] = 0;         
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    //For payroll product report    
    case 'getpayrollreport' :
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        $fromdate = isset($post['from_date']) ? trim($post['from_date']) : '';        
        $todate = isset($post['to_date']) ? trim($post['to_date']) : '';
        
        if($fromdate != '' && $todate != '') {
            $fromdate = date('Y-m-d', strtotime($fromdate));
            $todate = date('Y-m-d', strtotime($todate));
        } else {
            $fromdate = date('Y-m-d');
            $todate = date('Y-m-d');
        }

        if($company_id > 0)
        {                                                                    
            $query  = " SELECT ao.issue_id, au.employee_id, au.firstname, au.lastname, p.`name_en-GB` as product_title, p.product_id,
                        ao.attribute_details, ao.qty, ao.issue_confirmed_at as outtime, ao.return_confirmed_at as intime, ao.return_comments as comments, DATE(ao.issue_confirmed_at) as date, 
                        ao.price, ao.signature_comments, ao.qty,
                        IF(au.image != '', CONCAT('".$appurl."images/app_users/',au.image), '') as image,
                        IF(ao.is_chargeable = 1, CONCAT('".$appurl."images/app_users/signatures/',ao.issue_id,'.jpg'), '') as signature,
                        CONCAT('') as barcode
                        FROM `ppe_app_orders` as ao
                        JOIN `ppe_app_users` as au ON ao.user_id = au.app_user_id
                        JOIN `ppe_jshopping_products` as p ON p.product_id = ao.product_id
                        WHERE ao.company_id = '".$company_id."' AND ao.is_chargeable = 1 AND ao.issue_flag = 1 
                        AND DATE(ao.issue_confirmed_at) BETWEEN '".$fromdate."' AND '".$todate."' ";
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $resultdata = $obj_service->fetch_array_multiple($result);
            
            foreach($resultdata as $key => $value) {
                $resultdata[$key]['product_title'] = utf8_encode($value['product_title']);
            }
            
            if (count($resultdata)) 
            {                                                   
                $arrResultDetails['productdata'] = $resultdata;                        
                $arrResultDetails['TotalCount'] = count($resultdata);
                $arrResultDetails['success'] = 1;
            } 
            else 
            {                
                $arrResultDetails['message'] = 'No record found.';
                $arrResultDetails['success'] = 0;
            }       
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;


    //For payroll product report    
    case 'emailpayrollreport' :
        
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';        
        
        if($company_id) {
            if(general::send_payroll_report($post)) {
                $arrResultDetails['message']  = 'Report sent successfully.';
                $arrResultDetails['success']  = 1;        
            } else {                      
                $arrResultDetails['message']  = 'Failed to send report. Please try again.';
                $arrResultDetails['success']  = 0;        
            }
        } else {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;   
        }

    break;

    //For ToolZone
    case 'getadditionalzonedata' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $zone_id = isset($post['zone_id']) ? trim($post['zone_id']) : '';
        
        if($company_id > 0 && $user_id > 0 && $zone_id > 0)
        {
            $query  = 'SELECT jobzone_id FROM `ppe_app_users` WHERE `company_id` = "'.$company_id.'"            
                   AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array($result);

            $jobzone_id = $employee['jobzone_id'];
            $categoryData = general::getcategorylist($zone_id, $jobzone_id, $company_id);

            if(count($categoryData)) {
                $arrResultDetails['zonedata'] = $categoryData;                        
                $arrResultDetails['TotalCount']  = count($categoryData);
                $arrResultDetails['success']  = 1;            
            } else {
                $arrResultDetails['message']  = 'No record found';
                $arrResultDetails['success']  = 0;        
            }
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;
    

    //For Equipment Zone (specific) 
    case 'searchproductlist' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $zone_id = isset($post['zone_id']) ? trim($post['zone_id']) : '';
        $search = isset($post['search']) ? trim($post['search']) : '';
        $search_type = isset($post['search_type']) ? trim($post['search_type']) : '0';

        if($company_id > 0 && $user_id > 0 && $zone_id > 0 && $search != '')
        {                                
            $query  = ' SELECT * FROM `ppe_app_users` 
                       WHERE `company_id` = "'.$company_id.'" 
                       AND `app_user_id` = "'.$user_id.'"';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employee = $obj_service->fetch_array($result);

            $productdata = general::searchproductlist($search_type, $search, $zone_id, $employee['jobzone_id'], $company_id);            
                                                                        
            if (count($productdata)) 
            {                                   
                $arrResultDetails['products'] = $productdata;                        
                $arrResultDetails['TotalCount'] = count($productdata);
                $arrResultDetails['success'] = 1;

            } else {
                $arrResultDetails['message'] = 'No product found.';
                $arrResultDetails['success'] = 0;
            }
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    // Check for Asset Transfer 
    case 'checkassetowner' :
                
        $postdata = file_get_contents('php://input');
        $post     = json_decode($postdata,true);        
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $asset_no = isset($post['asset_no']) ? trim($post['asset_no']) : '';
        
        if($company_id > 0 && $user_id > 0 && $asset_no != '')
        {
            $query  = 'SELECT at.asset_no, at.app_user_id, CONCAT(au.firstname," ",au.lastname) as name
                       FROM `ppe_app_asset_tracking` as at 
                       JOIN `ppe_app_users` as au ON at.app_user_id = au.app_user_id AND au.is_deleted = 0
                       WHERE at.`company_id` = "'.$company_id.'" AND at.`asset_no` = "'.$asset_no.'"
                       ORDER BY at.assigned_at DESC
                       LIMIT 0,1';                   
            
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
            $employeeAsset = $obj_service->fetch_array($result);
            
            if(isset($employeeAsset['asset_no']) && $employeeAsset['asset_no'] != '' && $employeeAsset['app_user_id'] != $post['user_id']) {                
                $arrResultDetails['message']  = 'Asset# '.$employeeAsset['asset_no'].' currently hold by '.$employeeAsset['name'].'. Do you wish to transfer this asset?';
                $arrResultDetails['success']  = 1;            
            } else {
                $arrResultDetails['message']  = 'No asset found.';
                $arrResultDetails['success']  = 0;        
            }
            
        }         
        else
        {
            $arrResultDetails['message']  = 'Please enter parameters with proper value.';
            $arrResultDetails['success']  = 0;
        }

    break;

    default :
        $arrResultDetails['message']  = 'No such service available with required parameters.';
        $arrResultDetails['success']  = 0;
    break;
}
$output = json_encode($arrResultDetails);
print_r($output);
die;
?>
