<?php
class general {

    public function appurl(){                        
        return SITE_URL;
    }
    
    public static function getproductlist($category_id = 0, $jobzone_id, $company_id, $product_array = array())
    {
        global $obj_service;
        $obj_service = new sql();        
        $appurl = general::appurl().'components/com_jshopping/files/img_products/';
        
        $query  = ' SELECT p.product_id, p.`name_en-GB` as product_title, p.image, p.unlimited, p.product_quantity, p.product_price, p.`model_no`,
                    0 as product_reserved, p.display_order_no, p.is_laborcost
                    FROM `ppe_jshopping_products_to_categories` as ptc
                    JOIN `ppe_jshopping_products` as p ON ptc.product_id = p.product_id AND FIND_IN_SET("'.$jobzone_id.'",p.product_jobrole)
                    JOIN `ppe_company_product_map` as cpm ON cpm.product_id = p.product_id AND cpm.company_id = "'.$company_id.'"
                    WHERE ptc.`category_id` = "'.$category_id.'" AND p.`is_app` = 1                     
                    AND p.product_publish = 1 AND (p.unlimited = 1 OR p.product_quantity > 0)
                    ORDER BY p.display_order_no, p.product_id DESC';                   

            /*(Select count(*) from ppe_app_orders 
                                  WHERE product_id = p.product_id 
                                  AND issue_flag = 0
                                  AND DATE(issue_requested_at) = "'.date('Y-m-d').'") as product_reserved*/

        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
        $productlist = $obj_service->fetch_array_multiple($result);            
        
        $product_array = general::includeProductStock($productlist, $product_array);

        $query  = ' SELECT category_id FROM `ppe_jshopping_categories` 
                       WHERE `category_parent_id` = "'.$category_id.'" AND `category_publish` = 1 ORDER BY category_id DESC';                   
            
        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
        $categorylist = $obj_service->fetch_array_multiple($result);
        
        foreach($categorylist as $category_data) {            
            $product_array = general::getproductlist($category_data['category_id'], $jobzone_id, $company_id, $product_array);            
        }        
        
        return $product_array;
    }

    //Count Products for HomePage
    public static function countproductlist($category_id = 0, $jobzone_id, $company_id, $product_count = 0)
    {
        global $obj_service;
        $obj_service = new sql();        
        $appurl = general::appurl().'components/com_jshopping/files/img_products/';
        
        $query  = ' SELECT count(p.product_id) as total
                    FROM `ppe_jshopping_products_to_categories` as ptc
                    JOIN `ppe_jshopping_products` as p ON ptc.product_id = p.product_id AND FIND_IN_SET("'.$jobzone_id.'",p.product_jobrole)
                    JOIN `ppe_company_product_map` as cpm ON cpm.product_id = p.product_id AND cpm.company_id = "'.$company_id.'"
                    WHERE ptc.`category_id` = "'.$category_id.'" AND p.`is_app` = 1                     
                    AND p.product_publish = 1 AND (p.unlimited = 1 OR p.product_quantity > 0)
                    ORDER BY p.display_order_no, p.product_id DESC';                               

        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
        $totalProduct = $obj_service->fetch_array($result);            
        
        $product_count = $product_count + $totalProduct['total'];        

        if($product_count > 0) {            
            return $product_count;
        }        

        $query  = ' SELECT category_id FROM `ppe_jshopping_categories` 
                       WHERE `category_parent_id` = "'.$category_id.'" AND `category_publish` = 1 ORDER BY category_id DESC';                   
            
        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
        $categorylist = $obj_service->fetch_array_multiple($result);
        
        foreach($categorylist as $category_data) {            
            if($product_count > 0) {
                continue;
            }
            
            $product_count = general::countproductlist($category_data['category_id'], $jobzone_id, $company_id, $product_count);            
        }        
        
        return $product_count;
    }
    
    
    //For equipment zone (specific) - START
    public static function searchproductlist($search_type = 0, $search = '', $category_id = 0, $jobzone_id, $company_id, $product_array = array()) 
    {
        $category_array = general::searchcategorydepth($search_type, $search, $category_id, $jobzone_id, $company_id, array());                    
        $product_array = general::searchproductdepth($search_type, $search, $category_array, $jobzone_id, $company_id, array());                    
        return $product_array;
    }

    public static function searchcategorydepth($search_type = 0, $search = '', $category_id = 0, $jobzone_id, $company_id, $category_array = array())
    {
        global $obj_service;
        $obj_service = new sql();        
        
        $search_condition = '';
        /*if($search_type == 1) {
            $search_condition = ' AND `name_en-GB` like "%'.$search.'%" ';
        }*/

        $query  = ' SELECT category_id FROM `ppe_jshopping_categories` 
                       WHERE `category_parent_id` = "'.$category_id.'" AND `category_publish` = 1 
                       '.$search_condition.'
                       ORDER BY category_id DESC';                   
            
        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
        $categorylist = $obj_service->fetch_array_multiple($result);
                
        foreach($categorylist as $category_data) {
            $category_array[] = $category_data['category_id'];
            $category_array = general::searchcategorydepth($search_type, $search, $category_data['category_id'], $jobzone_id, $company_id, $category_array);            
        }
        
        return $category_array;        
    }
    
    public static function searchproductdepth($search_type = 0, $search = '', $category_id = array(), $jobzone_id, $company_id, $product_array = array())
    {
        global $obj_service;
        $obj_service = new sql();        
        $appurl = general::appurl().'components/com_jshopping/files/img_products/';
        
        $category_id = implode(",",$category_id);

        $search_condition = '';
        if($search_type == 0) {
            $search_condition = ' AND p.`model_no` like "%'.$search.'%" ';
        } else if($search_type == 1) {
            $search_condition = ' AND p.`bin_location` like "%'.$search.'%" ';
        } else if($search_type == 2) {
            $search_condition = ' AND p.`name_en-GB` like "%'.$search.'%" ';
        }   
        
        $query  = ' SELECT p.product_id, p.`name_en-GB` as product_title, p.image, p.unlimited, p.product_quantity, p.product_price,
                    0 as product_reserved, p.display_order_no, p.`is_laborcost`, p.`model_no`, p.`bin_location` as category_title
                    FROM `ppe_jshopping_products_to_categories` as ptc
                    JOIN `ppe_jshopping_products` as p ON ptc.product_id = p.product_id AND FIND_IN_SET("'.$jobzone_id.'",p.product_jobrole)
                    JOIN `ppe_jshopping_categories` as c ON ptc.category_id = c.category_id
                    JOIN `ppe_company_product_map` as cpm ON cpm.product_id = p.product_id AND cpm.company_id = "'.$company_id.'"
                    WHERE ptc.`category_id` IN ('.$category_id.') AND p.`is_app` = 1                     
                    AND p.product_publish = 1 AND (p.unlimited = 1 OR p.product_quantity > 0)
                    '.$search_condition.'                    
                    ORDER BY p.display_order_no, p.product_id DESC';                   
                    
                    //AND (p.`model_no` like "'.$search.'%" OR p.`name_en-GB` like "'.$search.'%") 

        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
        $productlist = $obj_service->fetch_array_multiple($result);            
        
        $product_array = general::includeProductStock($productlist, $product_array);
                      
        return $product_array;
    }
    //For equipment zone (specific) - END


    // Apply UPC and stock based on attributes to product
    public function includeProductStock($productlist, $product_array = array(), $is_wishlist = 0) 
    {
        global $obj_service;
        $obj_service = new sql();
        $attributeData = general::getAllAttributes(2);        
        $dependent_attr = $attributeData['dependent'];
        $appurl = general::appurl().'components/com_jshopping/files/img_products/';
        
        foreach ($productlist as $product) {
            if(file_exists(dirname(dirname(__FILE__)).'/components/com_jshopping/files/img_products/full_'.$product['image'])) {
                $product['image'] = utf8_encode($appurl.'full_'.$product['image']);
                $product['image'] = general::appurl().'timthumb/timthumb.php?src='.$product['image'].'&q=50&zc=2';
            } else {
                $product['image'] = '';
            }
            $product['product_title'] = utf8_encode($product['product_title']);
             

            //Dependent Product Attribites (START) -RJ                    
            $attrib_array = array();            
            if (count($dependent_attr))
            {
                $query = "SELECT * FROM `ppe_jshopping_products_attr` WHERE product_id = '".$product['product_id']."' ORDER BY product_attr_id";
                $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
                $prodAttribVal = $obj_service->fetch_array_multiple($result);
                                
                if (count($prodAttribVal))
                {
                    $remaining_qty = 0;                
                    $prodAtrtib = $prodAttribVal[0];
                    foreach($dependent_attr as $attrib)
                    {
                        $field = "attr_".$attrib['attr_id'];                                            
                        if ($prodAtrtib[$field]) 
                        {
                            $query = 'SELECT pa.product_attr_id, pa.ean as upc_code, av.value_id, av.`name_en-GB` as value_title, pa.price,
                                  pa.`count` - (Select count(*) from ppe_app_orders 
                                  WHERE product_attr_id = pa.product_attr_id 
                                  AND issue_flag = 0
                                  AND DATE(issue_requested_at) = "'.date('Y-m-d').'") as stock                                    
                                  FROM `ppe_jshopping_products_attr` as pa                                  
                                  JOIN `ppe_jshopping_attr_values` as av ON pa.attr_'.$attrib['attr_id'].' = av.value_id
                                  WHERE pa.`product_id` = "'.$product['product_id'].'"';
                            
                            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
                            $prodAttribData = $obj_service->fetch_array_multiple($result);
                            
                            foreach($prodAttribData as $key=>$value) 
                            {                                
                                $prodAttribData[$key]['is_dependent'] = true;
                                $prodAttribData[$key]['attr_id'] = $attrib['attr_id'];
                                $prodAttribData[$key]['attr_title'] = $attrib['name'];
                                if($value['stock'] > 0) {                                                                               
                                    $remaining_qty += $value['stock'];
                                    $attrib_array[$attrib['name']][] = $prodAttribData[$key];
                                }
                                
                            }
                        }
                    }
                }
            }
            
            //For wishlist only
            if($is_wishlist == 1) 
            {                
                $product['attributes'] = unserialize($product['attributes']);                
                if ( is_array($product['attributes']) )
                {                
                    //Update product dependent attribute
                    $wattr = array();
                    $dependent_wattr_key = 0;
                    foreach($product['attributes'] as $pro_attr_key => $pro_attr_value) {
                        if($pro_attr_value['is_dependent'] == true) {
                            $dependent_wattr_key = $pro_attr_key;
                            $wattr = $pro_attr_value;                            
                        }
                    }                                        
                    if($wattr['is_dependent'] == true && $wattr['product_attr_id'] > 0 ) 
                    {
                        $skip_loop = 0;
                        foreach($attrib_array as $wattrib_array) 
                        {                            
                            if($skip_loop) continue;
                            foreach($wattrib_array as $wattrib_check) 
                            {
                                if($skip_loop) continue;                                
                                if($wattr['product_attr_id'] == $wattrib_check['product_attr_id']) {
                                    $product['attributes'][$dependent_wattr_key] = $wattrib_check;
                                    $skip_loop = 1;
                                }
                            }                                
                        }
                    }                    
                }
                else 
                {
                    $product['attributes'] = array();
                }

                if($product['unlimited'] == 1 || ($product['product_quantity'] - $product['product_reserved']) > 0) {                    
                    $product['avaibility'] = 1;
                } else {
                    $product['avaibility'] = 0;
                }
                $product_array[] = $product;    
                continue;                           
            }                                        
            
            //For productlist
            //$product['dependent_attributes'] = $attrib_array;            

            //Independent Product Attribites (START) -RJ
            $query  = ' SELECT a.attr_id, a.`name_en-GB` as attr_title, av.value_id, av.`name_en-GB` as value_title FROM `ppe_jshopping_products_attr2` as pa
                    JOIN `ppe_jshopping_attr` as a ON pa.attr_id = a.attr_id
                    JOIN `ppe_jshopping_attr_values` as av ON pa.attr_value_id = av.value_id AND pa.attr_id = av.attr_id
                    WHERE pa.`product_id` = "'.$product['product_id'].'"';                               
            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
            $attrdata = $obj_service->fetch_array_multiple($result);
            
            //$attrib_array = array();
            foreach($attrdata as $attribute) {                
                $attribute['product_attr_id'] = 0;                
                $attribute['upc_code'] = '';                
                $attribute['price'] = 0;
                $attribute['stock'] = 0;

                $attribute['is_dependent'] = false;                                                
                $attrib_array[$attribute['attr_title']][] = $attribute;                
            }            
            /*if(count($attrib_array)) {
                $attrib_array = array_slice($attrib_array, 0 ,1);
            }*/
            //$product['independent_attributes'] = $attrib_array;            
            $product['attributes'] = $attrib_array;            
            //Independent Product Attributes (END) - RJ
            
            if($product['unlimited'] == 1 || ($product['product_quantity'] - $product['product_reserved']) > 0) {
                $product_array[] = $product;                               
            }
            
        }
        
        return $product_array;
    }

    public function checkAvailableQtyToApprove($approved_products = array()){
        
        global $obj_service;
        $obj_service = new sql();
        
        $product_avaibility = array();
        foreach($approved_products as $issue_id) 
        {
            $query = "SELECT ao.issue_id, p.product_quantity, p.unlimited, p.is_app, p.`name_en-GB` as product_title, pa.count as attr_prod_qty, pa.product_attr_id 
                      FROM `ppe_app_orders` as ao 
                      JOIN `ppe_jshopping_products` as p ON ao.product_id = p.product_id
                      LEFT JOIN `ppe_jshopping_products_attr` as pa ON pa.product_attr_id = ao.product_attr_id
                      WHERE ao.issue_id = '".$issue_id."'";

            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
            $issueDetail = $obj_service->fetch_array_multiple($result);        
            $issueDetail = $issueDetail[0];
            $issueDetail['product_title'] = utf8_encode($issueDetail['product_title']);
            
            if($issueDetail['issue_id'] < 1) {
                $product_avaibility[$issue_id] = 'Product not found';
            } else if($issueDetail['is_app'] != 1) {
                $product_avaibility[$issue_id] = $issueDetail['product_title'].' is no longer exist for mobile application.';
            } else if ($issueDetail['product_attr_id'] > 0 && $issueDetail['attr_prod_qty'] < 1) {
                $product_avaibility[$issue_id] = $issueDetail['product_title'].' not available in required size.';
            } else if ($issueDetail['product_quantity'] < 1) {
                $product_avaibility[$issue_id] = $issueDetail['product_title'].' not available.';
            }
        }        
        
        return $product_avaibility;
    }
    
    public function getAllAttributes($result = 0, $categorys = null, $order = null, $orderDir = null){
        
        global $obj_service;
        $obj_service = new sql();

        $ordering = "attr_ordering asc";
        if ($order && $orderDir){
            $ordering = $order." ".$orderDir;
        }
        $query = "SELECT attr_id, `name_en-GB` as name, attr_type, attr_ordering, independent, allcats, cats FROM `ppe_jshopping_attr` ORDER BY ".$ordering;
        $obj_service->sql_query($query);
        $list = $obj_service->fetch_array_multiple();
                
        if (is_array($categorys) && count($categorys)){
            foreach($list as $k=>$v){
                if (!$v['allcats']){
                    if ($v['cats']!=""){
                        $cats = unserialize($v['cats']);
                    }else{
                        $cats = array();
                    }
                    $enable = 0;
                    foreach($categorys as $cid){
                        if (in_array($cid, $cats)) $enable = 1;
                    }
                    if (!$enable){
                        unset($list[$k]);
                    }
                }
            } 
        }
        
        if ($result==0){
            return $list;
        }
        if ($result==1){
            $attributes_format1 = array();
            foreach($list as $v){
                $attributes_format1[$v['attr_id']] = $v;
            }
            return $attributes_format1;
        }
        if ($result==2){
            $attributes_format2 = array();
            $attributes_format2['independent']= array();
            $attributes_format2['dependent']= array();
            foreach($list as $v){
                if ($v['independent']) $key_dependent = "independent"; else $key_dependent = "dependent";
                $attributes_format2[$key_dependent][$v['attr_id']] = $v;
            }
            return $attributes_format2;
        }
    }    

    /**
    * get or return employee
    * @param company_id, user_id
    * @return  array
    */
    function getemployeeinfo($company_id, $user_id) {
        
        $appurl = general::appurl();
        global $obj_service;
        $obj_service = new sql();

        $query  = ' SELECT au.*, IF(image != "", CONCAT("'.$appurl.'images/app_users/",image),  "") as image, image as imagename, j.job_title
                    FROM `ppe_app_users` as au
                    JOIN `ppe_jobrole` as j ON j.id = au.jobzone_id
                    WHERE is_deleted = 0 AND `company_id` = "'.$company_id.'" AND `app_user_id` = "'.$user_id.'" ';                   

        $userresult = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
        $user = $obj_service->fetch_array($userresult);

        return $user;
    }

    /**
    * get or return product in Stock
    * @param $change ("-" - get, "+" - return) 
    */
    function changeProductQTYinStockOnReturn($issue_id = 0, $return_quantity = 0, $change = "+"){
        global $obj_service;
        $obj_service = new sql();
                
        $query = "SELECT OI.*, P.unlimited FROM `ppe_app_orders` as OI left join `ppe_jshopping_products` as P on P.product_id=OI.product_id
                  WHERE issue_id = '".$issue_id."'";
        $obj_service->sql_query($query);
        $items = $obj_service->fetch_array_multiple();
        
        foreach($items as $item){
            
            if ($item['unlimited']) continue;
            
            /*if ($item['attributes'] != ""){
                $attributes = unserialize($item['attributes']);
            }else{
                $attributes = array();
            }            
            if (!is_array($attributes)) $attributes = array();
            
            $allattribs = general::getAllAttributes(1);
            $dependent_attr = array();
            foreach($attributes as $k=>$v){
                if ($allattribs[$k]->independent==0){
                    $dependent_attr[$k] = $v;
                }
            }
            
            if (count($dependent_attr))
            {
                $where="";
                foreach($dependent_attr as $k=>$v){
                    $where.=" and `attr_$k`='".intval($v)."'";
                }*/
            
            
            if($item['product_attr_id'] > 0) {
        
                $query = "update `ppe_jshopping_products_attr` set `count`=`count`  ".$change." ".$return_quantity." where product_id='".intval($item['product_id'])."' AND product_attr_id = ".intval($item['product_attr_id']);
                //$query = "update `ppe_jshopping_products_attr` set `count`=`count`  ".$change." ".$return_quantity." where product_id='".intval($item['product_id'])."' ".$where ;
                $obj_service->sql_query($query);
                                
                $query="select sum(count) as qty from `ppe_jshopping_products_attr` where product_id='".intval($item['product_id'])."' and `count`>0 ";
                $obj_service->sql_query($query);
                $qty = $obj_service->fetch_array_multiple();
                $qty = $qty[0]['qty'];
                
                $query = "UPDATE `ppe_jshopping_products` SET product_quantity = '".$qty."' WHERE product_id = '".intval($item['product_id'])."'";
                $obj_service->sql_query($query);
                
            }else{
                $query = "UPDATE `ppe_jshopping_products` SET product_quantity = product_quantity ".$change." ".$return_quantity." WHERE product_id = '".intval($item['product_id'])."'";
                $obj_service->sql_query($query);                
            }            
        }

        return $items[0]['product_id'];
    }

    //Add transaction into order history
    function addTransactionIntoOrderHistory($post = array()) {
        global $obj_service;
        $obj_service = new sql();
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $products = is_array($post['products']) ? $post['products'] : array();                
        $datetime = date('Y-m-d H:i:s', time());

        if($post['non_returnable_counter'] == 0) {
            $order_created = 0;
            $order_status = 1;
        } else {
            $order_created = 1;
            $order_status = 7;
        }        
                
        $query="select next_order_number from `ppe_jshopping_config` where id = 1";
        $obj_service->sql_query($query);
        $config_jshop = $obj_service->fetch_array();        
        $order_number = sprintf('%08d', $config_jshop['next_order_number']) ;
        
        //Check if user exist on site -start
        $query="Select * from `ppe_app_users` as au
                LEFT JOIN `ppe_company_map_users` as cmu ON cmu.app_user_id = au.app_user_id                
                where au.app_user_id = '".$user_id."'";
        $obj_service->sql_query($query);
        $user = $obj_service->fetch_array();        
        $user['email'] = '-';
        $user['city'] = '-';
        $user['postal_code'] = '-';
        $user['state'] = '-';
        $user['address1'] = '-';        
        $user['phone'] = '-';
        $user['country'] = '223';

        if($user['site_user_id'] > 0) {
            $query="SELECT u.id as user_id, u.email, u.username, GROUP_CONCAT( CONCAT(up.profile_key,'||',profile_value) ) as user_profile 
                    from `ppe_users` as u 
                    JOIN `ppe_user_profiles` as up ON up.user_id = u.id                
                    where u.id = '".$user['site_user_id']."'";
            $obj_service->sql_query($query);
            $siteuser = $obj_service->fetch_array();        
                        
            $user['email'] = $siteuser['email'];
            foreach(explode(",",$siteuser['user_profile']) as $udata) 
            {                
                $pdata = explode("||",$udata);                
                $key = str_replace("profile.","",$pdata[0]);
                $user[$key] = trim($pdata[1], '"');                 
            }            
        }
        //Check if user exist on site -end

        $query="INSERT into `ppe_jshopping_orders` 
                (
                 order_id, order_number, user_id, currency_code, currency_code_iso, 
                 currency_exchange, order_status, order_created, order_date, invoice_date, 
                 order_m_date, f_name, l_name, company_id, street, 
                 email, zip, city, state, country, 
                 phone, d_f_name, d_l_name, d_email, d_firma_name, 
                 d_street, d_zip, d_city, d_state, d_country, 
                 d_phone, lang, is_app_order, ip_address,
                 app_user_id
                ) 
                VALUES 
                (
                '', '".$order_number."', '".$user['site_user_id']."', '$', 'DOL', 
                '1', '".$order_status."', '".$order_created."' ,'".$datetime."' ,'".$datetime."',
                '".$datetime."', '".$user['firstname']."', '".$user['lastname']."', '".$company_id."', '".$user['address1'].' '.$user['address2']."', 
                '".$user['email']."', '".$user['postal_code']."', '".$user['city']."', '".$user['state']."', '".$user['country']."',
                '".$user['phone']."', '".$user['firstname']."','".$user['lastname']."','".$user['email']."', '',
                '".$user['address1'].' '.$user['address2']."', '".$user['postal_code']."', '".$user['city']."', '".$user['state']."', '".$user['country']."',
                '".$user['phone']."', 'en-GB', '1', '".$_SERVER['REMOTE_ADDR']."',
                '".$user_id."'
                )";
        $obj_service->sql_query($query);                
        $order_id = mysql_insert_id();
        
        if($order_id > 0) {
            $next_order_number = $config_jshop['next_order_number'] + 1 ;
            $query="UPDATE `ppe_jshopping_config` SET next_order_number = '".$next_order_number."' where id = 1";
            $obj_service->sql_query($query);            
        }

        foreach($products as $product) 
        {
            $attributes = array();
            foreach(unserialize($product_attributes) as $vattrib) {
                $attributes[$vattrib['attr_id']] = $vattrib['value_id'];
            }
            
            $query="INSERT INTO `ppe_jshopping_order_item`
                (
                `order_item_id`, `order_id`, `product_id`, `product_ean`, 
                `product_name`, `product_quantity`, `product_item_price`, `product_tax`,
                `product_attributes`, `product_freeattributes`, `attributes`, `freeattributes`,
                `extra_fields`, `files`, `weight`, `thumb_image`, 
                `manufacturer`, `delivery_times_id`, `vendor_id`, `basicprice`,
                `basicpriceunit`, `params`, `shipping_info`, `model_no`,
                `is_non_returnable`, `app_order_id`
                ) 
                VALUES 
                (
                 '', '".$order_id."', '".$product['product_id']."', '".mysql_real_escape_string($product['detail']['upc_code'])."',
                 '".mysql_real_escape_string($product['product_title'])."', '".$product['user_quantity']."', '', '',
                 '".mysql_real_escape_string($product['attribute_details'])."', '', '".mysql_real_escape_string(serialize($attributes))."', '',
                 '', '', '".$product['detail']['product_weight']."', 'thumb_".mysql_real_escape_string($product['detail']['image'])."',
                 '', '', '', '',
                 '', '', '', '".mysql_real_escape_string($product['detail']['model_no'])."',
                 '".$product['detail']['is_non_returnable']."', '".$product['app_order_id']."'
                )";
            $obj_service->sql_query($query);
        }

        return $order_id;
    }
    
    //Remove unused transaction from order history
    function removeTransactionFromOrderHistory($post = array()) {
        global $obj_service;
        $obj_service = new sql();
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        
        $query  = " SELECT GROUP_CONCAT(`issue_id`) as transactions FROM `ppe_app_orders` WHERE
                    company_id = '".$company_id."' AND user_id = '".$user_id."' AND issue_flag = 0";                                           
        $result = $obj_service->sql_query($query);
        $result = $obj_service->fetch_array($result);               
        $transactions = $result['transactions'];

        if($transactions != '' && $transactions != 0 && $transactions != null) {
            $query  = "DELETE FROM `ppe_jshopping_order_item` WHERE is_non_returnable = 0 AND
                       app_order_id IN (".$transactions.")";                                                       
            $obj_service->sql_query($query);
        }

        return true;
    }

    //Update transaction into order history
    function updateTransactionIntoOrderHistory($post = array()) {
        global $obj_service;
        $obj_service = new sql();
        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';                        
         
        $query  = " SELECT o.order_id, count(oi.order_item_id) as order_item_count
                    FROM `ppe_jshopping_orders` as o 
                    LEFT JOIN `ppe_jshopping_order_item` as oi ON o.order_id = oi.order_id
                    WHERE o.company_id = '".$company_id."' 
                    AND o.is_app_order = 1 AND o.order_created = 0
                    AND o.app_user_id = '".$user_id."'
                    GROUP BY o.order_id";                                           
        $result = $obj_service->sql_query($query);
        $orders = $obj_service->fetch_array_multiple($result);               

        foreach($orders as $order) {
            if($order['order_item_count'] > 0) {
                $query  = "UPDATE `ppe_jshopping_orders` SET `order_created` = 1, `order_status` = 7
                           WHERE order_id = '".$order['order_id']."'";                                                       
                $obj_service->sql_query($query);
            } else {
                $query  = "DELETE FROM `ppe_jshopping_orders` WHERE order_id = '".$order['order_id']."'";                                                       
                $obj_service->sql_query($query);
            }
        }

        return true;
    }
    
    //Min-Max Product Quantity Alert 
    function send_quantity_alert($products= array()) 
    {
        $appurl = general::appurl();
        $products = array_unique($products);
            
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $appurl . "productquantityalert.php");
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_POST, 1);
        //curl_setopt($ch, CURLOPT_POSTFIELDS,
        //            "postvar1=value1&postvar2=value2&postvar3=value3");
        // in real life you should use something like:
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($products));

        // receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $content = curl_exec($ch);

        $response = curl_getinfo( $ch );

        curl_close($ch);

        //echo '<pre>'; print_r($content); die;
        return true;
    }


    /*
     * MERGE APP FUNCTIONS EMPLOYEE AND SUPERVISOR - RJ
     */
    public function checkAvailableQtyToApproveProducts($products = array()){
        
        global $obj_service;
        $obj_service = new sql();
        
        $product_avaibility = array();
        foreach($products as $product) 
        {
            $query = "SELECT p.product_quantity, p.unlimited, p.is_app, p.`name_en-GB` as product_title, pa.count as attr_prod_qty, pa.product_attr_id 
                      FROM `ppe_jshopping_products` as p
                      LEFT JOIN `ppe_jshopping_products_attr` as pa ON pa.product_attr_id = '".$product['attribute'][0]['product_attr_id']."'
                      WHERE p.product_id = '".$product['product_id']."'";

            $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());            
            $issueDetail = $obj_service->fetch_array_multiple($result);        
            $issueDetail = $issueDetail[0];
            $issueDetail['product_title'] = utf8_encode($issueDetail['product_title']);
            
            $quantity = 1;
            if(isset($product['user_quantity']) && $product['user_quantity'] > 0) {
                $quantity = $product['user_quantity'];
            }

            if($issueDetail['is_app'] != 1) {
                $product_avaibility[$issue_id] = $issueDetail['product_title'].' is no longer exist for mobile application.';
            } else if ($issueDetail['unlimited'] != 1 && $issueDetail['product_attr_id'] > 0 && $issueDetail['attr_prod_qty'] < $quantity) {
                $product_avaibility[$issue_id] = $issueDetail['product_title'].' not available in required size.';
            } else if ($issueDetail['unlimited'] != 1 && $issueDetail['product_quantity'] < $quantity) {
                $product_avaibility[$issue_id] = $issueDetail['product_title'].' not available in required quantity.';
            }
        }        
        
        return $product_avaibility;
    }


    //Send Payroll Report - RJ
    function send_payroll_report($post= array()) 
    {
        $appurl = general::appurl();
        $post['email'] = implode(",",$post['email']);
        
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, $appurl . "sendpayrollreport.php");
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_POST, 1);
        //curl_setopt($ch, CURLOPT_POSTFIELDS,
        //            "postvar1=value1&postvar2=value2&postvar3=value3");
        // in real life you should use something like:
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));

        // receive server response ...
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $content = curl_exec($ch);

        $response = curl_getinfo( $ch );

        curl_close($ch);
        
        //echo '<pre>'; print_r($content);
        if($content == true) {        
            return true;
        } else {
            return false;
        }
    }

    // Extra other functions
	public static function thumbss($file, $save, $width, $height)
	{
        
        //GD-Lib > 2.0 only!
        //@unlink($save);
        //get sizes else stop
        if (!$infos = @getimagesize($file)) {
            return false;
        }
        // keep proportions
        $iWidth = $infos[0];
        $iHeight = $infos[1];
        $iRatioW = $width / $iWidth;
        $iRatioH = $height / $iHeight;

        if ($iRatioW < $iRatioH) {
            $iNewW = $iWidth * $iRatioW;
            $iNewH = $iHeight * $iRatioW;
        } else {
            $iNewW = $iWidth * $iRatioH;
            $iNewH = $iHeight * $iRatioH;
        }
        
        //Don't resize images which are smaller than thumbs
        if ($infos[0] < $width && $infos[1] < $height) {
            $iNewW = $infos[0];
            $iNewH = $infos[1];
        }

        if($infos[2] == 1) {
            /*
            * Image is typ gif
            */
            $imgA = imagecreatefromgif($file);
            $imgB = imagecreate($iNewW,$iNewH);
            
            //keep gif transparent color if possible
            if(function_exists('imagecolorsforindex') && function_exists('imagecolortransparent')) {
                $transcolorindex = imagecolortransparent($imgA);
                    //transparent color exists
                    if($transcolorindex >= 0 ) {
                        $transcolor = imagecolorsforindex($imgA, $transcolorindex);
                        $transcolorindex = imagecolorallocate($imgB, $transcolor['red'], $transcolor['green'], $transcolor['blue']);
                        imagefill($imgB, 0, 0, $transcolorindex);
                        imagecolortransparent($imgB, $transcolorindex);
                    //fill white
                    } else {
                        $whitecolorindex = @imagecolorallocate($imgB, 255, 255, 255);
                        imagefill($imgB, 0, 0, $whitecolorindex);
                    }
            //fill white
            } else {
                $whitecolorindex = imagecolorallocate($imgB, 255, 255, 255);
                imagefill($imgB, 0, 0, $whitecolorindex);
            }
            imagecopyresampled($imgB, $imgA, 0, 0, 0, 0, $iNewW, $iNewH, $infos[0], $infos[1]);
            imagegif($imgB, $save);        

        } elseif($infos[2] == 2) {
            /*
            * Image is typ jpg
            */
            $imgA = imagecreatefromjpeg($file);
            $imgB = imagecreatetruecolor($iNewW,$iNewH);
            imagecopyresampled($imgB, $imgA, 0, 0, 0, 0, $iNewW, $iNewH, $infos[0], $infos[1]);
            imagejpeg($imgB, $save);

        } elseif($infos[2] == 3) {
            /*
            * Image is typ png
            */
            $imgA = imagecreatefrompng($file);
            $imgB = imagecreatetruecolor($iNewW, $iNewH);
            imagealphablending($imgB, false);
            imagecopyresampled($imgB, $imgA, 0, 0, 0, 0, $iNewW, $iNewH, $infos[0], $infos[1]);
            imagesavealpha($imgB, true);
            imagepng($imgB, $save);
        } 
        else 
        {
            return false;
        }
        return true;
	}
    
    // Upload image for Appuser to Webuser - Ajay
    public static function updateApptoWebuser($data)
    {          
        global $obj_service;
        $obj_service = new sql();

        $app_user_id = $data['user_id'];

        $query = 'SELECT * FROM `ppe_company_map_users` WHERE app_user_id = ' . (int) $app_user_id;
        $result = $obj_service->sql_query($query);
        $appuserresult = $obj_service->fetch_array($result); 
        
        if($appuserresult['site_user_id'] > 0) {
            $updatedata['image'] = $data['image'];
            $updatedata['app_user_id'] = $appuserresult['app_user_id'];
            $updatedata['employee_id'] = $data['employee_id'];
            $updatedata['site_user_id'] = $appuserresult['site_user_id'];
            
            $uploadimg = general::uploadimageAppToWebUser($updatedata);

            if($uploadimg){
                return true;
            } else{
                return false;
            }
        } else {
            return true;
        }

    }

    // Upload image for Appuser to Webuser - Ajay
    public static function uploadimageAppToWebUser($updatedata)
    { 
        $base_dir = dirname(__DIR__);
        global $obj_service;
        
        $obj_service = new sql();
        $ext = pathinfo($updatedata['image'], PATHINFO_EXTENSION);
        $imagename = $updatedata['image'];
       

        if ( isset($updatedata['image']) && file_exists($base_dir.'/images/app_users/'.$imagename) ) {
            
            $copy_path= $base_dir.'/images/app_users/'. $imagename;

            $image_path = $base_dir.'/images/ppezone/users/'; 

            $dest_path = $image_path. $imagename;

            @chmod($copy_path, 0777);
            copy($copy_path, $dest_path);

            rename($image_path.$imagename, $image_path . $updatedata['site_user_id'].".".$ext);
            

            $name_image = $updatedata['site_user_id'] . "." . $ext;
            $name_thumb = 'thumb_' . $name_image;
            $name_full = 'full_' . $name_image;
            @chmod($image_path . $name_image, 0777);


            $path_image = $image_path . $name_image;
            $path_thumb = $image_path . $name_thumb;
            $path_full = $image_path . $name_full;

            @unlink($path_thumb);
            general::thumbss($path_image, $path_thumb, '49', '49');

            @unlink($path_full);
            general::thumbss($path_image, $path_full, '120', '110');


            // Update web user profile table for image name
            $webprofileimage = $updatedata['site_user_id'].".".$ext;
            $updateimagenamequery = 'update `ppe_user_profiles` SET `profile_value` = "'.$webprofileimage.'" WHERE user_id = '.(int) $updatedata['site_user_id'].' AND profile_key = "profile.image" ';
            $result = $obj_service->sql_query($updateimagenamequery);

            return true;
        }
        else{
            return false;
        }
    }

    
    /*
     * SPECIFIC TOOLZONE FUNCTIONS - RJ
     */
    
    //Get ToolZone Tree structure
    public static function getcategorylist($category_id = 0, $jobzone_id = 0, $company_id = 0, $product_array = array())
    {
        global $obj_service;
        $obj_service = new sql();        
        $appurl = general::appurl().'components/com_jshopping/files/img_categories/';
                
        $query  = ' SELECT category_id, `name_en-GB` AS category_name, category_image
                    FROM `ppe_jshopping_categories` 
                    WHERE `category_parent_id` = "'.$category_id.'" AND `category_publish` = 1 ORDER BY ordering ASC';                   
            
        $result = $obj_service->sql_query($query) or die($query.": Selection Failed REASON: ".mysql_error());
        $categorylist = $obj_service->fetch_array_multiple($result);
                
        foreach($categorylist as $category_data) {                                    
            $category_products = general::countproductlist($category_data['category_id'], $jobzone_id, $company_id);
            if($category_products > 0) 
            {
                $temp_array = array();
                $category_data['category_name'] = utf8_encode($category_data['category_name']);
                if($category_data['category_image'] != null) {
                    $category_data['category_image'] = $appurl.$category_data['category_image'];
                    $category_data['category_image'] = general::appurl().'timthumb/timthumb.php?src='.$category_data['category_image'].'&q=50&zc=2';                    
                }                
                $temp_array = $category_data;
                $temp_array['productCount'] = count($category_products);            
                $temp_array['subcategories'] = general::getcategorylist($category_data['category_id'], $jobzone_id, $company_id);            
                $temp_array['subCategoryCount'] = count($temp_array['subcategories']);            
                $product_array[] = $temp_array;            
            }
        }        
        
        return $product_array;
    }

}
?>