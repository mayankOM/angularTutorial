<?php

define('_JEXEC', 1);
define('JPATH_BASE', dirname(__FILE__));
define('DS', DIRECTORY_SEPARATOR);

require_once ( JPATH_BASE . DS . 'includes' . DS . 'defines.php' );
require_once ( JPATH_BASE . DS . 'includes' . DS . 'framework.php' );

global $conn1;
global $servername;
global $username;
global $password;
global $dbname;
global $curDB;
global $tablePrefix;

$database = new JConfig();
$config_vars = get_class_vars(get_class($database));

//Master Database connection
$servername = $config_vars['host'];
$username = $config_vars['user'];
$password = $config_vars['password'];
$curDB = $config_vars['db'];
$dbname = "tyson_master";
$tablePrefix =  $config_vars['dbprefix'];

$conn1 = new mysqli($servername, $username, $password, $dbname);
if ($conn1->connect_error) {    
    die("Connection failed master: " . $conn1->connect_error);
}

class dataMigrate
{
    /**
    * @author       Softweb Solution-MK
    * @package      App User clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : User Information
    * @output : Insert or update user information   
    */
    public function updateDatabases($tableName, $excludeDB = '') 
    {        
        //UPDATE INTO ALL DATABASE
        global $servername;
        global $username;
        global $password;
        global $dbname;

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {    
            die("Connection failed master: " . $conn->connect_error);
        }

        //Find other facilities of same location/group
        $query = "SELECT * from databases_assoc";
        $result = $conn->query($query);
        
        while($db_value = $result->fetch_array(MYSQLI_ASSOC)) {

            if($db_value['db_name'] != $excludeDB) {
                $subconn = new mysqli($servername, $username, $password, $db_value['db_name']);
                if ($subconn->connect_error) {    
                die("Connection failed facilities: " . $subconn->connect_error);
                }
                $query = "REPLACE INTO ".$db_value['db_name'].".".$tableName." SELECT * FROM ".$dbname.".".$tableName."";
                $subconn->query($query);
            }
        }
        return true;
    }


    /**
    * @author       Softweb Solution-MK
    * @package      Admin (Sefty Manager) profile clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : user profile table
    * @output : Cloning with master and other branch of organization
    */
    public function clonUpdateAdminManager($specificTable='', $image_name) 
    {   
        global $tablePrefix;
        
        global $servername;
        global $username;
        global $password;
        global $dbname;
        global $curDB;

        $fromDB = $curDB;
        $toDB = $dbname;
        
        // Create connection
        $subconn = new mysqli($servername, $username, $password, $fromDB);
        if ($subconn->connect_error) {    
            die("Connection failed master: " . $conn->connect_error);
        }
        $tableArray = array("users", "user_usergroup_map", "company_employee", "user_profiles");
        for($i=0;$i<count($tableArray);$i++){
            $tableName = $tablePrefix.''.$tableArray[$i];
            
            $query = "REPLACE INTO ".$toDB.".".$tableName." SELECT * FROM ".$fromDB.".".$tableName."";
            $subconn->query($query);
            dataMigrate::updateDatabases($tableName);
        }
        dataMigrate::sync($image_name);   
        return true;
    }

    /**
    * @author       Softweb Solution-MK
    * @package      Admin (Sefty Manager) profile clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : user profile table
    * @output : Cloning with master and other branch of organization
    */
    public function clonUpdateWebEmployee($specificTable='', $image_name='') 
    {   
        global $tablePrefix;
        
        global $servername;
        global $username;
        global $password;
        global $dbname;
        global $curDB;

        $fromDB = $curDB;
        $toDB = $dbname;
        
        // Create connection
        $subconn = new mysqli($servername, $username, $password, $fromDB);
        if ($subconn->connect_error) {    
            die("Connection failed master: " . $conn->connect_error);
        }
        $tableArray = array("users", "user_usergroup_map", "company_employee", "user_profiles");
        for($i=0;$i<count($tableArray);$i++){
            $tableName = $tablePrefix.''.$tableArray[$i];
            $query = "REPLACE INTO ".$toDB.".".$tableName." SELECT * FROM ".$fromDB.".".$tableName."";
            $subconn->query($query);
            dataMigrate::updateDatabases($tableName, $fromDB);
        }
        if($image_name != "")
        {
            dataMigrate::sync($image_name);    
        }
        return true;
    }

    /**
    * @author       Softweb Solution-MK
    * @package      Website company employee cloning delete
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : user id, Table name
    * @output : Cloning with master and other remaining table for delete record
    */
    public function clonDeleteWebUserCompanyEmployee($user_id='') 
    {   
        //UPDATE INTO ALL DATABASE
        global $servername;
        global $username;
        global $password;
        global $dbname;
        global $tablePrefix;
        global $curDB;

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {    
            die("Connection failed master: " . $conn->connect_error);
        }

        //Find other facilities of same location/group
        $query = "SELECT * from databases_assoc";
        $result = $conn->query($query);
        
        $cnt = 0;
        while($db_value = $result->fetch_array(MYSQLI_ASSOC)) {
            $testArray[$cnt] = $db_value['db_name']; 
            $cnt++;
        }
        array_push($testArray,'tyson_master'); 
        foreach ($testArray as $key => $value) 
        {
            if($value != $curDB)
            {
                $connDel = new mysqli($servername, $username, $password, $value);
                if ($conn->connect_error) {    
                    die("Connection failed master: " . $conn->connect_error);
                }

                $tableArray = array("users", "user_usergroup_map", "company_employee", "user_profiles");
                
                foreach ($tableArray as $tableKey => $tname) {
                    $tableName = $tablePrefix.''.$tname;
                    if($tname == 'users')
                    {
                        $query = "DELETE FROM ".$tableName." WHERE id = ".(int) $user_id;
                        $connDel->query($query);
                    }
                    else
                    {
                        $query = "DELETE FROM ".$tableName." WHERE user_id = ".(int) $user_id;
                        $connDel->query($query);
                    }
                }
            }            
        }
        return true;
    }


    /**
    * @author       Softweb Solution-MK
    * @package      Website company employee cloning delete
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : user id, Table name
    * @output : Cloning with master and other remaining table for delete record
    */
    public function clonDeleteWebCompanyEmployee($user_id='',$table_name='') 
    {   
        //UPDATE INTO ALL DATABASE
        global $servername;
        global $username;
        global $password;
        global $dbname;
        global $tablePrefix;
        global $curDB;

        $tableName = $tablePrefix.''.$table_name;

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {    
            die("Connection failed master: " . $conn->connect_error);
        }

        //Find other facilities of same location/group
        $query = "SELECT * from databases_assoc";
        $result = $conn->query($query);
        
        $cnt = 0;
        while($db_value = $result->fetch_array(MYSQLI_ASSOC)) {

            echo $db_value['db_name'];
            $testArray[$cnt] = $db_value['db_name']; 
            $cnt++;
        }
        array_push($testArray,'tyson_master'); 
        foreach ($testArray as $key => $value) 
        {
            if($value != $curDB)
            {
                $connDel = new mysqli($servername, $username, $password, $value);
                if ($conn->connect_error) {    
                    die("Connection failed master: " . $conn->connect_error);
                }
                $query = "DELETE FROM ".$tableName." WHERE user_id = ".(int) $user_id;
                $connDel->query($query);
            }            
        }
        return true;
    }



/**
    * @author       Softweb Solution-MK
    * @package      Admin (Sefty Manager) profile clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : user profile table
    * @output : Cloning with master and other branch of organization
    */
    public function sync($image_name) 
    {
        global $conn1;
        global $tablePrefix;

        $pathSource = JPATH_SITE.'/images/ppezone/users/';
        $file_pathSource = scandir($pathSource);
        
        $seftyManagerImage = explode('.', $image_name);
        $seftyManagerID = $seftyManagerImage[0];
        $ext = pathinfo($image_name, PATHINFO_EXTENSION);

        $imgOriginalName = $image_name;
        $imgThumbName = 'thumb_'.$seftyManagerID.'.'.$ext;
        $imgFullName = 'full_'.$seftyManagerID.'.'.$ext;

        $imgArray = array($imgOriginalName, $imgThumbName, $imgFullName);
        
        $query = "SELECT db_name, base_url, site_url from databases_assoc WHERE status = '1'";
        $result = $conn1->query($query);

        while($row = $result->fetch_array())
        {
            if(isset($row['base_url']) && JPATH_SITE != $row['base_url'])
            {
                $pathDestin = $row['base_url'].'/images/ppezone/users/';
                foreach ($imgArray as $key => $value) {
                    //if (file_exists($pathDestin.''.$value)) {
                        /*echo $pathDestin.''.$value;
                        echo "<br>";*/
                        @unlink($pathDestin.''.$value); // Remove existing image in other directory
                    //}
                }
                $file_pathDestin = scandir($pathDestin);
                $newfiles = array_diff($file_pathSource, $file_pathDestin);
                foreach ($newfiles as $key => $value) {
                    $value = trim($value);
                    $res = copy($pathSource.$value, $pathDestin.$value);
                }
            }
        }
        return true;
    }

    /**
    * @author       Softweb Solution-MK
    * @package      General cloning Current DB to Master DB and then update into other DB
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : Table name
    * @output : Cloning with master table firts then cloning other db
    */
    public function updateCurrentToMasterDB($tableName) 
    {   
        //UPDATE INTO ALL DATABASE
        global $servername;
        global $username;
        global $password;
        global $dbname;
        global $tablePrefix;
        global $curDB;

        // Create connection
        $fromDB = $curDB;
        $toDB = $dbname;

        $subconn = new mysqli($servername, $username, $password, $fromDB);
        if ($subconn->connect_error) {    
            die("Connection failed master: " . $conn->connect_error);
        }
        
        $tableName = $tablePrefix.''.$tableName;
        $query = "REPLACE INTO ".$toDB.".".$tableName." SELECT * FROM ".$fromDB.".".$tableName."";
        $subconn->query($query);
        dataMigrate::updateDatabases($tableName, $fromDB);
        return true;
    }

    /**
    * @author       Softweb Solution-MK
    * @package      App User clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : User Information
    * @output : Insert or update user information   
    */
    function updateAppUser( $post )
    {     
        global $conn1;
        global $tablePrefix;

        $tableName = $tablePrefix.''.$post['tableName'];
        
        $data = '';
        if($post['app_user_id'] != '')
        {
            $query = "SELECT * from ".$tableName." WHERE app_user_id = ".$post['app_user_id'];
            $result = $conn1->query($query);
            $data = $result->fetch_assoc();
        }

        if($data)
        {
            $updateStr = '';

            if($post['employee_id'] != '')
            {
                $updateStr .= "employee_id = '".$post['employee_id']."',";
            }
            if($post['password'] != '')
            {
                $updateStr .= "password = '".$post['password']."',";
            }
            if($post['firstname'] != '')
            {
                $updateStr .= "firstname = '".$post['firstname']."',";
            }
            if($post['lastname'] != '')
            {
                $updateStr .= "lastname = '".$post['lastname']."',";
            }
            if($post['jobzone_id'] != '')
            {
                $updateStr .= "jobzone_id = '".$post['jobzone_id']."',";
            }
            if($post['company_id'] != '')
            {
                $updateStr .= "company_id = '".$post['company_id']."',";
            }
            if($post['barcode'] != '')
            {
                $updateStr .= "barcode = '".$post['barcode']."',";
            }
            if($post['locker_no'] != '')
            {
                $updateStr .= "locker_no = '".$post['locker_no']."',";
            }
            if($post['department_no'] != '')
            {
                $updateStr .= "department_no = '".$post['department_no']."',";
            }
            if($post['combination_no'] != '')
            {
                $updateStr .= "combination_no = '".$post['combination_no']."',";
            }
            if($post['date_of_hire'] != '')
            {
                $updateStr .= "date_of_hire = '".$post['date_of_hire']."',";
            }
            if($post['image'] != '')
            {
                $updateStr .= "image = '".$post['image']."',";
            }
            if($post['signature'] != '')
            {
                $updateStr .= "signature = '".$post['signature']."',";
            }
            if($post['registered_at'] != '')
            {
                $updateStr .= "registered_at = '".$post['registered_at']."',";
            }
            
            if(trim($post['block']) != '')
            {
                $updateStr .= "block = '".$post['block']."',";
            }  

            if(trim($post['is_deleted']) != '')
            {
                $updateStr .= "is_deleted = '".$post['is_deleted']."',";
            }
            $updateStr = substr($updateStr, 0,-1);
            $update_query = "UPDATE ".$tableName." SET ".$updateStr." WHERE app_user_id = ".$post['app_user_id'];
            $result = $conn1->query($update_query);
            $return = $post['app_user_id'];
        }
        else
        {
            $updateStr = '';
            $employee_id = $post['employee_id'];
            $password = $post['password'];
            $firstname = $post['firstname'];
            $lastname = $post['lastname'];
            $jobzone_id = $post['jobzone_id'];
            $company_id = $post['company_id'];
            $barcode = $post['barcode'];
            $locker_no = $post['locker_no'];
            $department_no = $post['department_no'];
            $combination_no = $post['combination_no'];
            $date_of_hire = $post['date_of_hire'];
            $image = $post['image'];
            $signature = $post['signature'];
            $registered_at = $post['registered_at'];
            $block = $post['block'];
            $is_deleted = $post['is_deleted'];

            $insert_query = " INSERT INTO ".$tableName." 
                   (employee_id, password, firstname, lastname, jobzone_id, company_id, barcode,
                    locker_no, department_no, combination_no, date_of_hire,
                    image, signature, registered_at, block, is_deleted)
            VALUES ('".$employee_id."','".$password."','".$firstname."','".$lastname."','".$jobzone_id."',
                    '".$company_id."','".$barcode."','".$locker_no."','".$department_no."','".$combination_no."',
                    '".$date_of_hire."','".$image."','".$signature."','".$registered_at."','".$block."','".$is_deleted."')";
            $result = $conn1->query($insert_query);
            $last_inserted_id = $conn1->insert_id;
            $return = $last_inserted_id;
        }        
        
        dataMigrate::updateDatabases($tableName);          

        return $return;
    }

   
   /**
    * @author       Softweb Solution-MK
    * @package      App User clone with image upload
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : User image and signeture
    * @output : update user with image and signeture information   
    */
    function updateAppUserImage( $post )
    {
        global $conn1;
        global $tablePrefix;

        $data = '';
        if(isset($post))
        {
            $query = "SELECT db_name, base_url, site_url from databases_assoc WHERE status = '1'";
            $result = $conn1->query($query);
            while($row = $result->fetch_array())
            {
                $rows[] = $row;
            }
        }

        $company_id = isset($post['company_id']) ? trim($post['company_id']) : '';
        $user_id = isset($post['user_id']) ? trim($post['user_id']) : '';
        $employee_id = isset($post['employee_id']) ? trim($post['employee_id']) : '';        
        $user_image = isset($post['image']) ? trim($post['image']) : '';
        $user_emp_sign = isset($post['emp_sign']) ? trim($post['emp_sign']) : '';
        $tableName = $tablePrefix.''.$post['tableName'];

        for($i=0;$i<count($rows);$i++)
        {
            $set = "";
            if ($user_image != '') {
                $image = str_replace(' ', '+', $user_image);
                $image = base64_decode($image);
                $file = $rows[$i]['base_url']. '/images/app_users/' . $company_id . '_' . $employee_id . '.jpg';
                unlink($file);
                $success = file_put_contents($file, $image);
                $set .= "`image` = '" . $company_id . '_' . mysql_real_escape_string($employee_id) . ".jpg',"; 
            }
            if ($user_emp_sign != '') {
                $emp_sign = str_replace(' ', '+', $user_emp_sign);
                $emp_sign = base64_decode($emp_sign);
                $emp_sign_file = $rows[$i]['base_url']. '/images/app_users_signature/' . $company_id . '_' . $employee_id . '.jpg';
                unlink($emp_sign_file);
                $emp_signsuccess = file_put_contents($emp_sign_file, $emp_sign);
                $set .= " `signature` = '" . $company_id . '_' . mysql_real_escape_string($employee_id) . ".jpg' "; 
            }
            $updateStr = substr($set, 0,-1);
            $update_query = "UPDATE ".$tableName." SET ".$updateStr." WHERE app_user_id = ".$user_id;
            $result = $conn1->query($update_query);
        }    
        
        dataMigrate::updateDatabases($tableName);          

        return true;
    }

    /**
    * @author       Softweb Solution-MK
    * @package      App User clone with image upload from admin panel
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : User image 
    * @output : update user with image
    */
    function updateUserImageFromAdmin( $file, $user )
    {
        global $conn1;
        global $tablePrefix;

        if(isset($file) && ($file['size'] > 0))
        {
            $query = "SELECT db_name, base_url, site_url from databases_assoc WHERE status = '1'";
            $result = $conn1->query($query);
            $ext = pathinfo($file['name'], PATHINFO_EXTENSION);  
            $res = '';
            if($ext == "jpg" || $ext == "jpeg" || $ext == "png" || $ext == "gif" ) {
                $name_image = $user.".".$ext;
                $cnt = 0;
                $numrows = mysqli_num_rows($result);
                while($row = $result->fetch_array())
                {
                    $image_path = $row['base_url']. '/images/app_users/'.$name_image;
                    $move_file = copy($file['tmp_name'], $image_path);
                    if($move_file)
                    {
                        $cnt++;
                    }
                }                
                if($cnt == $numrows)
                {
                    $res = $name_image;
                }
                else
                {
                    $res = 'UPLOAD_ERR';
                }
            }
            else
            {
                $res = 'EXT_ERR';  
            }            
        }
        return $res;
    }

    /**
    * @author       Softweb Solution-MK
    * @package      App Job Zone clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : Job Zone Information
    * @output : Update job Zone information   
    */
    function clonJobeRole( $post )
    {     
        global $conn1;
        global $tablePrefix;

        $tableName = $tablePrefix.''.$post['tableName'];
        
        $data = '';
        if($post['id'] != '')
        {
            $query = "SELECT * from ".$tableName." WHERE id = ".$post['id'];
            $result = $conn1->query($query);
            $data = $result->fetch_assoc();
        }
        
        if($data)
        {
            $updateStr = '';
 
            if($post['job_title'] != '')
            {
                $updateStr .= "job_title = '".$post['job_title']."',";
            }
            if($post['job_desc'] != '')
            {
                $updateStr .= "job_desc = '".$post['job_desc']."',";
            }
            if($post['industries'] != '')
            {
                $updateStr .= "industries = '".$post['industries']."',";
            }
            if($post['published'] != '')
            {
                $updateStr .= "published = '".$post['published']."',";
            }
            if(trim($post['is_app']) != '')
            {
                $updateStr .= "is_app = '".$post['is_app']."',";
            }  
            
            if($updateStr != "")
            {
                $updateStr .= "updated_at = '".date('Y-m-d h:i:s')."',"; 
            }

            $updateStr = substr($updateStr, 0,-1);
            $update_query = "UPDATE ".$tableName." SET ".$updateStr." WHERE id = ".$post['id'];
            
            $result = $conn1->query($update_query);
            $return = $post['id'];
        }
        else
        {
            $updateStr = '';
            $job_title = $post['job_title'];
            $job_desc = $post['job_desc'];
            $industries = $post['industries'];
            $published = $post['published'];
            $is_app = $post['is_app'];
            $dateToday = date('Y-m-d h:i:s');

            $insert_query = " INSERT INTO ".$tableName." 
                   (job_title, job_desc, industries, published, is_app, created_at, updated_at)
            VALUES ('".$job_title."','".$job_desc."','".$industries."','".$published."','".$is_app."','".$dateToday."','".$dateToday."')";
            
            $result = $conn1->query($insert_query);
            $last_inserted_id = $conn1->insert_id;
            $return = $last_inserted_id;
        }        
        
        dataMigrate::updateDatabases($tableName);          

        return $return;
    }


    /**
    * @author       Softweb Solution-MK
    * @package      App Job Zone clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : job role ids Information
    * @output : Update user information   
    */
    function clonJobeRolePubUnPub( $post )
    {     
        global $conn1;
        global $tablePrefix;

        $tableName = $tablePrefix.''.$post['tableName'];
        $data = '';
        $numrows = 0;
        if($post['ids'] != '')
        {
            $query = "SELECT * from ".$tableName." WHERE  id IN (".$post['ids'].")";
            $result = $conn1->query($query);
            $data = $result->fetch_assoc();
            $numrows = mysqli_num_rows($result);
        }
        
        if($numrows > 0)
        {
            $updateStr = '';
            $str = explode(',', $post['ids']);
            $cntStr = count($str);
            $update_query = "UPDATE ".$tableName." SET published = ".$post['published']." WHERE id IN (".$post['ids'].")";
            $result = $conn1->query($update_query);
            $return = $cntStr;
        }else{
            $return = 0;
        }
        dataMigrate::updateDatabases($tableName);
        return $return;
    }


    /**
    * @author       Softweb Solution-MK
    * @package      App Job Zone clone
    * @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
    * @license      GNU/GPL
    * @input : job role ids Information
    * @output : Update user information   
    */
    function clonJobeRoleDelete( $post )
    {   
        global $servername;
        global $username;
        global $password;
        global $dbname;
        global $tablePrefix;
        global $curDB;  
        global $conn1;
        global $tablePrefix;
        
        $tableName = $tablePrefix.''.$post['tableName'];
        $data = '';
        $numrows = 0;
        if($post['ids'] != '')
        {
            $query = "SELECT * from ".$tableName." WHERE  id IN (".$post['ids'].")";
            $result = $conn1->query($query);
            $data = $result->fetch_assoc();
            $numrows = mysqli_num_rows($result);
        }

        if($numrows > 0)
        {
            $updateStr = '';
            $str = explode(',', $post['ids']);
            $cntStr = count($str);

            $query = "SELECT * FROM databases_assoc WHERE status = '1'";
            $result = $conn1->query($query);

            $cnt = 0;
            while($db_value = $result->fetch_array(MYSQLI_ASSOC)) {

                //echo $db_value['db_name'];
                $testArray[$cnt] = $db_value['db_name']; 
                $cnt++;
            }
            array_push($testArray,'tyson_master');

            foreach ($testArray as $key => $value) 
            {
                //echo $value.'-------'.$curDB;
                $connDel = new mysqli($servername, $username, $password, $value);
                if ($conn->connect_error) {    
                    die("Connection failed master: " . $conn->connect_error);
                }
                $query = "DELETE FROM ".$tableName." WHERE id IN (".$post['ids'].")";
                $connDel->query($query);
                /*if($value != $curDB)
                {
                    $connDel = new mysqli($servername, $username, $password, $value);
                    if ($conn->connect_error) {    
                        die("Connection failed master: " . $conn->connect_error);
                    }
                    $query = "DELETE FROM ".$tableName." WHERE id IN (".$post['ids'].")";
                    $connDel->query($query);
                }*/            
            }            
            $return = $cntStr;
        }else{
            $return = 0;
        }
        dataMigrate::updateDatabases($tableName);
        return $return;
    }
}
?>